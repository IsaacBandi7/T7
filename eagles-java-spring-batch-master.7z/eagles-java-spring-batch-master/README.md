eagles-java-spring-batch
========================

Spring Batch POC for Generating CDI Master File:


Compare Source Master files four part key with other three files[ECID, ENTITY and Previous Day Master File] 
four part key and get the corresponding CDI and ECID keys and write it in the Output file to generate CDI Master File.

Technologies Used:

Spring batch

Lucene

Core Java
