package com.cap1.cdi.util;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.springframework.core.io.Resource;

/**
 * Utility class to get the single Lucene IndexSearcher instance based on Index path.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class LuceneUtil {

	final static Logger LOG = Logger.getLogger(LuceneUtil.class);
	private static IndexSearcher indexSearcher = null;
	private static IndexSearcher prevMFIndexSearcher = null;

	/**
	 * This method used to return the single instance for all the threads
	 * looking for IndexSearcher.
	 * @param indexPath 
	 * @return searcher - IndexSearcher
	 * @throws Exception
	 */
	public IndexSearcher getSearcher(String indexPath) throws Exception {
		try {
			if (indexSearcher == null) {
				if (indexPath != null) {
					Directory dir = FSDirectory.open(new File(indexPath).toPath());
					IndexReader indexReader = DirectoryReader.open(dir);
					indexSearcher = new IndexSearcher(indexReader);
				}
			}
		} catch (IOException e) {
			LOG.error("", e);
			throw new Exception(e);
		}
		return indexSearcher;
	}
	
	/**
	 * This method used to return the single instance for all the threads
	 * looking for Previous Day MF IndexSearcher.
	 * 
	 * @return prevMFIndexSearcher - IndexSearcher
	 * @throws Exception
	 */
	public IndexSearcher getPrevMFSearcher() throws Exception {
		try {
			if (prevMFIndexSearcher == null) {
				String indexPath = BatchUtil.getProperty("prevmf.index.path");
				if (indexPath != null) {
					Directory dir = FSDirectory.open(new File(indexPath).toPath());
					IndexReader indexReader = DirectoryReader.open(dir);
					prevMFIndexSearcher = new IndexSearcher(indexReader);
				}
			}
		} catch (IOException e) {
			LOG.error("", e);
			throw new Exception(e);
		}
		return prevMFIndexSearcher;
	}
	
	/**
	 * This method used to get the IndexWriter instance based on index path.
	 * @param indexPath
	 * @return IndexWriter - the  index writer
	 * @throws IOException
	 */
	public IndexWriter getIndexWriter(Resource indexPath) throws IOException {
		IndexWriter indexWriter = null;
		try {
			final Directory dir = FSDirectory.open(new File(indexPath.getFile().getAbsolutePath()).toPath());
			Analyzer analyzer = null;
			IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
			iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);
			indexWriter = new IndexWriter(dir, iwc);
		} catch (IOException e) {
			throw e;
		}
		return indexWriter;
	}
	
	/**
	 * This method used to force merge and close the IndexWriter instance properly.
	 * @param indexWriter
	 * @param forceMergeCount
	 * @throws IOException
	 */
	public void closeIndexWriter(IndexWriter indexWriter, int forceMergeCount) throws IOException {
		
		try {
			indexWriter.forceMerge(forceMergeCount);
			indexWriter.commit();
			indexWriter.close();
		} catch (IOException e) {
			throw e;
		}
	}
	
	/**
	 * This method used to return the matching documents from Lucene index based
	 * on search input.
	 * 
	 * @param searcher
	 * @param indexField
	 * @param searchInput
	 * @return ScoreDoc - array of documents
	 * @throws Exception
	 */
	public ScoreDoc[] getMatchedDocuments(IndexSearcher searcher, String indexField, String searchInput) throws Exception {
		TopScoreDocCollector collector = TopScoreDocCollector.create(5);
		final Term t = new Term(indexField, searchInput);
		final Query query = new TermQuery(t);
		searcher.search(query, collector);
		return collector.topDocs().scoreDocs;
	}
}
