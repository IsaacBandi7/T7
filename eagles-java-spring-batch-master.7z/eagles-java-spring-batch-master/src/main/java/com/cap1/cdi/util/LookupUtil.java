package com.cap1.cdi.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cap1.cdi.model.SorIdPrftCodePair;

/**
 * Utility class used to look up the file to get the field values.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class LookupUtil {

	final static Logger LOG = Logger.getLogger(LookupUtil.class);
	private static Map<SorIdPrftCodePair, String> lookupFileMap = new HashMap<SorIdPrftCodePair, String>();

	/**
	 * Method used to return the legl_afil_id based on Sor_id and Prft_code from
	 * the HashMap.
	 * 
	 * @param sorId
	 * @param prftCode
	 * @return String - legal afil id
	 */
	public static String getLegalAfilId(String sorId, String prftCode) {

		String legalAfilId = "";
		if (lookupFileMap.isEmpty()) {
			loadLookupFile();
		}
		legalAfilId = getLegalAfilIdFromMap(sorId, prftCode);
		return legalAfilId;
	}

	/**
	 * Get the Legal Afil id from the map, if the value already available in the Map.
	 * @param sorId
	 * @param prftCode
	 * @return String - legalAfilId
	 */
	private static String getLegalAfilIdFromMap(String sorId, String prftCode) {
		String legalAfilId;
		SorIdPrftCodePair sorIdPrftPair = new SorIdPrftCodePair();
		sorIdPrftPair.setSorId(sorId);
		sorIdPrftPair.setPrftCode(prftCode);
		legalAfilId = lookupFileMap.get(sorIdPrftPair);
		if (legalAfilId == null) {
			legalAfilId = "";
		}
		return legalAfilId;
	}

	/**
	 * Method used to load the legl_afil_id_lkp lookup file content in HashMap.
	 * 
	 * @return map - Sor id and profit center code pair as key and legal-afil id
	 *         as value
	 */
	private static Map<SorIdPrftCodePair, String> loadLookupFile() {

		try {
			InputStream in = LookupUtil.class.getResourceAsStream("/legl_afil_id_lkp.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(in, Charset.forName("UTF-8")));
			String line = null;
			while ((line = br.readLine()) != null) {
				String[] lineTokens = Pattern.compile("\\~").split(line);
				SorIdPrftCodePair sorIdPrftPair = new SorIdPrftCodePair();
				sorIdPrftPair.setSorId(lineTokens[0]);
				sorIdPrftPair.setPrftCode(lineTokens[1]);
				lookupFileMap.put(sorIdPrftPair, lineTokens[2]);
			}
			br.close();
			in.close();
		} catch (ArrayIndexOutOfBoundsException aiobe) {
			// does nothing
		} catch (FileNotFoundException fnfe) {
			LOG.error(fnfe);
		} catch (IOException ioe) {
			LOG.error(ioe);
		} catch (Exception e) {
			LOG.error(e);
		}
		return lookupFileMap;
	}
}
