package com.cap1.cdi.batch.tokenizer;

import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;

/**
 * Be-Spoke DelimitedLineTokenizer class used to not to throw
 * FlatFileParseException when double quotes in the record content.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class CustomDelimitedLineTokenizer extends DelimitedLineTokenizer {

	@Override
	protected boolean isQuoteCharacter(char c) {
		return false;
	}
}