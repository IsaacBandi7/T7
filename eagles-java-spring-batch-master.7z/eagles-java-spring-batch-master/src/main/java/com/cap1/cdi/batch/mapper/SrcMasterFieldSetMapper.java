package com.cap1.cdi.batch.mapper;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.cap1.cdi.model.SrcMaster;

/**
 * Mapper class used to map other sources file fields with SrcMaster class
 * properties.
 * 
 * @author Sankaraiah Narayanasamy
 */
public class SrcMasterFieldSetMapper implements FieldSetMapper<SrcMaster> {

	
	@Override
	public SrcMaster mapFieldSet(FieldSet fieldSet) throws BindException {
		
		SrcMaster srcMaster = new SrcMaster();
		
		srcMaster.setSor_id(fieldSet.readLong(0));
		srcMaster.setSor_cust_id(fieldSet.readLong(1));
		srcMaster.setAcct_id(fieldSet.readString(2));
		srcMaster.setCust_role_type_cd(fieldSet.readString(3));
		
		srcMaster.setCust_full_nm(fieldSet.readString(4));
		
		srcMaster.setMailg_adr_line_1(fieldSet.readString(5));
		srcMaster.setMailg_adr_line_2(fieldSet.readString(6));
		srcMaster.setMailg_city_nm(fieldSet.readString(7));
		srcMaster.setMailg_geo_st_cd(fieldSet.readString(8));
		srcMaster.setMailg_full_pstl_cd(fieldSet.readString(9));
		srcMaster.setMailg_cntry_cd(fieldSet.readString(10));
		srcMaster.setMailg_adr_desc(fieldSet.readString(11));
		
		srcMaster.setPhy_adr_line_1(fieldSet.readString(12));
		srcMaster.setPhy_adr_line_2(fieldSet.readString(13));
		srcMaster.setPhy_city_nm(fieldSet.readString(14));
		srcMaster.setPhy_geo_st_cd(fieldSet.readString(15));
		srcMaster.setPhy_full_pstl_cd(fieldSet.readString(16));
		srcMaster.setPhy_cntry_cd(fieldSet.readString(17));
		srcMaster.setPhy_adr_desc(fieldSet.readString(18));
		
		srcMaster.setHome_phn_num(fieldSet.readString(19));
		srcMaster.setWork_phn_num(fieldSet.readString(20));
		srcMaster.setMobile_phn_num(fieldSet.readString(21));
		
		srcMaster.setEmail_adr_txt(fieldSet.readString(22));
		
		srcMaster.setSsn(fieldSet.readString(23));
		srcMaster.setCust_tax_idn_num(fieldSet.readString(24));
		
		srcMaster.setGndr_cd(fieldSet.readString(25));
		srcMaster.setMartl_cd(fieldSet.readString(26));
		srcMaster.setLang_cd(fieldSet.readString(27));
		srcMaster.setAcct_stat_cd(fieldSet.readString(28));
		srcMaster.setCust_brth_dt(fieldSet.readString(29));
		srcMaster.setAcct_open_dt(fieldSet.readString(30));
		srcMaster.setSor_acct_stat_cd(fieldSet.readString(31));
		srcMaster.setSor_acct_stat_desc(fieldSet.readString(32));
		
		srcMaster.setVld_phn_num_ind(fieldSet.readString(33));
		srcMaster.setProd_cd(fieldSet.readString(34));
		srcMaster.setPrft_ctr_cd(fieldSet.readString(35));
		srcMaster.setBus_legl_strc_cd(fieldSet.readString(36));
		srcMaster.setAcct_use_cd(fieldSet.readString(37));
		srcMaster.setCntry_of_origin_cd(fieldSet.readString(38));
		
	
		return srcMaster;
		
	}

}