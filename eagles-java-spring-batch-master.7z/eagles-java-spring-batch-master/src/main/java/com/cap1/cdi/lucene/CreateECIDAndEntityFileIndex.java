package com.cap1.cdi.lucene;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.apache.lucene.index.ConcurrentMergeScheduler;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.MergeScheduler;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import com.cap1.cdi.util.BatchUtil;
import com.cap1.cdi.util.LuceneUtil;

/**
 * Class used to create index for ECID and ENTITY files using Lucene API under
 * the index directory.
 * 
 * @author Sankaraiah Narayanasamy
 */
public class CreateECIDAndEntityFileIndex implements Tasklet, InitializingBean {

	final static Logger LOG = Logger.getLogger(CreateECIDAndEntityFileIndex.class);
	private Resource indexPath;
	private Resource docsPath;

	@Override
	public void afterPropertiesSet() throws Exception {

		Assert.notNull(indexPath, "directory must be set");
		Assert.notNull(docsPath, "directory must be set");
	}

	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) {

		long startTime = System.nanoTime();
		try {
			final File docDir = new File(docsPath.getFile().getAbsolutePath());
			LOG.info("Indexing to directory '" + indexPath + "'...");
			LuceneUtil luceneUtil = new LuceneUtil();
			IndexWriter indexWriter = luceneUtil.getIndexWriter(indexPath);
			MergeScheduler ms = indexWriter.getConfig().getMergeScheduler();
			if (ms instanceof ConcurrentMergeScheduler) {
				((ConcurrentMergeScheduler) ms).setMaxMergesAndThreads(4, 4);
			}
			if (docDir.canRead()) {
				if (docDir.isDirectory()) {
					String[] files = docDir.list();
					if (files != null) {
						ExecutorService executor = Executors.newFixedThreadPool(6);
						final String delimiter = BatchUtil.getProperty("file.delimiter");
						for (int i = 0; i < files.length; i++) {
							Runnable indexJob = new IndexJob(indexWriter, new File(docDir, files[i]), delimiter);
							executor.submit(indexJob);
						}
						executor.shutdown();
						while (!executor.isTerminated()) {
						}
					}
				}
			}
			luceneUtil.closeIndexWriter(indexWriter, 5);
			LOG.debug(System.nanoTime() - startTime+" Total Nanoseconds - Completed ECID and ENTITY File Indexing");
		} catch (IOException ioe) {
			LOG.error("", ioe);
		} catch(Exception e) {
			LOG.error("", e);
		}
		return RepeatStatus.FINISHED;
	}


	public Resource getIndexPath() {
		return indexPath;
	}

	public void setIndexPath(Resource indexPath) {
		this.indexPath = indexPath;
	}

	public Resource getDocsPath() {
		return docsPath;
	}

	public void setDocsPath(Resource docsPath) {
		this.docsPath = docsPath;
	}
}