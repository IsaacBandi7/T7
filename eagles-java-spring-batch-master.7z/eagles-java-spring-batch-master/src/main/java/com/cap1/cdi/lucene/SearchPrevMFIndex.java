package com.cap1.cdi.lucene;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopScoreDocCollector;

import com.cap1.cdi.model.EcidEntity;
import com.cap1.cdi.util.LuceneUtil;

/**
 * @author Sankaraiah Narayanasamy
 */
public class SearchPrevMFIndex {

	final static Logger LOG = Logger.getLogger(SearchPrevMFIndex.class);
	private final static String indexField = "four_pk";

	public SearchPrevMFIndex() {
	}

	/**
	 * Method used to search the index files based on four part key and get the
	 * results
	 * 
	 * @param searchInput
	 * @param item 
	 * @param customerFullName
	 * @return  EcidEntity
	 * @throws Exception
	 */
	public EcidEntity process(String searchInput, String sfCustomerFullName)
			throws Exception {

		try {
			LuceneUtil luceneUtil = new LuceneUtil();
			IndexSearcher searcher = luceneUtil.getPrevMFSearcher();
			TopScoreDocCollector collector = TopScoreDocCollector.create(3);
			final Term t = new Term(indexField, searchInput);
			final Query query = new TermQuery(t);

			searcher.search(query, collector);
			ScoreDoc[] hits = collector.topDocs().scoreDocs;
			EcidEntity lookup = new EcidEntity();
			for (int i = 0; i < hits.length; ++i) {
				int docId = hits[i].doc;
				Document d = searcher.doc(docId);
				final String custFullName = d.get("cust_full_nm");
				if (custFullName != null && custFullName.equals(sfCustomerFullName)) {
					lookup.setNm_ind("S");
					final String firstName = d.get("first_name");
					final String middleName = d.get("middle_name");
					final String lastName = d.get("last_name");
					lookup.setFrst_nm(firstName);
					lookup.setMid_nm(middleName);
					lookup.setLast_nm(lastName);
				} else {
					lookup.setNm_ind("N");
				}
			}
			return lookup;
		} catch (Exception e) {
			LOG.error(e);
			throw e;
		}
	}
}