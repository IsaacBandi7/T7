package com.cap1.cdi.model;

/**
 * Model class used in creating output file with CDI and ECID keys.
 * 
 * @author Deb Rout
 * @author Sankaraiah Narayanasamy.
 */

public class EcidEntity {

	private String cust_grp_mbrp_id;
	private String ent_cust_id;
	private String cust_grp_cd;
	private String hh_cust_grp_mbrp_id;
	
	private String frst_nm;
	private String mid_nm;
	private String last_nm;

	private String nm_ind;

	public String getCust_grp_mbrp_id() {
		return cust_grp_mbrp_id;
	}

	public void setCust_grp_mbrp_id(String cust_grp_mbrp_id) {
		this.cust_grp_mbrp_id = cust_grp_mbrp_id;
	}

	public String getEnt_cust_id() {
		return ent_cust_id;
	}

	public void setEnt_cust_id(String ent_cust_id) {
		this.ent_cust_id = ent_cust_id;
	}

	public String getCust_grp_cd() {
		return cust_grp_cd;
	}

	public void setCust_grp_cd(String cust_grp_cd) {
		this.cust_grp_cd = cust_grp_cd;
	}

	public String getHh_cust_grp_mbrp_id() {
		return hh_cust_grp_mbrp_id;
	}

	public void setHh_cust_grp_mbrp_id(String hh_cust_grp_mbrp_id) {
		this.hh_cust_grp_mbrp_id = hh_cust_grp_mbrp_id;
	}

	public String getNm_ind() {
		return nm_ind;
	}

	public void setNm_ind(String nm_ind) {
		this.nm_ind = nm_ind;
	}

	public String getFrst_nm() {
		return frst_nm;
	}

	public void setFrst_nm(String frst_nm) {
		this.frst_nm = frst_nm;
	}

	public String getMid_nm() {
		return mid_nm;
	}

	public void setMid_nm(String mid_nm) {
		this.mid_nm = mid_nm;
	}

	public String getLast_nm() {
		return last_nm;
	}

	public void setLast_nm(String last_nm) {
		this.last_nm = last_nm;
	}
}