package com.cap1.cdi.batch.listener;

import org.apache.log4j.Logger;
import org.springframework.batch.core.SkipListener;

import com.cap1.cdi.model.SrcMaster;

/**
 * Listener used to skip the records on read when we get parsing related
 * exception.
 * It can also be used for processing and writing phase.
 * @author Sankaraiah Narayanasamy
 */
public class RecordSkipListener implements SkipListener<SrcMaster, SrcMaster> {

	final static Logger LOG = Logger.getLogger(RecordSkipListener.class);
	public static String newLine = System.getProperty("line.separator");

	@Override
	public void onSkipInRead(Throwable t) {

		/*try {
			FileWriter writer = new FileWriter("C://Java_All//FilesWithPrevMF//error/error.dat", true);
			if (t instanceof FlatFileParseException) {
				FlatFileParseException exception = (FlatFileParseException) t;
				writer.write(exception.getInput()+newLine);
			}
			writer.close();
		} catch (IOException e) {
			LOG.error("Error on Skip Record writing", e);
		} catch (Exception e) {
			LOG.error("Error on Skip Record writing", e);
		}*/
	}

	@Override
	public void onSkipInWrite(SrcMaster item, Throwable t) {

	}

	@Override
	public void onSkipInProcess(SrcMaster item, Throwable t) {

		LOG.info(t.toString());
	}
}
