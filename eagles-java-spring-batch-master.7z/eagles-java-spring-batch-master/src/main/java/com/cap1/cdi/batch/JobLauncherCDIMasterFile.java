package com.cap1.cdi.batch;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Main Class used to run the CDI Master File batch job Using Step Partitioning
 * approach for scaling.
 * 
 * @author Deb Rout
 * @author Sankaraiah Narayanasamy
 */
public class JobLauncherCDIMasterFile {

	final static Logger LOG = Logger.getLogger(JobLauncherCDIMasterFile.class);

	public static void main(String[] args) {

		long startTime = System.nanoTime();
		String[] springConfig = { "spring/batch/jobs/job-cdimasterfile.xml" };
		try(AbstractApplicationContext context = new ClassPathXmlApplicationContext(springConfig)) {

			JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
			Job job = (Job) context.getBean("cdiMasterFileJob");
			JobExecution execution = jobLauncher.run(job, new JobParametersBuilder().toJobParameters());
			LOG.debug("Job Status : " + execution.getStatus());
			LOG.debug(System.nanoTime() - startTime+" Total Nanoseconds");
		} catch (Exception e) {
			LOG.error("", e);
		}
	}
}