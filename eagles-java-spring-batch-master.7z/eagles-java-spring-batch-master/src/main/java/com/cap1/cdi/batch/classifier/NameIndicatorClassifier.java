package com.cap1.cdi.batch.classifier;

import org.springframework.classify.annotation.Classifier;

import com.cap1.cdi.model.SrcMaster;

/**
 * Classifier used to return the name indicator value[S or N] which will be used to 
 * delegate the record to different writers in writer step configuration.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class NameIndicatorClassifier {

	@Classifier
	public String classify(SrcMaster classifiable) {

		return classifiable.getNm_ind();
	}

}
