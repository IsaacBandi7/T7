package com.cap1.cdi.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import com.cap1.cdi.lucene.SearchEcidEntityIndex;
import com.cap1.cdi.lucene.SearchPrevMFIndex;
import com.cap1.cdi.model.EcidEntity;
import com.cap1.cdi.model.SrcMaster;
import com.cap1.cdi.util.LookupUtil;

/**
 * Class used to process TSYS Source master file with ECID, ENTITY and PREV MF
 * files to get ECID and CDI keys.
 * 
 * @author Sankaraiah Narayanasamy
 */
public class TsysSrcMasterItemProcessor implements ItemProcessor<SrcMaster, SrcMaster> {
	
	final static Logger LOG = Logger.getLogger(TsysSrcMasterItemProcessor.class);

	@Override
	public SrcMaster process(SrcMaster sourceMaster) throws Exception {

		try {
			//Skip Record if acct_rel_stat_cd is R
			String acctRelStatCd = sourceMaster.getAcct_rel_stat_cd();
			if(null!=acctRelStatCd && acctRelStatCd.equals("R")) {
				return null;
			}
			final SearchEcidEntityIndex ecidEntityIndex = new SearchEcidEntityIndex();

			final String sorId = sourceMaster.getSor_id().toString();
			final String sorCustId = sourceMaster.getSor_cust_id().toString();
			final String accountId = sourceMaster.getAcct_id().replaceFirst("^0+(?!$)", "");
			final String custRoleTypeCd = sourceMaster.getCust_role_type_cd();
			final String four_pk =  sorId + sorCustId	+  accountId + custRoleTypeCd;

			EcidEntity lookup = ecidEntityIndex.process(four_pk);

			String legalAfilId = LookupUtil.getLegalAfilId(sorId, sourceMaster.getPrft_ctr_cd());
			sourceMaster.setLegl_afil_id(legalAfilId);
			if (!sorId.equals("6") && !sorId.equals("7")) {
				sourceMaster.setPrft_ctr_cd("");
			}
			sourceMaster.setSor_id(Long.parseLong(String.format("%2s", sorId).replace(' ', '0')));
			sourceMaster.setAcct_id(String.format("%18s", accountId).replace(' ', '0'));
			sourceMaster.setHh_cust_grp_mbrp_id(lookup.getHh_cust_grp_mbrp_id());
			String custGrpCd = lookup.getCust_grp_cd();
			if(custGrpCd!=null) {
				sourceMaster.setCust_grp_cd(custGrpCd.trim());
			} else {
				sourceMaster.setCust_grp_cd(custGrpCd);
			}
			final String ssn = sourceMaster.getSsn();
			if(sourceMaster.getSsn()!=null) {
				sourceMaster.setCust_tax_idn_num(ssn);
			}
			//PREV MF CHANGES
			SearchPrevMFIndex prevMFIndex = new SearchPrevMFIndex();
			EcidEntity process = prevMFIndex.process(four_pk, sourceMaster.getCust_full_nm());
			if(null==process.getNm_ind()) {
				sourceMaster.setNm_ind("N");
			} else {
				sourceMaster.setNm_ind(process.getNm_ind());
			}
			sourceMaster.setFrst_nm(process.getFrst_nm());
			sourceMaster.setMid_nm(process.getMid_nm());
			sourceMaster.setLast_nm(process.getLast_nm());
			//PREV MF CHANGES
			
			sourceMaster.setCust_grp_mbrp_id(lookup.getCust_grp_mbrp_id());
			sourceMaster.setEnt_cust_id(lookup.getEnt_cust_id());
			return sourceMaster;
		} catch (Exception e) {
			LOG.error(e);
			throw e;
		}
	}
}