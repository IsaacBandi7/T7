package com.cap1.cdi.lucene;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.index.IndexWriter;

/**
 * Class used to index Previous Day Master File on different threads based on four
 * part key.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class PreviousDayMFIndexJob implements Runnable {

	final static Logger LOG = Logger.getLogger(PreviousDayMFIndexJob.class);
	private IndexWriter writer;
	private File file;
	private String delimiter;

	public PreviousDayMFIndexJob(IndexWriter writer, File file, String delimiter) {
		this.writer = writer;
		this.file = file;
		this.delimiter = delimiter;
	}

	@Override
	public void run() {
		try {
			final String filePath = file.getPath();
			if (filePath.indexOf("prevmfa") != -1) {
				indexPreviousDayMF();
			}
		} catch (Exception e) {
			LOG.error("", e);
		}
	}

	/**
	 * This method used to index the Previous day master file fields(customer
	 * full name, first name, middle name and last name) based on four part key
	 */
	private void indexPreviousDayMF() {

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			BufferedReader br = new BufferedReader(new InputStreamReader(fis, Charset.forName("UTF-8")));

			Document doc = new Document();
			Field four_pk_Field = new StringField("four_pk", "", Field.Store.NO);
			doc.add(four_pk_Field);
			Field cust_full_nm = new StoredField("cust_full_nm", "");
			doc.add(cust_full_nm);
			Field first_name = new StoredField("first_name", "");
			doc.add(first_name);
			Field middle_Name = new StoredField("middle_name", "");
			doc.add(middle_Name);
			Field last_Name = new StoredField("last_name", "");
			doc.add(last_Name);
			
			String line = null;

			while ((line = br.readLine()) != null) {

				String[] lineTokens = line.split("\\"+delimiter);

				String sor_id = new Integer(lineTokens[0]).toString();
				String sor_cust_id = new Long(lineTokens[1]).toString();
				String acct_id = lineTokens[2].replaceFirst("^0+(?!$)", "");
				String cust_role_type_cd = lineTokens[3];
				String four_pk = sor_id + sor_cust_id + acct_id	+ cust_role_type_cd;
				String custFullName = lineTokens[9];
				String firstName = lineTokens[10];
				String middleName = lineTokens[11];
				String lastName = lineTokens[12];

				four_pk_Field.setStringValue(four_pk);
				cust_full_nm.setStringValue(custFullName);
				first_name.setStringValue(firstName);
				middle_Name.setStringValue(middleName);
				last_Name.setStringValue(lastName);
				writer.addDocument(doc);
			}
			br.close();
			writer.commit();
		} catch (FileNotFoundException fnfe) {
			LOG.error("", fnfe);
		} catch (IOException ioe) {
			LOG.error("", ioe);
		} catch (IndexOutOfBoundsException iobe) {
			LOG.error("", iobe);
		} catch (Exception e) {
			LOG.error("", e);
		}
		finally {
			try {
				fis.close();
			} catch (IOException e) {
				LOG.error("", e);
			}
		}
	}
}