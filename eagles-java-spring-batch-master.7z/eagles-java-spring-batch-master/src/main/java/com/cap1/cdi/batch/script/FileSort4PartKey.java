package com.cap1.cdi.batch.script;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.cap1.cdi.util.BatchUtil;

/**
 * Tasklet used to run the shell script which will sort the output file based on
 * four part key.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class FileSort4PartKey implements Tasklet {

	final static Logger LOG = Logger.getLogger(FileSort4PartKey.class);

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {

		try {
			LOG.debug("Four Part Key Sorting Started");
			final String fpKeySortScriptLocation = BatchUtil.getProperty("cdi.batch.fpkey.sort.script");
			final ProcessBuilder pb = new ProcessBuilder(fpKeySortScriptLocation);
			final Process p = pb.start();
			p.waitFor();
			LOG.debug("Four Part Key Sorting Completed");
		} catch (Exception e) {
			LOG.error("Error while executing Shell Script", e);
		}
		return RepeatStatus.FINISHED;
	}
}
