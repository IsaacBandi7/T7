package com.cap1.cdi.model;
/**
 * Model class used to hold Sorid and Prft code values.
 * @author Sankaraiah Narayanasamy
 *
 */
public class SorIdPrftCodePair {

	private String sorId;
	private String prftCode;

	public String getSorId() {
		return sorId;
	}

	public void setSorId(String sorId) {
		this.sorId = sorId;
	}

	public String getPrftCode() {
		return prftCode;
	}

	public void setPrftCode(String prftCode) {
		this.prftCode = prftCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((prftCode == null) ? 0 : prftCode.hashCode());
		result = prime * result + ((sorId == null) ? 0 : sorId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SorIdPrftCodePair other = (SorIdPrftCodePair) obj;
		if (prftCode == null) {
			if (other.prftCode != null)
				return false;
		} else if (!prftCode.equals(other.prftCode))
			return false;
		if (sorId == null) {
			if (other.sorId != null)
				return false;
		} else if (!sorId.equals(other.sorId))
			return false;
		return true;
	}
}