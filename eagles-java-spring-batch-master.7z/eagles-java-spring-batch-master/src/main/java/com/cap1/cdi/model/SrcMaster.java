package com.cap1.cdi.model;

/**
 * Model class holds the value of Source Master file and output file fields.
 * @author Deb Rout
 * @author Sankaraiah Narayanasamy
 *
 */
public class SrcMaster {

	private Long sor_id;
	private Long sor_cust_id;
	private String acct_id;
	private String cust_role_type_cd;
	private String cust_full_nm;
	private String mailg_adr_line_1;
	private String mailg_adr_line_2;
	private String mailg_city_nm;
	private String mailg_geo_st_cd;
	private String mailg_full_pstl_cd;
	private String mailg_cntry_cd;
	private String mailg_adr_desc;
	private String phy_adr_line_1;
	private String phy_adr_line_2;
	private String phy_city_nm;
	private String phy_geo_st_cd;
	private String phy_full_pstl_cd;
	private String phy_cntry_cd;
	private String phy_adr_desc;
	private String home_phn_num;
	private String work_phn_num;
	private String mobile_phn_num;
	private String email_adr_txt;
	private String ssn;
	private String cust_tax_idn_num;
	private String gndr_cd;
	private String martl_cd;
	private String lang_cd;
	private String acct_stat_cd;
	private String cust_brth_dt;
	private String acct_open_dt;
	private String sor_acct_stat_cd;
	private String sor_acct_stat_desc;
	private String vld_phn_num_ind;
	private String prod_cd;
	private String prft_ctr_cd;
	private String bus_legl_strc_cd;
	private String acct_use_cd;
	private String cntry_of_origin_cd;

	private String cust_grp_mbrp_id;
	private String ent_cust_id;
	private String cust_grp_cd;
	private String hh_cust_grp_mbrp_id;
	private String legl_afil_id;
	private String frst_nm;
	private String mid_nm;
	private String last_nm;
	private String acct_type_cd;
	private String acct_rel_stat_cd;
	
	private String nm_ind;

	public Long getSor_id() {
		return sor_id;
	}

	public void setSor_id(Long sor_id) {
		this.sor_id = sor_id;
	}

	public Long getSor_cust_id() {
		return sor_cust_id;
	}

	public void setSor_cust_id(Long sor_cust_id) {
		this.sor_cust_id = sor_cust_id;
	}

	public String getAcct_id() {
		return acct_id;
	}

	public void setAcct_id(String acct_id) {
		this.acct_id = acct_id;
	}

	public String getCust_role_type_cd() {
		return cust_role_type_cd;
	}

	public void setCust_role_type_cd(String cust_role_type_cd) {
		this.cust_role_type_cd = cust_role_type_cd;
	}

	public String getCust_full_nm() {
		return cust_full_nm;
	}

	public void setCust_full_nm(String cust_full_nm) {
		this.cust_full_nm = cust_full_nm;
	}

	public String getMailg_adr_line_1() {
		return mailg_adr_line_1;
	}

	public void setMailg_adr_line_1(String mailg_adr_line_1) {
		this.mailg_adr_line_1 = mailg_adr_line_1;
	}

	public String getMailg_adr_line_2() {
		return mailg_adr_line_2;
	}

	public void setMailg_adr_line_2(String mailg_adr_line_2) {
		this.mailg_adr_line_2 = mailg_adr_line_2;
	}

	public String getMailg_city_nm() {
		return mailg_city_nm;
	}

	public void setMailg_city_nm(String mailg_city_nm) {
		this.mailg_city_nm = mailg_city_nm;
	}

	public String getMailg_geo_st_cd() {
		return mailg_geo_st_cd;
	}

	public void setMailg_geo_st_cd(String mailg_geo_st_cd) {
		this.mailg_geo_st_cd = mailg_geo_st_cd;
	}

	public String getMailg_full_pstl_cd() {
		return mailg_full_pstl_cd;
	}

	public void setMailg_full_pstl_cd(String mailg_full_pstl_cd) {
		this.mailg_full_pstl_cd = mailg_full_pstl_cd;
	}

	public String getMailg_cntry_cd() {
		return mailg_cntry_cd;
	}

	public void setMailg_cntry_cd(String mailg_cntry_cd) {
		this.mailg_cntry_cd = mailg_cntry_cd;
	}

	public String getMailg_adr_desc() {
		return mailg_adr_desc;
	}

	public void setMailg_adr_desc(String mailg_adr_desc) {
		this.mailg_adr_desc = mailg_adr_desc;
	}

	public String getPhy_adr_line_1() {
		return phy_adr_line_1;
	}

	public void setPhy_adr_line_1(String phy_adr_line_1) {
		this.phy_adr_line_1 = phy_adr_line_1;
	}

	public String getPhy_adr_line_2() {
		return phy_adr_line_2;
	}

	public void setPhy_adr_line_2(String phy_adr_line_2) {
		this.phy_adr_line_2 = phy_adr_line_2;
	}

	public String getPhy_city_nm() {
		return phy_city_nm;
	}

	public void setPhy_city_nm(String phy_city_nm) {
		this.phy_city_nm = phy_city_nm;
	}

	public String getPhy_geo_st_cd() {
		return phy_geo_st_cd;
	}

	public void setPhy_geo_st_cd(String phy_geo_st_cd) {
		this.phy_geo_st_cd = phy_geo_st_cd;
	}

	public String getPhy_full_pstl_cd() {
		return phy_full_pstl_cd;
	}

	public void setPhy_full_pstl_cd(String phy_full_pstl_cd) {
		this.phy_full_pstl_cd = phy_full_pstl_cd;
	}

	public String getPhy_cntry_cd() {
		return phy_cntry_cd;
	}

	public void setPhy_cntry_cd(String phy_cntry_cd) {
		this.phy_cntry_cd = phy_cntry_cd;
	}

	public String getPhy_adr_desc() {
		return phy_adr_desc;
	}

	public void setPhy_adr_desc(String phy_adr_desc) {
		this.phy_adr_desc = phy_adr_desc;
	}

	public String getHome_phn_num() {
		return home_phn_num;
	}

	public void setHome_phn_num(String home_phn_num) {
		this.home_phn_num = home_phn_num;
	}

	public String getWork_phn_num() {
		return work_phn_num;
	}

	public void setWork_phn_num(String work_phn_num) {
		this.work_phn_num = work_phn_num;
	}

	public String getMobile_phn_num() {
		return mobile_phn_num;
	}

	public void setMobile_phn_num(String mobile_phn_num) {
		this.mobile_phn_num = mobile_phn_num;
	}

	public String getEmail_adr_txt() {
		return email_adr_txt;
	}

	public void setEmail_adr_txt(String email_adr_txt) {
		this.email_adr_txt = email_adr_txt;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getCust_tax_idn_num() {
		return cust_tax_idn_num;
	}

	public void setCust_tax_idn_num(String cust_tax_idn_num) {
		this.cust_tax_idn_num = cust_tax_idn_num;
	}

	public String getGndr_cd() {
		return gndr_cd;
	}

	public void setGndr_cd(String gndr_cd) {
		this.gndr_cd = gndr_cd;
	}

	public String getMartl_cd() {
		return martl_cd;
	}

	public void setMartl_cd(String martl_cd) {
		this.martl_cd = martl_cd;
	}

	public String getLang_cd() {
		return lang_cd;
	}

	public void setLang_cd(String lang_cd) {
		this.lang_cd = lang_cd;
	}

	public String getAcct_stat_cd() {
		return acct_stat_cd;
	}

	public void setAcct_stat_cd(String acct_stat_cd) {
		this.acct_stat_cd = acct_stat_cd;
	}

	public String getCust_brth_dt() {
		return cust_brth_dt;
	}

	public void setCust_brth_dt(String cust_brth_dt) {
		this.cust_brth_dt = cust_brth_dt;
	}

	public String getAcct_open_dt() {
		return acct_open_dt;
	}

	public void setAcct_open_dt(String acct_open_dt) {
		this.acct_open_dt = acct_open_dt;
	}

	public String getSor_acct_stat_cd() {
		return sor_acct_stat_cd;
	}

	public void setSor_acct_stat_cd(String sor_acct_stat_cd) {
		this.sor_acct_stat_cd = sor_acct_stat_cd;
	}

	public String getSor_acct_stat_desc() {
		return sor_acct_stat_desc;
	}

	public void setSor_acct_stat_desc(String sor_acct_stat_desc) {
		this.sor_acct_stat_desc = sor_acct_stat_desc;
	}

	public String getVld_phn_num_ind() {
		return vld_phn_num_ind;
	}

	public void setVld_phn_num_ind(String vld_phn_num_ind) {
		this.vld_phn_num_ind = vld_phn_num_ind;
	}

	public String getProd_cd() {
		return prod_cd;
	}

	public void setProd_cd(String prod_cd) {
		this.prod_cd = prod_cd;
	}

	public String getPrft_ctr_cd() {
		return prft_ctr_cd;
	}

	public void setPrft_ctr_cd(String prft_ctr_cd) {
		this.prft_ctr_cd = prft_ctr_cd;
	}

	public String getBus_legl_strc_cd() {
		return bus_legl_strc_cd;
	}

	public void setBus_legl_strc_cd(String bus_legl_strc_cd) {
		this.bus_legl_strc_cd = bus_legl_strc_cd;
	}

	public String getAcct_use_cd() {
		return acct_use_cd;
	}

	public void setAcct_use_cd(String acct_use_cd) {
		this.acct_use_cd = acct_use_cd;
	}

	public String getCntry_of_origin_cd() {
		return cntry_of_origin_cd;
	}

	public void setCntry_of_origin_cd(String cntry_of_origin_cd) {
		this.cntry_of_origin_cd = cntry_of_origin_cd;
	}

	public String getCust_grp_mbrp_id() {
		return cust_grp_mbrp_id;
	}

	public void setCust_grp_mbrp_id(String cust_grp_mbrp_id) {
		this.cust_grp_mbrp_id = cust_grp_mbrp_id;
	}

	public String getEnt_cust_id() {
		return ent_cust_id;
	}

	public void setEnt_cust_id(String ent_cust_id) {
		this.ent_cust_id = ent_cust_id;
	}

	public String getCust_grp_cd() {
		return cust_grp_cd;
	}

	public void setCust_grp_cd(String cust_grp_cd) {
		this.cust_grp_cd = cust_grp_cd;
	}

	public String getHh_cust_grp_mbrp_id() {
		return hh_cust_grp_mbrp_id;
	}

	public void setHh_cust_grp_mbrp_id(String hh_cust_grp_mbrp_id) {
		this.hh_cust_grp_mbrp_id = hh_cust_grp_mbrp_id;
	}

	public String getLegl_afil_id() {
		return legl_afil_id;
	}

	public void setLegl_afil_id(String legl_afil_id) {
		this.legl_afil_id = legl_afil_id;
	}

	public String getFrst_nm() {
		return frst_nm;
	}

	public void setFrst_nm(String frst_nm) {
		this.frst_nm = frst_nm;
	}

	public String getMid_nm() {
		return mid_nm;
	}

	public void setMid_nm(String mid_nm) {
		this.mid_nm = mid_nm;
	}

	public String getLast_nm() {
		return last_nm;
	}

	public void setLast_nm(String last_nm) {
		this.last_nm = last_nm;
	}

	public String getAcct_type_cd() {
		return acct_type_cd;
	}

	public void setAcct_type_cd(String acct_type_cd) {
		this.acct_type_cd = acct_type_cd;
	}

	public String getAcct_rel_stat_cd() {
		return acct_rel_stat_cd;
	}

	public void setAcct_rel_stat_cd(String acct_rel_stat_cd) {
		this.acct_rel_stat_cd = acct_rel_stat_cd;
	}

	public String getNm_ind() {
		return nm_ind;
	}

	public void setNm_ind(String nm_ind) {
		this.nm_ind = nm_ind;
	}
}