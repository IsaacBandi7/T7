package com.cap1.cdi.lucene;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.ScoreDoc;

import com.cap1.cdi.model.EcidEntity;
import com.cap1.cdi.util.BatchUtil;
import com.cap1.cdi.util.LuceneUtil;

/**
 * Class used to search the Lucene index to get the
 * cust_grp_cd,cust_grp_mbrp_id,ent_cust_id based on Four part key.
 * 
 * @author Deb Rout
 * @author Sankaraiah Narayanasamy
 */
public class SearchEcidEntityIndex {

	final static Logger LOG = Logger.getLogger(SearchEcidEntityIndex.class);
	private final static String indexField = "four_pk";

	public SearchEcidEntityIndex() {
	}

	/**
	 * Method used to search index files based on four part key and get the
	 * results.
	 * 
	 * @param searchInput
	 * @param sfCustomerFullName 
	 * @return EcidEntity
	 * @throws Exception
	 */
	public EcidEntity process(String searchInput) throws Exception {

		try {
			String indexPath = BatchUtil.getProperty("index.path");
			LuceneUtil luceneUtil = new LuceneUtil();
			IndexSearcher searcher = luceneUtil.getSearcher(indexPath);
			ScoreDoc[] matchedDocuments = luceneUtil.getMatchedDocuments(searcher, indexField, searchInput);
			EcidEntity lookup = new EcidEntity();
			for (int i = 0; i < matchedDocuments.length; ++i) {
				int docId = matchedDocuments[i].doc;
				Document d = searcher.doc(docId);
				final String entCustId = d.get("ent_cust_id");
				if (entCustId != null) {
					lookup.setEnt_cust_id(entCustId);
				}
				final String custGrpCd = d.get("cust_grp_cd");
				final String custGrpMbrpId = d.get("cust_grp_mbrp_id");
				if (custGrpCd != null && custGrpCd.equals("HH")) {
					lookup.setHh_cust_grp_mbrp_id(custGrpMbrpId);
				} else {
					if (custGrpCd != null) {
						lookup.setCust_grp_cd(custGrpCd);
					}
					if (custGrpMbrpId != null) {
						lookup.setCust_grp_mbrp_id(custGrpMbrpId);
					}
				}
			}
			return lookup;
		} catch (Exception e) {
			LOG.error(e);
			throw e;
		}
	}
}