package com.cap1.cdi.lucene;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.index.IndexWriter;

/**
 * Class used to index ECID and ENTITY files on different threads based on four
 * part key.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class IndexJob implements Runnable {

	final static Logger LOG = Logger.getLogger(IndexJob.class);
	private IndexWriter writer;
	private File file;
	private String delimiter;

	public IndexJob(IndexWriter writer, File file, String delimiter) {
		this.writer = writer;
		this.file = file;
		this.delimiter = delimiter;
	}

	@Override
	public void run() {

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			final String filePath = file.getPath();
			if (filePath.indexOf("ecida") != -1) {
				indexEcidFile(fis, filePath);
			} else if (filePath.indexOf("entitya") != -1) {
				indexEntityFile(fis, filePath);
			}
		} catch (FileNotFoundException fnfe) {
			LOG.error("", fnfe);
		}
	}

	/**
	 * Method used to index the Entity file and written into Lucene IndexWriter
	 * @param fis
	 * @param filePath 
	 */
	private void indexEntityFile(FileInputStream fis, String filePath) {

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(fis, Charset.forName("UTF-8")));

			Document doc = new Document();
			Field four_pk_Field = new StringField("four_pk", "", Field.Store.NO);
			doc.add(four_pk_Field);
			Field cust_grp_cd_Field = new StoredField("cust_grp_cd", "");
			Field cust_grp_mbrp_id_Field = new StoredField("cust_grp_mbrp_id", "");
			doc.add(cust_grp_cd_Field);
			doc.add(cust_grp_mbrp_id_Field);
			String line = null;
			while ((line = br.readLine()) != null) {

				String[] lineTokens = line.split("\\"+delimiter);
				String sor_id = new Integer(lineTokens[0]).toString();
				String sor_cust_id = new Long(lineTokens[1]).toString();
				String acct_id = lineTokens[2].replaceFirst("^0+(?!$)", "");
				String cust_role_type_cd = lineTokens[3];

				String four_pk = sor_id + sor_cust_id + acct_id + cust_role_type_cd;
				four_pk_Field.setStringValue(four_pk);

				String cust_grp_cd = lineTokens[4];
				cust_grp_cd_Field.setStringValue(cust_grp_cd);
				String cust_grp_mbrp_id = lineTokens[5];
				cust_grp_mbrp_id_Field.setStringValue(cust_grp_mbrp_id);
				writer.addDocument(doc);
			}
			br.close();
			writer.commit();
		} catch (FileNotFoundException fnfe) {
			LOG.error("", fnfe);
		} catch (IOException ioe) {
			LOG.error("", ioe);
		} catch (IndexOutOfBoundsException iobe) {
			LOG.debug(filePath);
			LOG.error("", iobe);
		} catch (Exception e) {
			LOG.error("", e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				LOG.error("", e);
			}
		}
	}

	/**
	 * Method used to index Ecid file and written into Lucene IndexWriter
	 * @param fis
	 * @param filePath 
	 */
	private void indexEcidFile(FileInputStream fis, String filePath) {

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(fis, Charset.forName("UTF-8")));

			Document doc = new Document();
			Field four_pk_Field = new StringField("four_pk", "", Field.Store.NO);
			doc.add(four_pk_Field);
			Field ent_cust_id_Field = new StoredField("ent_cust_id", "");
			doc.add(ent_cust_id_Field);
			String line = null;
			while ((line = br.readLine()) != null) {

				String[] lineTokens = line.split("\\"+delimiter);
				String sor_id = new Integer(lineTokens[0]).toString();
				String sor_cust_id = new Long(lineTokens[1]).toString();
				String acct_id = lineTokens[2].replaceFirst("^0+(?!$)", "");
				String cust_role_type_cd = lineTokens[3];

				String four_pk = sor_id + sor_cust_id + acct_id	+ cust_role_type_cd;
				four_pk_Field.setStringValue(four_pk);

				String ent_cust_id = lineTokens[6];
				ent_cust_id_Field.setStringValue(ent_cust_id);
				writer.addDocument(doc);
			}
			br.close();
			writer.commit();
		} catch (FileNotFoundException fnfe) {
			LOG.error("", fnfe);
		} catch (IOException ioe) {
			LOG.error("", ioe);
		} catch (IndexOutOfBoundsException iobe) {
			LOG.debug(filePath);
			LOG.error("", iobe);
		} catch (Exception e) {
			LOG.error("", e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				LOG.error("", e);
			}
		}
	}
}