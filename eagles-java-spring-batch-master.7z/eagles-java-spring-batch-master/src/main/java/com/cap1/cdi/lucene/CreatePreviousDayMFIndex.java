package com.cap1.cdi.lucene;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.apache.lucene.index.ConcurrentMergeScheduler;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.MergeScheduler;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import com.cap1.cdi.util.BatchUtil;
import com.cap1.cdi.util.LuceneUtil;

/**
 * Class used to index Previous day master file based on four part key.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class CreatePreviousDayMFIndex implements Tasklet, InitializingBean {

	final static Logger LOG = Logger.getLogger(CreatePreviousDayMFIndex.class);
	private Resource prevMFIndexPath;
	private Resource prevMFDocsPath;

	@Override
	public void afterPropertiesSet() throws Exception {

		Assert.notNull(prevMFIndexPath, "directory must be set");
		Assert.notNull(prevMFDocsPath, "directory must be set");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		long startTime = System.nanoTime();
		try {
			final File docDir = new File(prevMFDocsPath.getFile().getAbsolutePath());
			LOG.info("Indexing to directory '" + prevMFIndexPath + "'...");
			LuceneUtil luceneUtil = new LuceneUtil();
			IndexWriter indexWriter = luceneUtil.getIndexWriter(prevMFIndexPath);
			MergeScheduler ms = indexWriter.getConfig().getMergeScheduler();
			if (ms instanceof ConcurrentMergeScheduler) {
				((ConcurrentMergeScheduler) ms).setMaxMergesAndThreads(4, 4);
			}
			if (docDir.canRead()) {
				if (docDir.isDirectory()) {
					String[] files = docDir.list();
					if (files != null) {
						ExecutorService executor = Executors.newFixedThreadPool(4);
						final String delimiter = BatchUtil.getProperty("file.delimiter");
						for (int i = 0; i < files.length; i++) {
							Runnable indexJob = new PreviousDayMFIndexJob(
									indexWriter, new File(docDir, files[i]),
									delimiter);
							executor.submit(indexJob);
						}
						executor.shutdown();
						while (!executor.isTerminated()) {
						}
					}
				}
			}
			luceneUtil.closeIndexWriter(indexWriter, 2);
			LOG.debug(System.nanoTime() - startTime+" Total Nanoseconds - Completed Previous Day Master File Indexing");
		} catch (IOException ioe) {
			LOG.error("", ioe);
		} catch (Exception e) {
			LOG.error("", e);
		}
		return RepeatStatus.FINISHED;
	}

	public Resource getPrevMFIndexPath() {
		return prevMFIndexPath;
	}

	public void setPrevMFIndexPath(Resource prevMFIndexPath) {
		this.prevMFIndexPath = prevMFIndexPath;
	}

	public Resource getPrevMFDocsPath() {
		return prevMFDocsPath;
	}

	public void setPrevMFDocsPath(Resource prevMFDocsPath) {
		this.prevMFDocsPath = prevMFDocsPath;
	}
}
