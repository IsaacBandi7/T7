package com.cap1.cdi.batch.partitioner;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

/**
 * Be-Spoke class used to partition the reader based on the pool size configured
 * on the ThreadPoolTaskExecutor
 * 
 * @author Sankaraiah Narayanasamy
 */
public class MultiFileResourcePartitioner implements Partitioner,InitializingBean {

	private static final String DEFAULT_KEY_NAME = "fileName";

	private static final String PARTITION_KEY = "partition";

	private String keyName = DEFAULT_KEY_NAME;

	private String fileName = DEFAULT_KEY_NAME;

	private Resource directory;

	/**
	 * The name of the key for the file path in each {@link ExecutionContext}.
	 * @param keyName - the value of the key
	 */
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	/**
	 * The name of the key for the file name in each {@link ExecutionContext}.
	 * @param keyName - the value of the key
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * Assign the filename of each of the injected resources to an {@link ExecutionContext}.
	 * @see Partitioner#partition(int)
	 */
	public Map<String, ExecutionContext> partition(int gridSize) {
		Map<String, ExecutionContext> map = new HashMap<String, ExecutionContext>(gridSize);
		int i = 0;
		try {
			File dir = directory.getFile();
			if (dir.isDirectory()) {
				File[] files = dir.listFiles();
				for (File file : files) {
					if (!(file.getName().contains("ts2_cust_prfl_mstr_nrch")) && !(file.getName().contains("rcvr_cust_prfl_mstr_nrch"))) {
						ExecutionContext context = new ExecutionContext();
						context.putString(keyName, file.toURI().toString());
						context.putString(fileName, file.getName());
						map.put(PARTITION_KEY + i + ":" + file.getName(), context);
						i++;
					}
				}
			}
		} catch (Exception e) {
			throw new IllegalArgumentException("File could not be located for: " + e);
		}
		return map;
	}

	public void setDirectory(Resource directory) {
		this.directory = directory;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(directory, "directory must be set");
	}
}
