package com.cap1.cdi.batch.script;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.cap1.cdi.util.BatchUtil;

/**
 * Tasklet used to run the shell script which will do file split and some
 * cleanup activities.
 * 
 * @author Sankaraiah Narayanasamy
 *
 */
public class CDIMasterInitialScript implements Tasklet {

	final static Logger LOG = Logger.getLogger(CDIMasterInitialScript.class);

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {

		try {
			LOG.debug("File Splitting started");
			final String initialScriptLocation = BatchUtil.getProperty("cdi.batch.initial.script");
			final ProcessBuilder pb = new ProcessBuilder(initialScriptLocation);
			final Process p = pb.start();
			p.waitFor();
			LOG.debug("File Splitting Completed");
		} catch (Exception e) {
			LOG.error("Error while executing Shell Script", e);
		}
		return RepeatStatus.FINISHED;
	}
}
