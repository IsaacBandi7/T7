package com.capitalone.api.dms.redispatcher.config;

import java.net.UnknownHostException;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;

import com.capitalone.api.dms.redispatcher.OAuth2.EncryptedSecuredDatum;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadPreference;
import com.mongodb.WriteConcern;

/**
 * Spring MongoDB configuration file
 * 
 */
@Configuration
// @EnableAutoConfiguration
@ComponentScan(basePackages = { "com.capitalone.api.dms.redispatcher" })
@EnableAsync
public class ReDispatcherConfig {
	private static Logger logger = LoggerFactory
			.getLogger(ReDispatcherConfig.class);
	@Inject
	private EncryptedSecuredDatum crypto;

	// @Value("${totalRetryAllowed}")
	private String totalRetryAllowed;



	@Value("${retryErrorCodes}")
	private String retryErrorCodes;

	@Value("${jaxrs.connection.timeout}")
	private String connectionTimeout;

	@Value("${jaxrs.request.timeout}")
	private String requestTimeout;

	@Value("${mongodb.databasename}")
	String databaseName;

	@Value("${mongodb.password}")
	String pwd;

	@Value("${mongodb.username}")
	String username;

	@Value("${mongodb.replica.enabled}")
	String replicaEnabled;

	@Value("${mongodb.replica.name}")
	String replicaSetName;

	@Value("${mongodb.addresses}")
	String addresses;

	@Value("${mongodb.authentication.database}")
	String authdatabase;

	@Value("${mongodb.auth.mechanism}")
	String authMechanism;

	@Value("${mongodb.socket.timeout}")
	private String mongoSocketTimeOut;

	@Value("${mongodb.connect.timeout}")
	private String mongoConnectTimeOut;

	@Value("${mongodb.min.connection.host}")
	String minConnectionForHost;

	@Value("${mongodb.max.connection.host}")
	String maxConnectionForHost;

	@Value("${mongodb.connection.separator}")
	String uriConnectionSeparator = "&";



	@Value("${messageDispatcherURL}")
	private String apiGWMessageDispURL;

	

	
	public String getTotalRetryAllowed() {
		return totalRetryAllowed;
	}

	public void setTotalRetryAllowed(String totalRetryAllowed) {
		this.totalRetryAllowed = totalRetryAllowed;
	}

	public String getRetryErrorCodes() {
		return retryErrorCodes;
	}

	public void setRetryErrorCodes(String retryErrorCodes) {
		this.retryErrorCodes = retryErrorCodes;
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	// To be removed after using dms-mongo jars

	/**
	 * Exposed Mongo instance to support the older version of Mongo by wrapping
	 * MongoClient.
	 * 
	 * @return Returns Mongo object from MongoClient
	 * @throws UnknownHostException
	 */
	@Bean
	public Mongo mongo() throws UnknownHostException {
		return createMongo();
	}

	/**
	 * Internal Method called to generate Mongo Client.
	 * 
	 * @return Returns MongoClient object
	 * @throws UnknownHostException
	 */
	private MongoClient createMongo() throws UnknownHostException {
		MongoClient mongoClient = new MongoClient(getMongoURI());
		if ("Y".equalsIgnoreCase(replicaEnabled)) {
			mongoClient.setReadPreference(ReadPreference.primaryPreferred());
			mongoClient.setWriteConcern(WriteConcern.REPLICAS_SAFE);
		} else {
			mongoClient.setWriteConcern(WriteConcern.SAFE);
		}
		return mongoClient;
	}

	/**
	 * This method constructs the MongoClientURI from the specified parameters.
	 * 
	 * @return Returns the MongoClientURI Object.
	 */
	public MongoClientURI getMongoURI() {
		return new MongoClientURI(getDBURI());
	}

	protected String getDBURI() {
		if (StringUtils.isBlank(uriConnectionSeparator)) {
			uriConnectionSeparator = "&";
		}
		StringBuilder sb = new StringBuilder();
		sb.append("mongodb://");
		sb.append(username);
		sb.append(":");
		sb.append(getDecryptedPassword());
		sb.append("@");
		sb.append(addresses);
		sb.append("/");
		sb.append("?authSource=");
		sb.append(authdatabase);
		sb.append(uriConnectionSeparator);
		sb.append("authMechanism=");
		sb.append(StringUtils.isNotBlank(authMechanism) ? authMechanism
				: "SCRAM-SHA-1");

		if ("Y".equalsIgnoreCase(replicaEnabled)) {
			sb.append(uriConnectionSeparator);
			sb.append("replicaSet=");
			sb.append(replicaSetName);
		}

		sb.append(uriConnectionSeparator);
		sb.append("connectTimeoutMS=");
		sb.append(StringUtils.isNotBlank(mongoConnectTimeOut) ? mongoConnectTimeOut
				: 10000);
		sb.append(uriConnectionSeparator);
		sb.append("socketTimeoutMS=");
		sb.append(StringUtils.isNotBlank(mongoSocketTimeOut) ? mongoSocketTimeOut
				: 300000);
		sb.append(uriConnectionSeparator);
		sb.append("minPoolSize=");
		sb.append(StringUtils.isNotBlank(minConnectionForHost) ? minConnectionForHost
				: 5);
		sb.append(uriConnectionSeparator);
		sb.append("maxPoolSize=");
		sb.append(StringUtils.isNotBlank(maxConnectionForHost) ? maxConnectionForHost
				: 100);

		logger.debug("Mongo Connection String @ " + this.getClass().getName()
				+ "----> {} " + sb);

		return sb.toString();
	}

	/**
	 * This method decrypts the password.
	 * 
	 * @return Returns the decrypted password.
	 */
	public String getDecryptedPassword() {

		// logger.debug("Password {}",crypto.encryptBase64Encode(pwd));
		return this.crypto.decryptBase64Encoded(pwd);
	}

	public String getConnectionTimeout() {
		return connectionTimeout;
	}

	public void setConnectionTimeout(String connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	public String getRequestTimeout() {
		return requestTimeout;
	}

	public void setRequestTimeout(String requestTimeout) {
		this.requestTimeout = requestTimeout;
	}

	public String getApiGWMessageDispURL() {
		return apiGWMessageDispURL;
	}

	public void setApiGWMessageDispURL(String apiGWMessageDispURL) {
		this.apiGWMessageDispURL = apiGWMessageDispURL;
	}



	public String getMongoConnectTimeOut() {
		return mongoConnectTimeOut;
	}

	public void setMongoConnectTimeOut(String mongoConnectTimeOut) {
		this.mongoConnectTimeOut = mongoConnectTimeOut;
	}

	public String getMongoSocketTimeOut() {
		return mongoSocketTimeOut;
	}

	public void setMongoSocketTimeOut(String mongoSocketTimeOut) {
		this.mongoSocketTimeOut = mongoSocketTimeOut;
	}


}
