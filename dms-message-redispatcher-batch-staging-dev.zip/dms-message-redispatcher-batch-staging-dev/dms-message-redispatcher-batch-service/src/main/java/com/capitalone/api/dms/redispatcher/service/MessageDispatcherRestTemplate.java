package com.capitalone.api.dms.redispatcher.service;


import java.nio.charset.Charset;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

public class MessageDispatcherRestTemplate  extends RestTemplate{
	
	private static final Logger LOGGER = LoggerFactory
	            .getLogger(MessageDispatcherRestTemplate.class);
	 

	private  static Integer requestTimeOut;
	
	private  static Integer totalMaxConnections;
	private  static Integer maxConnectionPerRoute;
	
	

	/**
	 * @return the requestTimeOut
	 */
	public static Integer getRequestTimeOut() {
		return requestTimeOut;
	}

	/**
	 * @param requestTimeOut the requestTimeOut to set
	 */
	public static void setRequestTimeOut(Integer requestTimeOut) {
		MessageDispatcherRestTemplate.requestTimeOut = requestTimeOut;
	}

	/**
	 * @return the totalMaxConnections
	 */
	public static Integer getTotalMaxConnections() {
		return totalMaxConnections;
	}

	/**
	 * @param totalMaxConnections the totalMaxConnections to set
	 */
	public static void setTotalMaxConnections(Integer totalMaxConnections) {
		MessageDispatcherRestTemplate.totalMaxConnections = totalMaxConnections;
	}

	/**
	 * @return the maxConnectionPerRoute
	 */
	public static Integer getMaxConnectionPerRoute() {
		return maxConnectionPerRoute;
	}

	/**
	 * @param maxConnectionPerRoute the maxConnectionPerRoute to set
	 */
	public static void setMaxConnectionPerRoute(Integer maxConnectionPerRoute) {
		MessageDispatcherRestTemplate.maxConnectionPerRoute = maxConnectionPerRoute;
	}

	public MessageDispatcherRestTemplate(Integer requestTimeOut,Integer totalMaxConnections,Integer maxConnectionPerRoute)  {
		super(createBatchHttpRequestFactory(requestTimeOut,totalMaxConnections,maxConnectionPerRoute));
		List<HttpMessageConverter<?>> messageConverters= new ArrayList<HttpMessageConverter<?>>();
		messageConverters.addAll(getMessageConverters());
		messageConverters.add(0,new StringHttpMessageConverter(Charset.forName("UTF-8")));
		setMessageConverters(messageConverters);
   	
	}
	
	private static ClientHttpRequestFactory createBatchHttpRequestFactory(Integer requestTimeOut, Integer totalMaxConnections, Integer maxConnectionPerRoute)  {
		    
	        CloseableHttpClient httpClient;
	        HttpComponentsClientHttpRequestFactory httpRequestFactory;
	        
	        SSLConnectionSocketFactory socketFactory;
			try {
				
				SSLContext sslcontext = SSLContext.getInstance("TLS");
				sslcontext.init(null, new TrustManager[] { new X509TrustManager() {
					@Override
					public void checkClientTrusted(X509Certificate[] arg0,
							String arg1) throws CertificateException {
					}

					@Override
					public void checkServerTrusted(X509Certificate[] arg0,
							String arg1) throws CertificateException {
					}

					@Override
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						return new X509Certificate[0];
					}

				} }, new java.security.SecureRandom());
				
				
				
				socketFactory = new SSLConnectionSocketFactory(
						sslcontext,
				        new String[] {"TLSv1"},
				        null,
				        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			
	        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
	                .register("http", PlainConnectionSocketFactory.getSocketFactory())
	                .register("https", socketFactory)
	                .build();
	        PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
	        cm.setMaxTotal(totalMaxConnections);
	        cm.setDefaultMaxPerRoute(maxConnectionPerRoute);
	        cm.closeExpiredConnections();
	       

	        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(requestTimeOut)
	                .setConnectionRequestTimeout(requestTimeOut).setSocketTimeout(requestTimeOut).build();
	       


	        httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setConnectionManager(cm).build();
	        

	        httpRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
	        return httpRequestFactory;
	        
			}
			
			catch (Exception e) {
				 LOGGER.error("error exception", e);
				
	
	}
			return null; 
	}
	
	

}
