package com.capitalone.api.dms.redispatcher.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

public class LoggingRequestInterceptor implements ClientHttpRequestInterceptor {
	private static Logger logger = LoggerFactory
			.getLogger(LoggingRequestInterceptor.class);

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body,
			ClientHttpRequestExecution execution) throws IOException {

		traceRequest(request, body);
		ClientHttpResponse response = execution.execute(request, body);
	//	traceResponse(response);
		return response;
	}

	private void traceRequest(HttpRequest request, byte[] body)
			throws IOException {
		if (logger.isDebugEnabled()) {
			logger.debug("===========================request begin================================================");

			logger.debug("URI : " + request.getURI());
			logger.debug("Method : " + request.getMethod());
			logger.debug("Request Body : " + new String(body, "UTF-8"));
			logger.debug("==========================request end================================================");
		}
	}
/*
	private void traceResponse(ClientHttpResponse response) throws IOException {
		if (logger.isDebugEnabled()) {

			StringBuilder inputStringBuilder = new StringBuilder();
			if (response.getStatusCode().is2xxSuccessful()) {
				BufferedReader bufferedReader = new BufferedReader(
						new InputStreamReader(response.getBody(), "UTF-8"));
				String line = bufferedReader.readLine();
				while (line != null) {
					inputStringBuilder.append(line);
					inputStringBuilder.append('\n');
					line = bufferedReader.readLine();
				}

				logger.debug("============================response begin==========================================");
				logger.debug("status code: " + response.getStatusCode());
				logger.debug("status text: " + response.getStatusText());
				logger.debug("Response Body : " + inputStringBuilder.toString());
				logger.debug("=======================response end=================================================");
				bufferedReader.close();

			} else {
				logger.debug("============================response begin==========================================");
				logger.debug("status code: " + response.getStatusCode());
				logger.debug("status text: " + response.getStatusText());

			}
		}
	}
*/
}
