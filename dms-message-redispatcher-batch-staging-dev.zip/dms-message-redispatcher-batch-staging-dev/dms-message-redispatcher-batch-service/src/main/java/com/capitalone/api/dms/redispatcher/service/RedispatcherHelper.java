package com.capitalone.api.dms.redispatcher.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import javax.inject.Named;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.capitalone.api.dms.redispatcher.RedispatcherConstants;
import com.capitalone.api.dms.redispatcher.dao.MessageDispatcherDao;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

@Named
public class RedispatcherHelper {

	@Autowired 
	protected MongoTemplate mongoTemplate;
	@Autowired 
	private MessageDispatcherDao messageDispatcherDao;

	private static Logger logger = LoggerFactory
			.getLogger(RedispatcherHelper.class);

	public String healthCheck() {
		try {
			boolean checkIfExists = mongoTemplate
					.collectionExists(RedispatcherConstants.ALRT_HIST_COLL_NAME);
			logger.info("Health Check Status,Collection exists {}",
					checkIfExists);
			messageDispatcherDao.healthCheck();
			return "PING_SUCCESS";
		} catch (Exception exception) {
			logger.error("Health check {}", exception);
			return "PING_FAILED";
		}

	}

	// Convert the ; separated properties to list
	public List<String> convertPropertyToList(String propertyValue) {
		List<String> valueList = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(propertyValue, ";");
		while (st.hasMoreElements()) {
			valueList.add((String) st.nextElement());
		}
		return valueList;
	}

	// Get the last Job Run date from redispatcher Control table
	public String getLastJobRunDate() {
		MongoOperations mongoOperations = mongoTemplate;
		Date date = null;
		DBObject dbObject = mongoOperations.getCollection(
				RedispatcherConstants.RDSP_CTRL_COLL_NAME).findOne(
				new BasicDBObject(), null,
				new BasicDBObject("lastJobRunDate", -1));
		if (dbObject != null && dbObject.get("lastJobRunDate") != null) {
			date = (Date) dbObject.get("lastJobRunDate");
		} else {
			// Last Job Run date is not returned then
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MINUTE, -15);
			date = cal.getTime();
			if (!mongoOperations
					.collectionExists(RedispatcherConstants.RDSP_CTRL_COLL_NAME)) {
				mongoOperations
						.createCollection(RedispatcherConstants.RDSP_CTRL_COLL_NAME);

			}
			/*
			mongoOperations.getCollection(
					RedispatcherConstants.RDSP_CTRL_COLL_NAME).insert(
					new BasicDBObject("lastJobRunDate", date));
					*/
		}

		DateTime dateTime = new DateTime(date, DateTimeZone.UTC);
		logger.debug("Last Job Run date in helper {}", dateTime.toString());
		return dateTime.toString();
	}

	public void updateLastJobRunDate(String lastJobRunDate) {
		MongoOperations mongoOperations = mongoTemplate;
		DateTime dateTime = DateTime.parse(lastJobRunDate);
		BasicDBObject updateQuery = new BasicDBObject();
		updateQuery
				.append("$set",
						new BasicDBObject().append("lastJobRunDate",
								dateTime.toDate()));

		mongoOperations.upsert(new Query(),
				Update.update("lastJobRunDate", dateTime.toDate()),
				RedispatcherConstants.RDSP_CTRL_COLL_NAME);
		/*
		 * mongoOperations
		 * .getCollection(RedispatcherConstants.RDSP_CTRL_COLL_NAME) .update(
		 * new BasicDBObject(),updateQuery);
		 */logger.debug("Last Job Run date Update in helper {}",
				dateTime.toString());

	}

	// Get Current date in UTC
	public String getCurrentDateUTC() {
		DateTime dateTimeUtc = DateTime.now(DateTimeZone.UTC);
		return dateTimeUtc.toString();
	}

}
