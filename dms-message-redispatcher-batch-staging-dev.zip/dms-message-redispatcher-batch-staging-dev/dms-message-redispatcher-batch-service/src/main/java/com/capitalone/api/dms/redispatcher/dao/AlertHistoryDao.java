package com.capitalone.api.dms.redispatcher.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.capitalone.api.dms.redispatcher.RedispatcherConstants;
import com.capitalone.api.dms.redispatcher.config.ReDispatcherConfig;
import com.capitalone.api.dms.redispatcher.service.RedispatcherHelper;
import com.mongodb.AggregationOptions;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;

import static java.util.concurrent.TimeUnit.MILLISECONDS;

@StepScope
public class AlertHistoryDao {

	@Inject
	MongoTemplate mongoTemplate;

	@Inject
	private ReDispatcherConfig configBean;

	@Inject
	private RedispatcherHelper redispatcherHelper;

	private String dbBatchsize;
	private String totalRetryAllowed;

	private static Logger logger = LoggerFactory
			.getLogger(AlertHistoryDao.class);

	public Cursor getAlertHistory(String savedDatetime) {

	//	String alertsAllowed = configBean.getAlertsAllowed();
		
		String retryErrorCodes = configBean.getRetryErrorCodes();
		int batchSize = Integer.valueOf(dbBatchsize);
		long maxRetryAllowed = Integer.valueOf(totalRetryAllowed);

	//	logger.debug("Alerts allowed for redispatcher {}", alertsAllowed);
		logger.debug("Total retry count allowed {}", maxRetryAllowed);
		logger.debug("Retry Error Codes {}", retryErrorCodes);
		logger.debug("Batch Size {}", batchSize);

//		List<String> alertsAllowedList = redispatcherHelper
	//			.convertPropertyToList(alertsAllowed);
		List<String> errorCodes = redispatcherHelper
				.convertPropertyToList(retryErrorCodes);
		DateTimeFormatter formatter = DateTimeFormat
				.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
				.withLocale(Locale.ROOT)
				.withChronology(ISOChronology.getInstanceUTC());
		DateTime datetime = formatter.parseDateTime(savedDatetime);
		Date date = datetime.toDate();

		/*
		 * Decision was to use createdTimeStamp >= of the last processed record
		 * to avoid breaking of batch in the middle that has same
		 * createdTimeStamp. Added time range to improve query performance
		 */
		logger.debug("lastJobRuntime to history dao {}", date.toString());
		List<DBObject> pipeline = new ArrayList<DBObject>();

		DBObject dateQuery = new BasicDBObject();
		dateQuery.put("$gte", date);
		dateQuery.put("$lte", new Date());

		DBObject dateRange = new BasicDBObject();
		dateRange.put("createdTimeStamp",dateQuery);

		//DBObject andQuery = new BasicDBObject(and);

	//	andQuery.put("alertTypeCode", new BasicDBObject("$in",
	//			alertsAllowedList));

		DBObject matchDBO = new BasicDBObject("$match", dateRange);
		pipeline.add(matchDBO);
		DBObject groupFields = new BasicDBObject("_id", "$alertTrackingId");
		groupFields.put("alertSentTimeStamp", new BasicDBObject("$max",
				"$alertSentTimeStamp"));
		groupFields.put("alertTrackingId", new BasicDBObject("$last",
				"$alertTrackingId"));
		groupFields.put("sorId", new BasicDBObject("$last", "$sorId"));
		groupFields.put("accountId", new BasicDBObject("$last", "$accountId"));
		groupFields
				.put("customerId", new BasicDBObject("$last", "$customerId"));
		groupFields.put("messageText", new BasicDBObject("$last",
				"$messageText"));
		groupFields.put("enterpriseLineOfBusiness", new BasicDBObject("$last",
				"$enterpriseLineOfBusiness"));
		groupFields.put("alertTypeCode", new BasicDBObject("$last",
				"$alertTypeCode"));
		groupFields.put("classificationId", new BasicDBObject("$last",
				"$classificationId"));
		groupFields.put("contactPointValue", new BasicDBObject("$last",
				"$contactPointValue"));
		groupFields.put("contactPointId", new BasicDBObject("$last",
				"$contactPointId"));
		groupFields.put("cyclDt", new BasicDBObject("$last", "$cyclDt"));
		groupFields.put("contactPointType", new BasicDBObject("$last",
				"$contactPointType"));
		groupFields.put("messagingCustomerId", new BasicDBObject("$last",
				"$messagingCustomerId"));
		groupFields.put("alertDeliveryVendorId", new BasicDBObject("$last",
				"$alertDeliveryVendorId"));
		groupFields
				.put("templateId", new BasicDBObject("$last", "$templateId"));
		groupFields.put("vendorResponseStatus", new BasicDBObject("$last",
				"$vendorResponseStatus"));
		groupFields.put("languageCode", new BasicDBObject("$last",
				"$languageCode"));
		groupFields.put("ssoId", new BasicDBObject("$last", "$ssoId"));
		groupFields
				.put("thldValTxt", new BasicDBObject("$last", "$thldValTxt"));
		groupFields.put("last4DigitsCardNumber", new BasicDBObject("$last",
				"$last4DigitsCardNumber"));
		groupFields.put("productDescription", new BasicDBObject("$last",
				"$productDescription"));
		groupFields.put("createdTimeStamp", new BasicDBObject("$last",
				"$createdTimeStamp"));
		groupFields.put("vendorResponseErrorCode", new BasicDBObject("$last",
				"$vendorResponseErrorCode"));
		groupFields.put("messageRetryCount", new BasicDBObject("$max",
				"$messageRetryCount"));
		groupFields.put("templateLookupCode", new BasicDBObject("$last",
				"$templateLookupCode"));
		groupFields.put("messageFormat", new BasicDBObject("$last",
				"$messageFormat"));
		groupFields.put("vendorTrackingId", new BasicDBObject("$last",
				"$vendorTrackingId"));
		groupFields.put("msgEvtRsltReasId", new BasicDBObject("$last",
				"$msgEvtRsltReasId"));
		DBObject groupDBO = new BasicDBObject("$group", groupFields);
		pipeline.add(groupDBO);

		DBObject andQuery2 = new BasicDBObject();
		andQuery2.put("vendorResponseStatus", "INP");
		andQuery2.put("vendorResponseErrorCode", new BasicDBObject("$in",
				errorCodes));
		andQuery2.put("messageRetryCount", new BasicDBObject("$lt",
				maxRetryAllowed));

		DBObject match2 = new BasicDBObject("$match", andQuery2);
		pipeline.add(match2);
	
		DBCollection coll = mongoTemplate
				.getCollection(RedispatcherConstants.ALRT_HIST_COLL_NAME);
		AggregationOptions aggregationOptions = AggregationOptions
				.builder()
				.maxTime(Long.valueOf(configBean.getMongoSocketTimeOut()),
						MILLISECONDS).batchSize(batchSize)
				.outputMode(AggregationOptions.OutputMode.CURSOR)
				.allowDiskUse(true).build();

		Cursor cursor = coll.aggregate(pipeline, aggregationOptions,
				ReadPreference.primaryPreferred());

		return cursor;

	}

	public String getDbBatchsize() {
		return dbBatchsize;
	}

	public void setDbBatchsize(String dbBatchsize) {
		this.dbBatchsize = dbBatchsize;
	}

	public String getTotalRetryAllowed() {
		return totalRetryAllowed;
	}

	public void setTotalRetryAllowed(String totalRetryAllowed) {
		this.totalRetryAllowed = totalRetryAllowed;
	}
}
