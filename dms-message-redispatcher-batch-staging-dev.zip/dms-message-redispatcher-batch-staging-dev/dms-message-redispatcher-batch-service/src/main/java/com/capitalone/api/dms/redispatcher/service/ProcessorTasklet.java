package com.capitalone.api.dms.redispatcher.service;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.capitalone.api.dms.redispatcher.dao.AlertHistoryDao;
import com.capitalone.api.dms.redispatcher.model.MessageDispatcherRequest;
import com.google.common.collect.Lists;
import com.google.common.math.IntMath;
import com.mongodb.Cursor;
import com.mongodb.DBObject;
import com.mongodb.MongoException;

public class ProcessorTasklet implements Tasklet {
	private Map<String, Object> dataMap;

	@Inject
	private AlertHistoryDao alertHistoryDao;

	@Inject
	MongoTemplate mongoTemplate;
	@Inject
	private MessageDispatcherService messageDispatcherService;

	private static Logger logger = LoggerFactory
			.getLogger(ProcessorTasklet.class);
	private String dbBatchsize;
	private Cursor cursor;
	private int gridSize;

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {

		long currentTime = System.currentTimeMillis();
		logger.debug("Entered Inside Partitioner {}", currentTime);
		long batchSize = Integer.valueOf(dbBatchsize);
		cursor = (Cursor) dataMap.get("cursor");

		/*
		 * First time when the cursor is null read Mongo to get records. This
		 * will occur every time Job is started.
		 */
		if (cursor == null) {
			try {
				String savedDatetime = (String) dataMap.get("lastJobRunDate");
				logger.debug("lastJobRuntime in Partitioner {}", savedDatetime);
				cursor = alertHistoryDao.getAlertHistory(savedDatetime);
				dataMap.put("cursor", cursor);
			} catch (Exception e) {
				dataMap.clear();
				logger.error("*****Error reading records from Mongo**** {}", e);
				throw new Exception(e);
			}

		}

		List<MessageDispatcherRequest> alertHistoryList = new ArrayList<MessageDispatcherRequest>();
		/*
		 * Iterate cursor until the the batch size reached.
		 */
		try {
			while (cursor.hasNext() && alertHistoryList.size() < batchSize) {
				DBObject doc = cursor.next();
				logger.debug("Cursor Result set {}", doc.toString());
				alertHistoryList.add(mongoTemplate.getConverter().read(
						MessageDispatcherRequest.class, doc));
			}
		} catch (MongoException exception) {
			// If the Cursor timed out Exception occurs remove cursor
			dataMap.remove("cursor");
			dataMap.put("hasMoreRecords", "true");
			logger.error("Cursor expired.");
		}
		logger.debug("Cursor Result set size {}", alertHistoryList.size());
		logger.debug("Partitioner grid size {}", gridSize);

		List<List<MessageDispatcherRequest>> partitions = null;
		// Split the batch records to equal chunk of grid size
		if (alertHistoryList.size() > 0) {
			// Set this flag to loop until the last record
			dataMap.put("hasMoreRecords", "true");
			int partitionSize = IntMath.divide(alertHistoryList.size(),
					gridSize, RoundingMode.UP);
			partitions = Lists.partition(alertHistoryList, partitionSize);
			List<Future<Object>> futures = new ArrayList<Future<Object>>();
			try {
				for (List<MessageDispatcherRequest> partition : partitions) {
					Future<Object> future = messageDispatcherService
							.sendMessages(partition);
					futures.add(future);
				}
				// Wait for the results
				for (Future<Object> future : futures) {
					// fetch the result
					future.get();
				}
			} catch (Exception e) {
				dataMap.clear();
				logger.error("*****Message dispatcher error****");
				throw new Exception(e);
			}
		} else {
			if (null != cursor) {
				cursor.close();
			}
			dataMap.put("hasMoreRecords", "false");
		}

		logger.debug("Exit Partitioner {}", System.currentTimeMillis()
				- currentTime);

		return RepeatStatus.FINISHED;
	}

	public void setDataMap(Map<String, Object> dataMap) {
		this.dataMap = dataMap;
	}

	public int getGridSize() {
		return gridSize;
	}

	public void setGridSize(int gridSize) {
		this.gridSize = gridSize;
	}

	public String getDbBatchsize() {
		return dbBatchsize;
	}

	public void setDbBatchsize(String dbBatchsize) {
		this.dbBatchsize = dbBatchsize;
	}
}
