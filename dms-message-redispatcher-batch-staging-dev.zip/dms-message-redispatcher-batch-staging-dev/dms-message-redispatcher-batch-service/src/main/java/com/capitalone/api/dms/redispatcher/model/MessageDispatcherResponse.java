package com.capitalone.api.dms.redispatcher.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MessageDispatcherResponse {

	private BigDecimal contactPointId;

	private String contactPointValue;

	private DeliveryResponse deliveryResponse;

	public BigDecimal getContactPointId() {
		return contactPointId;
	}

	public void setContactPointId(BigDecimal contactPointId) {
		this.contactPointId = contactPointId;
	}

	public String getContactPointValue() {
		return contactPointValue;
	}

	public void setContactPointValue(String contactPointValue) {
		this.contactPointValue = contactPointValue;
	}

	public DeliveryResponse getDeliveryResponse() {
		return deliveryResponse;
	}

	public void setDeliveryResponse(DeliveryResponse deliveryResponse) {
		this.deliveryResponse = deliveryResponse;
	}
}
