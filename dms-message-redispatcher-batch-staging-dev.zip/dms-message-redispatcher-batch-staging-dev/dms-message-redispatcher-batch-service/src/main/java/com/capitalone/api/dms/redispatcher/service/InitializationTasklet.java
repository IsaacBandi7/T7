package com.capitalone.api.dms.redispatcher.service;

import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;


public class InitializationTasklet implements Tasklet, StepExecutionListener {

	@Inject
	private RedispatcherHelper redispatcherHelper;

	private static Logger logger = LoggerFactory
			.getLogger(InitializationTasklet.class);

	/** Databean. */
	private Map<String, Object> dataMap;
	private String healthCheckStatus;
	private String pingOnlyFlag;


	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
			String savedDatetime = null;

			/**
			 * If Ping only flag is set to true in the definition file then only run the ping Operation.
			 * 
			 */
			if(StringUtils.equalsIgnoreCase(pingOnlyFlag, "true"))
			{
				healthCheckStatus = redispatcherHelper.healthCheck();
			}
		
			// Check if the Last Job run date exist in the context
			else
			{
			if (null == dataMap.get("lastJobRunDate")) {
				logger.info("*******************Starting Redispatcher***************");
				// Read and update  current date from redispatcher Control table
				try {
					savedDatetime = redispatcherHelper.getLastJobRunDate();	
				dataMap.put("lastJobRunDate", savedDatetime);
				dataMap.put("currentJobStartDate",
						redispatcherHelper.getCurrentDateUTC());
				logger.debug("Last job run date time {}", savedDatetime);
				
				} catch (Exception e) {
					logger.error("Error retrieving last job run date {}  ", e.getMessage());
					healthCheckStatus="JOB_FAILED";
					}
			}

		}

		return RepeatStatus.FINISHED;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {

		// logger.info("!!!!!!!!!!!Entered Before step in AlertHistoryDAOTasklet");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		String savedDatetime = null;
		if (StringUtils.equals(healthCheckStatus, "PING_FAILED")) {
			dataMap.clear();
			return new ExitStatus("PING_FAILED");
		}
		if (StringUtils.equals(healthCheckStatus, "PING_SUCCESS")) {
			dataMap.clear();
			return new ExitStatus("PING_SUCCESS");
		}
	
		if (StringUtils.equals(healthCheckStatus, "JOB_FAILED")) {
			dataMap.clear();
			return new ExitStatus("JOB_FAILED");
		}
		
		// Check if More records exists to process
		String hasMoreRecords = (String) dataMap.get("hasMoreRecords");

		if (StringUtils.equals(hasMoreRecords, "false")) {
			// Get the current job Start date time
			if (null != dataMap.get("currentJobStartDate")) {
				savedDatetime = (String) dataMap.get("currentJobStartDate");
				redispatcherHelper.updateLastJobRunDate(savedDatetime);
			}

			dataMap.clear();
			logger.debug("*******************Redispatcher Job Completed***************");
			return new ExitStatus("NO_RECORD");
		} else
			return ExitStatus.COMPLETED;

	}

	public void setDataMap(Map<String, Object> dataMap) {
		this.dataMap = dataMap;
	}
	public String getPingOnlyFlag() {
		return pingOnlyFlag;
	}

	public void setPingOnlyFlag(String pingOnlyFlag) {
		this.pingOnlyFlag = pingOnlyFlag;
	}

}
