package com.capitalone.api.dms.redispatcher.model;

import java.util.List;

public class MessageDispatcherResponses {

	private List<MessageDispatcherResponse> messageDispatcherResponse;

	public List<MessageDispatcherResponse> getMessageDispatcherResponse() {
		return messageDispatcherResponse;
	}

	public void setMessageDispatcherResponse(
			List<MessageDispatcherResponse> messageDispatcherResponse) {
		this.messageDispatcherResponse = messageDispatcherResponse;
	}
}
