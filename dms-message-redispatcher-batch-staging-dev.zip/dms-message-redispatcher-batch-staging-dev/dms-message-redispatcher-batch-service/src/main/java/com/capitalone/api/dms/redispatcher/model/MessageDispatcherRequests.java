package com.capitalone.api.dms.redispatcher.model;

import java.util.List;

public class MessageDispatcherRequests {

	private List<MessageDispatcherRequest> messageDispatcher;

	public List<MessageDispatcherRequest> getMessageDispatcher() {
		return messageDispatcher;
	}

	public void setMessageDispatcher(
			List<MessageDispatcherRequest> messageDispatcher) {
		this.messageDispatcher = messageDispatcher;
	}
}
