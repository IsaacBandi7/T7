package com.capitalone.api.dms.redispatcher.model;

public class DeliveryResponse {

	private Integer notificationStatusCode;
	private String notificationStatusDescription;
	private String notificationStatusDeveloperText;

	public Integer getNotificationStatusCode() {
		return notificationStatusCode;
	}

	public void setNotificationStatusCode(Integer notificationStatusCode) {
		this.notificationStatusCode = notificationStatusCode;
	}

	public String getNotificationStatusDescription() {
		return notificationStatusDescription;
	}

	public void setNotificationStatusDescription(
			String notificationStatusDescription) {
		this.notificationStatusDescription = notificationStatusDescription;
	}

	public String getNotificationStatusDeveloperText() {
		return notificationStatusDeveloperText;
	}

	public void setNotificationStatusDeveloperText(
			String notificationStatusDeveloperText) {
		this.notificationStatusDeveloperText = notificationStatusDeveloperText;
	}
}
