package com.capitalone.api.dms.redispatcher;

public class RedispatcherConstants {
	public static final String DISPACTHER_URL = "/internal-message-dispatcher-web/internal/message-dispatcher";

	public static final String HEADER_ACCEPT = "Accept";

	public static final String HEADER_CONTENT_TYPE = "Content-Type";

	public static final String HEADER_API_KEY = "Api-Key";

	public static final String HEADER_USER_ID = "User-id";

	public static final String HEADER_PROXY_ID = "x-RS-Proxy-Id";
	
	public static final String HEADER_PROXY_VAL = "x-RS-Proxy-Value";
	
	
	public static final String HEADER_VALUE_CONTENTTYPE = "application/json;charset=UTF-8";

	public static final String HEADER_VALUE_RTM = "RTM";
	
	public static final String HEADER_VALUE_PROXY_ID = "health";
	
	public static final String HEADER_VALUE_PROXY_VAL = "internal/message-dispatcher/health";
	
	public static final String ALRT_HIST_COLL_NAME="alrtDlvryHist";
	
	public static final String RDSP_CTRL_COLL_NAME="redispatchCtrl";
}
