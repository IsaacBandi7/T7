package com.capitalone.api.dms.redispatcher;

public class RetryableException extends Exception {
	
	private static final long serialVersionUID = 1L;
	public RetryableException(String message) {
	super(message);
	}
}
