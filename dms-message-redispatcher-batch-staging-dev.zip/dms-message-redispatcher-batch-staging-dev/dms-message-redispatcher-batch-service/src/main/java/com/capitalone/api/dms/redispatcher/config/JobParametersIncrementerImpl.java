package com.capitalone.api.dms.redispatcher.config;

import java.util.Date;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersIncrementer;

public class JobParametersIncrementerImpl implements JobParametersIncrementer {

	@Override
	public JobParameters getNext(JobParameters parameters) {
		 if (parameters == null) {
	            parameters = new JobParameters();
	        }

	        parameters = new JobParametersBuilder(parameters).addDate("schedule.time",new Date()).toJobParameters();

	        return parameters; 
	    }
	}


