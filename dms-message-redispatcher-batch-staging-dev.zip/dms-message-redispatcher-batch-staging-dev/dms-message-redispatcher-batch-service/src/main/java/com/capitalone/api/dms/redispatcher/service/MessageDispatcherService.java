package com.capitalone.api.dms.redispatcher.service;

import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.capitalone.api.dms.redispatcher.dao.MessageDispatcherDao;
import com.capitalone.api.dms.redispatcher.model.MessageDispatcherRequest;
import com.capitalone.api.dms.redispatcher.model.MessageDispatcherRequests;
import com.google.common.collect.Lists;
@Service
public class MessageDispatcherService {
	@Inject
	private MessageDispatcherDao messageDispatcherDao;

	 @Async("taskExecutor")
	public Future<Object> sendMessages(List<MessageDispatcherRequest> messageDispatcherRequestList) throws Exception
	{
		 
			List<List<MessageDispatcherRequest>> splittedMDRequest = null;
			
			if (messageDispatcherRequestList != null && messageDispatcherRequestList.size() > 0) {
				//Split the input MessageDispatcher request List to 5 contact points each
			
				splittedMDRequest = Lists.partition(messageDispatcherRequestList, 5);
				for (List<MessageDispatcherRequest> partition : splittedMDRequest) {
				MessageDispatcherRequests dispatcherRequests = new MessageDispatcherRequests();
				dispatcherRequests.setMessageDispatcher(partition);
				messageDispatcherDao.sendMessages(dispatcherRequests);
				}
			}
		 
		return new AsyncResult<Object>(Boolean.TRUE);
		
		
	}
}
