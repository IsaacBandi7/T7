package com.capitalone.api.dms.redispatcher.dao;

import java.net.URI;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.capitalone.api.dms.redispatcher.RedispatcherConstants;
import com.capitalone.api.dms.redispatcher.RetryableException;
import com.capitalone.api.dms.redispatcher.config.ReDispatcherConfig;
import com.capitalone.api.dms.redispatcher.model.MessageDispatcherRequests;
import com.capitalone.api.dms.redispatcher.model.MessageDispatcherResponses;
import com.capitalone.api.dms.redispatcher.service.MessageDispatcherRestTemplate;

public class MessageDispatcherDao {

	/*@Inject
	private OAuth2RSUtils oAuth2RSUtils;
*/
	private RestTemplate messageDispatchRestTemplate;

	@Inject
	private ReDispatcherConfig configBean;
	private int DEFAULT_MAX_PER_ROUTE = 60;
	private int DEFAULT_MAX_TOT_CON = 100;
	private static Logger logger = LoggerFactory
			.getLogger(MessageDispatcherDao.class);

	@PostConstruct
	public void initService() {
		messageDispatchRestTemplate = new MessageDispatcherRestTemplate(
				Integer.valueOf(configBean.getConnectionTimeout()),
				DEFAULT_MAX_TOT_CON, DEFAULT_MAX_PER_ROUTE);
	}


	public void sendMessages(MessageDispatcherRequests dispatcherRequests)
			throws Exception {

		HttpEntity<MessageDispatcherRequests> entity = new HttpEntity<MessageDispatcherRequests>(
				dispatcherRequests, getHeaders());

		try {
			long currentTime = System.currentTimeMillis();

			logger.debug("***BEFORE MD Call***" + Long.toString(currentTime));
			URI url = new URI(configBean.getApiGWMessageDispURL());
			logger.info("Request to MS dispatcher" + entity.toString());

			ResponseEntity<MessageDispatcherResponses> responseEntity = messageDispatchRestTemplate
					.exchange(url, HttpMethod.POST, entity,
							MessageDispatcherResponses.class);

			logger.debug("***After MD Call***"
					+ Long.toString(currentTime - System.currentTimeMillis()));

			logger.debug("Response stat code from MessageRedispatcher {}",
					responseEntity.getStatusCode());

		} catch (HttpClientErrorException e) {
			logger.error("Exception Occured calling Message Dispatcher {} ", e);
			HttpStatus httpStatus = e.getStatusCode();

			// Suppress Request validation error
			if (httpStatus == HttpStatus.BAD_REQUEST) {
				logger.error("Bad request to Message Dispatcher {}", e);

			} else {
				throw new RetryableException(e.getResponseBodyAsString());
			}
		}

	}

	public void healthCheck() throws Exception {
		HttpEntity<MessageDispatcherRequests> entity = new HttpEntity<MessageDispatcherRequests>(
				getHealthCheckHeaders());
		URI url = new URI(configBean.getApiGWMessageDispURL());
		logger.info("Health Check Request to MS dispatcher" + entity.toString());
		ResponseEntity<?> responseEntity = messageDispatchRestTemplate
				.exchange(url, HttpMethod.POST, entity, String.class);
		logger.debug(
				"Response stat code from MessageRedispatcher healthCheck{}",
				responseEntity.getStatusCode());
	}

	private HttpHeaders getHealthCheckHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.add(RedispatcherConstants.HEADER_ACCEPT,
				RedispatcherConstants.HEADER_VALUE_CONTENTTYPE);
		headers.add(RedispatcherConstants.HEADER_CONTENT_TYPE,
				RedispatcherConstants.HEADER_VALUE_CONTENTTYPE);
		headers.add(RedispatcherConstants.HEADER_PROXY_ID,
				RedispatcherConstants.HEADER_VALUE_PROXY_ID);
		headers.add(RedispatcherConstants.HEADER_PROXY_VAL,
				RedispatcherConstants.HEADER_VALUE_PROXY_VAL);
		return headers;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.add(RedispatcherConstants.HEADER_ACCEPT,
				RedispatcherConstants.HEADER_VALUE_CONTENTTYPE);
		headers.add(RedispatcherConstants.HEADER_CONTENT_TYPE,
				RedispatcherConstants.HEADER_VALUE_CONTENTTYPE);
		headers.add(RedispatcherConstants.HEADER_API_KEY,
				RedispatcherConstants.HEADER_VALUE_RTM);
		headers.add(RedispatcherConstants.HEADER_USER_ID,
				RedispatcherConstants.HEADER_VALUE_RTM);
		return headers;
	}
}
