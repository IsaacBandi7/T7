package com.capitalone.api.dms.redispatcher.service;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

public class CustomJobExecutionListener implements JobExecutionListener {

	@Autowired
	private ThreadPoolTaskExecutor taskExecutor;
	private Map<String, Object> dataMap;
	private static Logger logger = LoggerFactory
			.getLogger(CustomJobExecutionListener.class);

	@Override
	public void beforeJob(JobExecution jobExecution) {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		// Cleans data Map if the job is Stopped or failed
		dataMap.clear();
		logger.debug("Enetered CustomJobExecutionListener	");
	}

	public void setDataMap(Map<String, Object> dataMap) {
		this.dataMap = dataMap;
	}

}
