package com.capitalone.api.dms.redispatcher.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class MessageDispatcherRequest implements Serializable {
	
	 private static final long serialVersionUID = 1853355651832301663L;  

	private Long alertTrackingId;
	private Long _id;

	private Long contactPointId;

	private Long alertDeliveryVendorId;
	private String contactPointType;

	private Integer messageFormat;

	private String messageText;

	private String contactPointValue;

	private String alertTypeCode;

	private Integer classificationId;

	private Long accountId;

	private Integer sorId;

	private Long customerId;

	private String ssoId;

	private Long messagingCustomerId;

	private boolean isDraft;

	private boolean isAlertHistoryRequired;

	private String enterpriseLineOfBusiness;

	private Integer templateId;

	private String templateLookupCode;

	private String productDescription;

	private String last4DigitsCardNumber;

	private Integer messageRetryCount;

	private Date alertSentTimeStamp;
	
	public Long get_id() {
		return _id;
	}

	public void set_id(Long _id) {
		this._id = _id;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	// Increment value
	public Integer getMessageRetryCount() {
		return (Integer) (messageRetryCount.intValue() + 1);
	}

	public void setMessageRetryCount(Integer messageRetryCount) {
		this.messageRetryCount = messageRetryCount;
	}

	public Integer getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}

	public String getAlertTypeCode() {
		return alertTypeCode;
	}

	public void setAlertTypeCode(String alertTypeCode) {
		this.alertTypeCode = alertTypeCode;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public String getSsoId() {
		return ssoId;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	public boolean isIsDraft() {
		return isDraft;
	}

	public void setDraft(boolean isDraft) {
		this.isDraft = isDraft;
	}

	public Long getContactPointId() {
		return contactPointId;
	}

	public void setContactPointId(Long contactPointId) {
		this.contactPointId = contactPointId;
	}

	public Long getAlertDeliveryVendorId() {
		return alertDeliveryVendorId;
	}

	public void setAlertDeliveryVendorId(Long alertDeliveryVendorId) {
		this.alertDeliveryVendorId = alertDeliveryVendorId;
	}

	public String getContactPointType() {
		return contactPointType;
	}

	public void setContactPointType(String contactPointType) {
		this.contactPointType = contactPointType;
	}

	public Integer getMessageFormat() {
		return messageFormat;
	}

	public void setMessageFormat(Integer messageFormat) {
		this.messageFormat = messageFormat;
	}

	public String getContactPointValue() {
		return contactPointValue;
	}

	public void setContactPointValue(String contactPointValue) {
		this.contactPointValue = contactPointValue;
	}

	public Integer getSorId() {
		return sorId;
	}

	public void setSorId(Integer sorId) {
		this.sorId = sorId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getMessagingCustomerId() {
		return messagingCustomerId;
	}

	public void setMessagingCustomerId(Long messagingCustomerId) {
		this.messagingCustomerId = messagingCustomerId;
	}

	// Set to true always
	public boolean isIsAlertHistoryRequired() {
		return true;
	}

	public void setAlertHistoryRequired(boolean isAlertHistoryRequired) {
		this.isAlertHistoryRequired = isAlertHistoryRequired;
	}

	public String getEnterpriseLineOfBusiness() {
		return enterpriseLineOfBusiness;
	}

	public void setEnterpriseLineOfBusiness(String enterpriseLineOfBusiness) {
		this.enterpriseLineOfBusiness = enterpriseLineOfBusiness;
	}

	public String getTemplateLookupCode() {
		return templateLookupCode;
	}

	public void setTemplateLookupCode(String templateLookupCode) {
		this.templateLookupCode = templateLookupCode;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getLast4DigitsCardNumber() {
		return last4DigitsCardNumber;
	}

	public void setLast4DigitsCardNumber(String last4DigitsCardNumber) {
		this.last4DigitsCardNumber = last4DigitsCardNumber;
	}

	public BigDecimal getAlertTrackingId() {
		return new BigDecimal(alertTrackingId);
	}

	public void setAlertTrackingId(Long alertTrackingId) {
		this.alertTrackingId = alertTrackingId;
	}

	public Integer getClassificationId() {
		return classificationId;
	}

	public void setClassificationId(Integer classificationId) {
		this.classificationId = classificationId;
	}
	public Date getAlertSentTimeStamp() {
		return alertSentTimeStamp;
	}

	public void setAlertSentTimeStamp(Date alertSentTimeStamp) {
		this.alertSentTimeStamp = alertSentTimeStamp;
	}

	
	
}
