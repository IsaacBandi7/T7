package com.capitalone.api.dms.redispatcher.OAuth2;

/**
 * @author asv132 - Karthik Palanivelu on 5/14/15.
 */

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.annotation.PostConstruct;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.inject.Named;
import javax.xml.bind.DatatypeConverter;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.capitalone.epf.exception.model.EPFSystemException;
import com.capitalone.upf.secureddatum.SecuredData;
import com.capitalone.upf.secureddatum.SecuredDatum;

@Named
public class EncryptedSecuredDatum implements SecuredDatum {
	protected static final ThreadLocal<Cipher> cipherEncrypTls = new ThreadLocal();
	protected static final ThreadLocal<Cipher> cipherDecyptTls = new ThreadLocal();
	private static final long serialVersionUID = -7873071135023239109L;
	@Value("${upf.secureddatum.encryption.password}")
	String encPassword;
	@Value("${upf.secureddatum.encryption.salt}")
	String encSaltStr;
	private byte[] encSalt;
	private byte[] initVector = new byte[] { (byte) 0, (byte) 2, (byte) 4,
			(byte) 6, (byte) 2, (byte) 9, (byte) 5, (byte) 1, (byte) 4,
			(byte) 1, (byte) 5, (byte) 9, (byte) 2, (byte) 7, (byte) 1,
			(byte) 0 };
	private String algorithmName = "AES/CBC/PKCS5Padding";
	private int keyStrength = 256;

	private org.slf4j.Logger logger = LoggerFactory.getLogger(getClass());

	public EncryptedSecuredDatum() {
	}

	@PostConstruct
	public void configForEncryption() {
		logger.info("configForEncryption salt and pwd"+encPassword + encSaltStr);
		try {
			this.getInitFromConfig();
		} catch (EPFSystemException var2) {
			this.logger.error("Error generating Cipher for Encryption", var2);
		}

	}

	private void getInitFromConfig() {
		try {
			this.encSalt = encSaltStr.getBytes();
		} catch (EPFSystemException var3) {
			this.logger
					.error("Error initializing EncryptedDatum from UPF application config file",
							var3);
		}

	}

	Cipher getEncyptCipher() {
		return this.getCipher(cipherEncrypTls, 1);
	}

	Cipher getDecyptCipher() {
		return this.getCipher(cipherDecyptTls, 2);
	}

	Cipher getCipher(ThreadLocal<Cipher> tls, int mode) {
		try {
			Cipher e = (Cipher) tls.get();
			if (e == null) {
				e = Cipher.getInstance(this.algorithmName);
				this.initCipher(mode, e);
				tls.set(e);
			}

			return e;
		} catch (NoSuchAlgorithmException var4) {
			throw new EPFSystemException(
					"The encryption algorithm specified is invalid", var4);
		} catch (NoSuchPaddingException var5) {
			throw new EPFSystemException(
					"The encryption padding specified is invalid", var5);
		}
	}

	private void initCipher(int mode, Cipher cipher) {
		try {
			logger.info("configForEncryption salt and pwd"+encPassword + encSaltStr);
			
			cipher.init(mode, this.generateEncKey(this.encSalt),
					new IvParameterSpec(this.initVector));
		} catch (InvalidKeyException var4) {
			throw new EPFSystemException(
					"The secret key is invalid. Verify 256-bit cryptogrpahy policy jar files installed.",
					var4);
		} catch (InvalidAlgorithmParameterException var5) {
			throw new EPFSystemException(
					"The encryption algorithm parameters are invalid", var5);
		} catch (NoSuchAlgorithmException var6) {
			throw new EPFSystemException(
					"The encryption algorithm parameters are invalid", var6);
		} catch (InvalidKeySpecException var7) {
			throw new EPFSystemException(
					"The secret key specification is invalid.  Verify 256-bit cryptogrpahy policy jar files installed.",
					var7);
		}
	}

	public int getKeyStrength() {
		return this.keyStrength;
	}

	public SecretKey generateEncKey(byte[] encSalt)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		char[] encPasswordChrArr = this.encPassword.toCharArray();
		SecretKeyFactory keyFactory = SecretKeyFactory
				.getInstance("PBKDF2WithHmacSHA1");
		PBEKeySpec encSpec = new PBEKeySpec(encPasswordChrArr, encSalt, 65536,
				this.keyStrength);
		SecretKey priSecretKey = keyFactory.generateSecret(encSpec);
		return new SecretKeySpec(priSecretKey.getEncoded(), "AES");
	}

	public byte[] encrypt(String textToEncrypt) {
		if (textToEncrypt == null) {
			return null;
		} else {
			try {
				return this.getEncyptCipher().doFinal(
						textToEncrypt.getBytes("UTF-8"));
			} catch (UnsupportedEncodingException var3) {
				this.initCipher(1, this.getEncyptCipher());
				throw new EPFSystemException(
						"Unsupported encoding Size while trying to encrypt.",
						var3);
			} catch (IllegalBlockSizeException var4) {
				this.initCipher(1, this.getEncyptCipher());
				throw new EPFSystemException(
						"Illegal Block Size while trying to encrypt.", var4);
			} catch (BadPaddingException var5) {
				this.initCipher(1, this.getEncyptCipher());
				throw new EPFSystemException(
						"Badd Padding while trying to encrypt.", var5);
			}
		}
	}

	public String encryptBase64Encode(String text) {
		return DatatypeConverter.printBase64Binary(this.encrypt(text));
	}

	public String decrypt(byte[] encryptedText) {
		
		
		if (encryptedText == null) {
			return null;
		} else {
			try {
				return new String(
						this.getDecyptCipher().doFinal(encryptedText), "UTF-8");
			} catch (UnsupportedEncodingException var3) {
				this.initCipher(2, this.getDecyptCipher());
				throw new EPFSystemException(
						"Unsupported encoding Size while trying to decrypt.",
						var3);
			} catch (IllegalBlockSizeException var4) {
				this.initCipher(2, this.getDecyptCipher());
				throw new EPFSystemException(
						"Illegal Block Size while trying to decrypt.", var4);
			} catch (BadPaddingException var5) {
				this.initCipher(2, this.getDecyptCipher());
				throw new EPFSystemException(
						"Badd Padding while trying to decrypt.", var5);
			}
		}
	}

	public String decryptBase64Encoded(String base64EncryptedText) {
		logger.info("encryptedText "+base64EncryptedText);
		
		return this.decrypt(DatatypeConverter
				.parseBase64Binary(base64EncryptedText));
	}

	public String convertToSecuredFormat(SecuredData datum) {
		if (null != datum.getDataValue()) {
			try {
				return DatatypeConverter.printBase64Binary(this.encrypt(datum
						.getDataValue()));
			} catch (Exception var3) {
				throw new EPFSystemException(
						"Error encrypting SecuredData value", var3);
			}
		} else {
			return datum.getDataValue();
		}
	}
}
