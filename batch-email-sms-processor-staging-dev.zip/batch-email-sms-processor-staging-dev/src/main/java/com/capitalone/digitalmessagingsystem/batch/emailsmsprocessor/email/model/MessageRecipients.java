package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model;

import org.json.JSONObject;

public class MessageRecipients {
	private Recipient recipient; 
	private MessageKeyValueData messageKeyValueData;
	private JSONObject substitutionKeyValueData; 
	
	public Recipient getRecipient() {
		return recipient;
	}
	public void setRecipient(Recipient recipient) {
		this.recipient = recipient;
	}
	public MessageKeyValueData getMessageKeyValueData() {
		return messageKeyValueData;
	}
	public void setMessageKeyValueData(MessageKeyValueData messageKeyValueData) {
		this.messageKeyValueData = messageKeyValueData;
	}
	public JSONObject getSubstitutionKeyValueData() { 
		return substitutionKeyValueData;
	}
	public void setSubstitutionKeyValueData(JSONObject substitutionKeyValueData) {
		this.substitutionKeyValueData = substitutionKeyValueData;
	}
	 
	
}
