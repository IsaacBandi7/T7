package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.tkn.model;

public class PushNotificationRequest {

	private String mobileAppId;
	
	private String deviceToken;
	
	private String alertTypeCode;
	
	private String message;
	
	private String alertTrackingId;

	public String getMobileAppId() {
		return mobileAppId;
	}

	public void setMobileAppId(String mobileAppId) {
		this.mobileAppId = mobileAppId;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getAlertTypeCode() {
		return alertTypeCode;
	}

	public void setAlertTypeCode(String alertTypeCode) {
		this.alertTypeCode = alertTypeCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAlertTrackingId() {
		return alertTrackingId;
	}

	public void setAlertTrackingId(String alertTrackingId) {
		this.alertTrackingId = alertTrackingId;
	}
	
	
}
