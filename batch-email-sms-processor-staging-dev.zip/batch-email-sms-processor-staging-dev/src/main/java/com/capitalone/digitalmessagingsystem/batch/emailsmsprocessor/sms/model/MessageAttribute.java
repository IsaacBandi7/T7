package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.sms.model;

public class MessageAttribute {
	private String channelType;
	private String contentKey;
	private String messageFormat; 
	private String contentSubscriber;
	private String languageCode;
	public String getChannelType() {
		return channelType;
	}
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}
	public String getContentKey() {
		return contentKey;
	}
	public void setContentKey(String contentKey) {
		this.contentKey = contentKey;
	}
	public String getMessageFormat() {
		return messageFormat;
	}
	public void setMessageFormat(String messageFormat) {
		this.messageFormat = messageFormat;
	}
	public String getContentSubscriber() {
		return contentSubscriber;
	}
	public void setContentSubscriber(String contentSubscriber) {
		this.contentSubscriber = contentSubscriber;
	}
	public String getLanguageCode() {
		return languageCode;
	}
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	
}
