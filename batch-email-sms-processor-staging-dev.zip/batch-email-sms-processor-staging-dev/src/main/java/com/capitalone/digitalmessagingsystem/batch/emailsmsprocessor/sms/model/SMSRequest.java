package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.sms.model;

public class SMSRequest {

	private SMSRecipients smsRecipients;
	private String smsShortCode;
	private String messageText;
	private String smsMobileOriginatedConnectionId;
	private String smsReportingKey2;
	private String smsSendTimestamp;
	private String smsValidityDuration;
	private String deliverInCustomerLocalTime;  
	
	
	public SMSRecipients getSmsRecipients() {
		return smsRecipients;
	}
	public void setSmsRecipients(SMSRecipients smsRecipients) {
		this.smsRecipients = smsRecipients;
	}
	public String getSmsShortCode() {
		return smsShortCode;
	}
	public void setSmsShortCode(String smsShortCode) {
		this.smsShortCode = smsShortCode;
	}
	public String getMessageText() {
		return messageText;
	}
	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
	public String getSmsMobileOriginatedConnectionId() {
		return smsMobileOriginatedConnectionId;
	}
	public void setSmsMobileOriginatedConnectionId(
			String smsMobileOriginatedConnectionId) {
		this.smsMobileOriginatedConnectionId = smsMobileOriginatedConnectionId;
	}
	public String getSmsReportingKey2() {
		return smsReportingKey2;
	}
	public void setSmsReportingKey2(String smsReportingKey2) {
		this.smsReportingKey2 = smsReportingKey2;
	}
	public String getSmsSendTimestamp() {
		return smsSendTimestamp;
	}
	public void setSmsSendTimestamp(String smsSendTimestamp) {
		this.smsSendTimestamp = smsSendTimestamp;
	}
	public String getSmsValidityDuration() {
		return smsValidityDuration;
	}
	public void setSmsValidityDuration(String smsValidityDuration) {
		this.smsValidityDuration = smsValidityDuration;
	}
	public String getDeliverInCustomerLocalTime() {
		return deliverInCustomerLocalTime;
	}
	public void setDeliverInCustomerLocalTime(String deliverInCustomerLocalTime) {
		this.deliverInCustomerLocalTime = deliverInCustomerLocalTime;
	}
}
