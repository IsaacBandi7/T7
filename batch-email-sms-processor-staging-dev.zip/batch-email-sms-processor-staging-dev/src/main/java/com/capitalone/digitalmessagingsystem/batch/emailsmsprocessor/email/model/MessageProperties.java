package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model;

public class MessageProperties{
	 
	private String environmentVar;

	/**
	 * @return the environmentVar
	 */
	public String getEnvironmentVar() {
		return environmentVar;
	}

	/**
	 * @param environmentVar the environmentVar to set
	 */
	public void setEnvironmentVar(String environmentVar) {
		this.environmentVar = environmentVar;
	}  
	

}
