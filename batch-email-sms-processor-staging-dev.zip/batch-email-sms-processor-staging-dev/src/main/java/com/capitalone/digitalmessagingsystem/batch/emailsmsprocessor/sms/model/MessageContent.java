package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.sms.model;

public class MessageContent {
	private String templateContent;
	private String substitutionContent;
	
	
	public String getTemplateContent() { 
		return templateContent;
	}
	public void setTemplateContent(String templateContent) {
		this.templateContent = templateContent;
	}
	public String getSubstitutionContent() {
		return substitutionContent;
	}
	public void setSubstitutionContent(String substitutionContent) {
		this.substitutionContent = substitutionContent;
	}
	
}
