package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.processor;

public class EmailSMSProcessorException extends Exception {

	
	
	private final String errorType;
	private final String message;
	
	public String getErrorType() {
		return errorType;
	}

	
	public String getMessage() {
		return message;
	}


	public EmailSMSProcessorException(String message){ 
		this.message = message;
		this.errorType = "";
	}
	
	public EmailSMSProcessorException(String message, String errorType){
		this.message = message;
		this.errorType = errorType;
	}
	
	public EmailSMSProcessorException(Throwable throwable){  
		super(throwable); 
		this.message = throwable.getMessage();
		this.errorType = "";
	}
}
