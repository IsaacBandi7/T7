package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;


public class EmailSMSDataFilter {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailSMSDataFilter.class);
	public boolean dataFilter(Message<String> message){
 
		String errorCode = (String)message.getHeaders().get("errorCode");
		if(null != errorCode && !errorCode.isEmpty()){
			LOGGER.info("Error :: "+message);
			return false;
		}
		return true;
	}
} 
