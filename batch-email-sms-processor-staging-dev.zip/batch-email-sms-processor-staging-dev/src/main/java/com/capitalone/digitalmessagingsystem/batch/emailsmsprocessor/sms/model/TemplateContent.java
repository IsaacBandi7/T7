package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.sms.model;

public class TemplateContent {
	private String dynamicPlain;
	private String dynamicHtml;
	private String webRoot;
	private String fromEmailAddress;
	
	
	public String getDynamicHtml() {
		return dynamicHtml;
	}
	public String getDynamicPlain() {
		return dynamicPlain;
	}
	public void setDynamicPlain(String dynamicPlain) {
		this.dynamicPlain = dynamicPlain;
	}
	public void setDynamicHtml(String dynamicHtml) {
		this.dynamicHtml = dynamicHtml;
	}
	public String getWebRoot() {
		return webRoot;
	}
	public void setWebRoot(String webRoot) {
		this.webRoot = webRoot;
	}
	public String getFromEmailAddress() {
		return fromEmailAddress;
	}
	public void setFromEmailAddress(String fromEmailAddress) {
		this.fromEmailAddress = fromEmailAddress;
	}
	
}
