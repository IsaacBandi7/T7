package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util;

public class EmailSMSConstants {
	/**
	 * Payload constants
	 */
	private EmailSMSConstants(){
		
	}
	public static final String MSG_ATTRIBUTE = "messageAttribute"; 
	public static final String EML = "EML";
	public static final String PHN = "PHN";
	public static final String TKN = "TKN";
	public static final String MobileAPPId = "elctrAdrFrmtId";
	public static final String ERROR_CODE = "errorCode";
	public static final String ERROR_MSG = "errorMessage";
	public static final String MSG_CONTENT = "messageContent";
	public static final String SUBSTI_CONTENT = "substitutionContent";
	public static final String CNTCT_PNT_ADR_TXT = "cntctPntAdrTxt";
	public static final String ALRT_TYPE_CD = "alrtTypeCd";
	public static final String DLVRY_ID = "dlvryId";
	public static final String TMPL_ID = "tmplId";
	public static final String MSG_FORMAT = "messageFormat";
	public static final String TMPL_CONTENT = "templateContent";
	public static final String MSG_TEXT = "messageText";
	public static final String CHNL_TYPE = "elctrAdrTypeCd";
	public static final String EMPTY_STRING = "";
	public static final String UNDER_SCORE = "_";
	public static final String  CONST_DLVRY_CUST_LCL_TIME= "f";
	/** * Header Constants * **/
	public static final String ACTUAL_RECORD = "Actual-Record";
	public static final String API_KEY = "Api-Key";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String CHANNEL_TYPE = "Channel-Type";
	public static final String MESSAGE_TEXT = "Message-Text"; 
	public static final String FILE_NAME = "file_name";
	public static final String ENVIORNMENT_PROD = "PROD";
    
    public static final String PREMISE = "premise";
    public static final String CONST_COIN = "coin";

	
	/** * error message payload parameters	 */
	public static final String CONST_FILE_NAME = "fileName";
	public static final String CONST_ACTUAL_RECORD = "actualRecord";
	public static final String CONST_ERROR_MSG = "errorMessage";
	public static final String ERROR_TEXT = "Error in Content Assembly Response";
	
	/*********** Error Constants ****************/
	public static final String CONST_ID = "id";
	public static final String CONST_TEXT = "text";
    public static final String CONST_DVLPR_TXT = "developerText";
    public static final String CONST_ERR_DETAILS = "errorDetails";
    public static final String CONST_CUST_ERR_DESC = "Error Description not available";
	/*********************************************/
	
	public static final String  UTF_8 = "UTF-8";
	public static final String  IS_NULL = "is null";
	
	public static final String MSG_DELIMITER = "*****************************************************";
	
	public static final String MODULE_NAME = "batch-emailsmsprocessor";
	public static final String ERROR_TYPE = "Error-Type";
	public static final String CONST_SYS_EXPTN = "System Exception";
	public static final String CONST_BIZ_EXPTN = "Business Exception";
	
}
