package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.sms.model;

public class SMSRecipients {
	private String destinationPhoneNumber;
	private String alertTrackingId; 
	
	public String getDestinationPhoneNumber() {
		return destinationPhoneNumber;
	}
	public void setDestinationPhoneNumber(String destinationPhoneNumber) {
		this.destinationPhoneNumber = destinationPhoneNumber;
	}
	public String getAlertTrackingId() {
		return alertTrackingId;
	}
	public void setAlertTrackingId(String alertTrackingId) {
		this.alertTrackingId = alertTrackingId;
	}  
	
}
