package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model;

public class MessageKeyValueData {
	private String alertTrackingId;
	private String alertType;
	private boolean isIsDraft; 

	


	
	/**
	 * @return the isIsDraft
	 */
	public boolean isIsDraft() {
		return isIsDraft;
	}
	/**
	 * @param isIsDraft the isIsDraft to set
	 */
	public void setIsDraft(boolean isIsDraft) {
		this.isIsDraft = isIsDraft;
	}
	public String getAlertTrackingId() {
		return alertTrackingId;
	}
	public void setAlertTrackingId(String alertTrackingId) {
		this.alertTrackingId = alertTrackingId;
	}
	public String getAlertType() {
		return alertType;
	}
	public void setAlertType(String alertType) { 
		this.alertType = alertType;
	}
	
}
