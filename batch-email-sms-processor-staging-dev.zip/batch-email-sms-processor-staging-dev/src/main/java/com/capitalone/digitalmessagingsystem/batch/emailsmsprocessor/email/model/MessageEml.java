package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model;

public class MessageEml {
	private String templateId;
	private boolean useDraftTemplate;
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public boolean isUseDraftTemplate() {
		return useDraftTemplate;
	}
	public void setUseDraftTemplate(boolean useDraftTemplate) {
		this.useDraftTemplate = useDraftTemplate; 
	}   
}
