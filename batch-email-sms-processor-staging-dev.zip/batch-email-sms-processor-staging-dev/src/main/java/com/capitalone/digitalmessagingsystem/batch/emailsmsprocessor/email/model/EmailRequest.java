package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model;

import java.util.Arrays;

import org.json.JSONObject;

public class EmailRequest {
	private MessageRecipients[] messageRecipients;
	private MessageEml message;
	private JSONObject substitutionKeyValueData;

	public MessageRecipients[] getMessageRecipients() {
		return Arrays.copyOf(messageRecipients, messageRecipients.length);
	}

	public void setMessageRecipients(MessageRecipients[] messageRecipients) {
		
		this.messageRecipients = messageRecipients.clone();
	}

	public MessageEml getMessage() {
		return message;
	}

	public void setMessage(MessageEml message) {
		this.message = message;
	}

	public JSONObject getSubstitutionKeyValueData() {
		return substitutionKeyValueData;
	}

	public void setSubstitutionKeyValueData(
			JSONObject substitutionKeyValueData) {
		this.substitutionKeyValueData = substitutionKeyValueData;
	}
}
