package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model;

public class Recipient {
	private String emailAddress;

	public String getEmailAddress() { 
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress; 
	} 
	
}
