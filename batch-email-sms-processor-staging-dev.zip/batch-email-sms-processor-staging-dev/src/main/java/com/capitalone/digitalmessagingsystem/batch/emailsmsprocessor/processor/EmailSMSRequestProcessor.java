package com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.processor;

/**
 * This class creates Email / SMS request from the batch input and the Content Assembly Response
 * 
 * @author Jitendranath Bariki
 */
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.ACTUAL_RECORD;


import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.ALRT_TYPE_CD;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CHANNEL_TYPE;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CHNL_TYPE;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CNTCT_PNT_ADR_TXT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_ACTUAL_RECORD;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_CUST_ERR_DESC;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_DLVRY_CUST_LCL_TIME;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_DVLPR_TXT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_ERROR_MSG;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_ERR_DETAILS;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_FILE_NAME;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_ID;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_SYS_EXPTN;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_TEXT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.DLVRY_ID;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.EML;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.EMPTY_STRING;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.ENVIORNMENT_PROD;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.ERROR_CODE;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.ERROR_TYPE;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.FILE_NAME;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.IS_NULL;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.MESSAGE_TEXT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.MODULE_NAME;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.MSG_ATTRIBUTE;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.MSG_CONTENT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.MSG_DELIMITER;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.MSG_FORMAT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.MSG_TEXT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.PHN;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.TKN;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.SUBSTI_CONTENT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.TMPL_CONTENT;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.TMPL_ID;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.UNDER_SCORE;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.UTF_8;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.PREMISE;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.CONST_COIN;
import static com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.util.EmailSMSConstants.MobileAPPId;


import java.io.UnsupportedEncodingException; 
import java.nio.charset.StandardCharsets;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;

import com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model.EmailRequest;
import com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model.MessageEml;
import com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model.MessageKeyValueData;
import com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model.MessageRecipients;
import com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model.Recipient;
import com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.sms.model.SMSRecipients;
import com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.sms.model.SMSRequest;
import com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.tkn.model.PushNotificationRequest;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import java.util.zip.DeflaterOutputStream;

public class EmailSMSRequestProcessor {
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailSMSRequestProcessor.class);

	private com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model.MessageProperties messageProperties;

	/**
	 * @return the messageProperties
	 */
	public com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model.MessageProperties getMessageProperties() {
		return messageProperties;
	}

	/**
	 * @param messageProperties
	 *            the messageProperties to set
	 */
	public void setMessageProperties(
			com.capitalone.digitalmessagingsystem.batch.emailsmsprocessor.email.model.MessageProperties messageProperties) {
		this.messageProperties = messageProperties;
	}

	@Autowired
	private RabbitTemplate rabbitTemplate;

	public Message<String> transform(Message<String> payload) {
		LOGGER.error("Email-SMS Processor > transform()....");

		Message<String> result = null;
		String actualRecord = null;
		String fileName = null;
		MessageHeaders headers = null;
		JSONObject jsonPayload = null;
		JSONObject msgCntJson = null;
		ByteArrayOutputStream bos = null;
		Kryo kryo = null;
		Output ko = null;

		try {
			if (null != payload) {
				headers = payload.getHeaders();
				if (null != headers && null != headers.get(ACTUAL_RECORD)) {
					actualRecord = new String((byte[]) headers.get(ACTUAL_RECORD), StandardCharsets.UTF_8);
					fileName = headers.get(FILE_NAME).toString();
				}
				LOGGER.debug(MSG_DELIMITER);
				LOGGER.debug("actual record = " + actualRecord);
				LOGGER.debug("Content Assembly Response = " + payload.getPayload());
				LOGGER.debug(MSG_DELIMITER);

				/**********************
				 * validating content assembly
				 ***********************/
				// validatePayload(payload, actualRecord);
				/************************************************************************/

				String strPayload = payload.getPayload();
				try {
					jsonPayload = new JSONObject(strPayload);
				} catch (Exception e) {
					throw new EmailSMSProcessorException("payload/mandatory data is missing", CONST_SYS_EXPTN);
				}

				validateErrorIdText(jsonPayload);

				try {
					if (jsonPayload.has(MSG_CONTENT)){
						msgCntJson = jsonPayload.getJSONObject(MSG_CONTENT);
						bos = new ByteArrayOutputStream();
						DeflaterOutputStream deflaterOutputStream = 
				                new DeflaterOutputStream(bos);
						ko = new Output(deflaterOutputStream);
						kryo = new Kryo();
						kryo.writeObject(ko, msgCntJson.toString());
						ko.flush();
						deflaterOutputStream.close();
					}	
				} catch (JSONException e) {
					LOGGER.error("Error in converting Msg Content to Byte[]", e);
					throw new EmailSMSProcessorException(e);
				}
				// byte[] msgCont = convertMsgContToBytes(jsonPayaload);

				String channelType = headers.get(CHANNEL_TYPE).toString();

				if (isNotNull(channelType)) {
					/*******************
					 * Email request creation
					 ****************************/

					if (EML.equals(channelType)) {
						String emailRequest = new JSONObject(
								generateEMailRequest(jsonPayload, actualRecord, msgCntJson)).toString();
						result = MessageBuilder.withPayload(emailRequest).copyHeaders(headers)
						.setHeader(MESSAGE_TEXT, bos.toByteArray()).build();
						// .setHeader(MESSAGE_TEXT, "{\r\n\t\"substitutionContent\": \"welcome\"\r\n}".getBytes(UTF_8)).build();
								// .setHeader(MESSAGE_TEXT, "").build();
								//To Do
								// .setHeader(MESSAGE_TEXT, msgCntJson.toString().getBytes(UTF_8)).build();
						// .setHeader(MESSAGE_TEXT, msgCont).build();
						LOGGER.debug(MSG_DELIMITER);
						LOGGER.debug("EMail Request=" + result.getPayload());
						LOGGER.debug(MSG_DELIMITER);
					} else if (PHN.equals(channelType)) {
						/********************
						 * SMS request creation
						 *************************/
						String smsRequest = new JSONObject(generateSMSRequest(jsonPayload, actualRecord, msgCntJson))
								.toString();

						result = MessageBuilder.withPayload(smsRequest).copyHeaders(headers)
								.setHeader(PREMISE, CONST_COIN)
								.setHeader(MESSAGE_TEXT, bos.toByteArray()).build();
						// .setHeader(MESSAGE_TEXT, "{\r\n\t\"substitutionContent\": \"welcome\"\r\n}".getBytes(UTF_8)).build();
								// .setHeader(MESSAGE_TEXT, "").build();
								//To Do
								// .setHeader(MESSAGE_TEXT, msgCntJson.toString().getBytes(UTF_8)).build();
						// .setHeader(MESSAGE_TEXT, msgCont).build();

						LOGGER.debug(MSG_DELIMITER);
						LOGGER.debug("SMS Request=" + result.getPayload());
						LOGGER.debug(MSG_DELIMITER);
					}  else if (TKN.equals(channelType)) {
						/********************
						 * PUSH Notification request creation
						 *************************/
						String pushNotificationRequest = new JSONObject(generatePushNotificationRequest(jsonPayload, actualRecord, msgCntJson))
								.toString();

						result = MessageBuilder.withPayload(pushNotificationRequest).copyHeaders(headers)
								.setHeader(PREMISE, CONST_COIN)
								.setHeader(MESSAGE_TEXT, bos.toByteArray()).build();
						// .setHeader(MESSAGE_TEXT, "{\r\n\t\"substitutionContent\": \"welcome\"\r\n}".getBytes(UTF_8)).build();
								// .setHeader(MESSAGE_TEXT, "").build();
								//To Do
								// .setHeader(MESSAGE_TEXT, msgCntJson.toString().getBytes(UTF_8)).build();
						// .setHeader(MESSAGE_TEXT, msgCont).build();

						LOGGER.debug(MSG_DELIMITER);
						LOGGER.debug("Push Request=" + result.getPayload());
						LOGGER.debug(MSG_DELIMITER);
					}
				}
			}
		} catch (EmailSMSProcessorException e) {
			LOGGER.error("Error in transform() = ", e);
			writeErrorToQueue(actualRecord, e.getMessage(), e.getErrorType(), fileName);

			result = MessageBuilder.withPayload(e.getMessage()).setHeader(CONST_FILE_NAME, "")
					.setHeader(CONST_ACTUAL_RECORD, actualRecord.replaceAll("\\\\", "").getBytes())
					.setHeader(ERROR_CODE, e.getMessage()).build();
		} catch (Exception e) {
			LOGGER.error("Error in transform() = ", e);
			writeErrorToQueue(actualRecord, e.getMessage(), CONST_SYS_EXPTN, fileName);

			result = MessageBuilder.withPayload(e.getMessage()).setHeader(CONST_FILE_NAME, "")
					.setHeader(CONST_ACTUAL_RECORD, actualRecord.replaceAll("\\\\", "").getBytes())
					.setHeader(ERROR_CODE, e.getMessage()).build();
		}
		return result;
	}
		
	private void validateErrorIdText(JSONObject jsonData) throws EmailSMSProcessorException {
		String errorId = "";
		String errorText = "";
		if (null != jsonData && jsonData.has(CONST_ID)) {
			errorId = jsonData.get(CONST_ID).toString();

			if (jsonData.has(CONST_ERR_DETAILS) && jsonData.getJSONArray(CONST_ERR_DETAILS).length() > 0) {
				JSONArray errorDetailsArray = jsonData.getJSONArray(CONST_ERR_DETAILS);
				JSONObject errDetailsJSON = (JSONObject) errorDetailsArray.get(0);
				errorText = errDetailsJSON.has(CONST_DVLPR_TXT) ? errDetailsJSON.getString(CONST_DVLPR_TXT)
						: (errDetailsJSON.has(CONST_TEXT) ? errDetailsJSON.getString(CONST_TEXT) : CONST_CUST_ERR_DESC);
			} else {
				errorText = jsonData.has(CONST_DVLPR_TXT) ? jsonData.getString(CONST_DVLPR_TXT)
						: (jsonData.has(CONST_TEXT) ? jsonData.getString(CONST_TEXT) : CONST_CUST_ERR_DESC);
			}

			/** write to error queue */
			if ((null != errorId && !errorId.isEmpty()) && (null != errorText && !errorText.isEmpty())) {
				throw new EmailSMSProcessorException(CONST_ID + "=" + errorId + "," + errorText);
			}
		}
	}

	private String writeErrorToQueue(String actualJson, String errorText, String errorType, String fileName) {
		String response = null;
		try {
			MessageProperties messageProperties = new MessageProperties();
			messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
			messageProperties.setAppId(MODULE_NAME);
			if (errorType == null || errorType.equals(EMPTY_STRING)) {
				messageProperties.setHeader(ERROR_TYPE, CONST_SYS_EXPTN);
			} else {
				messageProperties.setHeader(ERROR_TYPE, errorType);
			}
			/** error payload creation */
			JSONObject jsonResponse = new JSONObject();
			jsonResponse.put(CONST_FILE_NAME, fileName);
			jsonResponse.put(CONST_ACTUAL_RECORD, actualJson);
			jsonResponse.put(CONST_ERROR_MSG, errorText);
			/** sending the error payload to error Queue */
			response = jsonResponse.toString();
			response = response.replaceAll("\\\\", "");
			org.springframework.amqp.core.Message message = null;

			message = new org.springframework.amqp.core.Message(response.getBytes(UTF_8), messageProperties);
			rabbitTemplate.send(message);
		} catch (UnsupportedEncodingException e) {
			LOGGER.error("UnsupportedEncodingException occurred while writing to error queue = ", e);
		} catch (Exception e) {
			LOGGER.error("Exception occurred while writing to error queue = ", e + ":" + actualJson);
		}

		return response;
	}

	private EmailRequest generateEMailRequest(JSONObject jsonPayload, String actualRecord, JSONObject msgCntJson)
			throws EmailSMSProcessorException {
		EmailRequest emailReq = null;
		if (null != actualRecord) {
			// JSONObject jsonPayload = new JSONObject(payload.getPayload());
			JSONObject actualJSON = new JSONObject(actualRecord);

			emailReq = new EmailRequest();
			MessageRecipients messageRecipients = new MessageRecipients();

			if (null != msgCntJson) {

				// if (jsonPayload.has(MSG_CONTENT)) {
				// JSONObject msgCntJson =
				// jsonPayload.getJSONObject(MSG_CONTENT);
				if (msgCntJson.has(SUBSTI_CONTENT)) {
					// String substitutionContent = jsonPayload
					// .getJSONObject(MSG_CONTENT).get(SUBSTI_CONTENT)
					// .toString();
					String substitutionContent = msgCntJson.get(SUBSTI_CONTENT).toString();
					JSONObject substitutionContentJSONObj = new JSONObject(substitutionContent);
					messageRecipients.setSubstitutionKeyValueData(substitutionContentJSONObj);
				}
			}

			Recipient recipient = new Recipient();
			recipient.setEmailAddress(
					isNullCheckMandatoryFields(actualJSON.getString(CNTCT_PNT_ADR_TXT), CNTCT_PNT_ADR_TXT));
			messageRecipients.setRecipient(recipient);

			MessageKeyValueData messageKeyValData = new MessageKeyValueData();
			messageKeyValData
					.setAlertType(isNullCheckMandatoryFields(actualJSON.getString(ALRT_TYPE_CD), ALRT_TYPE_CD));
			messageKeyValData.setAlertTrackingId(isNullCheckMandatoryFields(actualJSON.getString(DLVRY_ID), DLVRY_ID));
			messageKeyValData
					.setIsDraft((getMessageProperties() != null && getMessageProperties().getEnvironmentVar() != null
							&& !getMessageProperties().getEnvironmentVar().equalsIgnoreCase(ENVIORNMENT_PROD)) ? true
									: false);
			messageRecipients.setMessageKeyValueData(messageKeyValData);
			MessageEml message = new MessageEml();
			String templId = actualJSON.getString(TMPL_ID);
			String chnlType = actualJSON.getString(CHNL_TYPE);
			String msgFormat = jsonPayload.getJSONObject(MSG_ATTRIBUTE).get(MSG_FORMAT).toString();
			message.setTemplateId(new StringBuffer().append(templId).append(UNDER_SCORE).append(chnlType)
					.append(UNDER_SCORE).append(msgFormat).toString());
			message.setUseDraftTemplate(
					(getMessageProperties() != null && getMessageProperties().getEnvironmentVar() != null
							&& !getMessageProperties().getEnvironmentVar().equalsIgnoreCase(ENVIORNMENT_PROD)) ? true
									: false);
			MessageRecipients[] messageRecipientsAry = new MessageRecipients[1];
			messageRecipientsAry[0] = messageRecipients;
			// String substitutionKeyValueData = jsonPayload
			// .getJSONObject(MSG_CONTENT).get(TMPL_CONTENT).toString();
			String substitutionKeyValueData = msgCntJson.get(TMPL_CONTENT).toString();
			JSONObject substitutionKeyValueDataObj = new JSONObject(substitutionKeyValueData);
			emailReq.setMessageRecipients(messageRecipientsAry);
			emailReq.setMessage(message);
			emailReq.setSubstitutionKeyValueData(substitutionKeyValueDataObj);
		}
		return emailReq;
	}

	private SMSRequest generateSMSRequest(JSONObject jsonData, String actualRecord, JSONObject msgCntJson)
			throws JSONException, EmailSMSProcessorException {
		SMSRequest smsRequest = null;
		if (null != actualRecord) {
			smsRequest = new SMSRequest();
			// JSONObject jsonData = new JSONObject(payload.getPayload());
			JSONObject actualJSON = new JSONObject(actualRecord);
			SMSRecipients recipients = new SMSRecipients();
			recipients.setAlertTrackingId(isNullCheckForNonMandatoryFields(actualJSON.getString(DLVRY_ID)));
			recipients.setDestinationPhoneNumber(
					isNullCheckMandatoryFields(actualJSON.getString(CNTCT_PNT_ADR_TXT), CNTCT_PNT_ADR_TXT));

			/*
			 * JSONObject substitutionContent = new JSONObject(
			 * jsonData.getJSONObject(MSG_CONTENT)
			 * .getString(SUBSTI_CONTENT).toString());
			 */
			JSONObject substitutionContent = new JSONObject(msgCntJson.getString(SUBSTI_CONTENT).toString());
			String messageText = substitutionContent.get(MSG_TEXT).toString();

			smsRequest.setSmsRecipients(recipients);
			smsRequest.setDeliverInCustomerLocalTime(CONST_DLVRY_CUST_LCL_TIME);
			smsRequest.setMessageText(isNullCheckMandatoryFields(messageText, MSG_TEXT));
			smsRequest.setSmsMobileOriginatedConnectionId(EMPTY_STRING);
			smsRequest.setSmsReportingKey2(EMPTY_STRING);
			smsRequest.setSmsSendTimestamp(EMPTY_STRING);
			smsRequest.setSmsShortCode(EMPTY_STRING);
			smsRequest.setSmsValidityDuration(EMPTY_STRING);
		}
		return smsRequest;
	}
	
	private PushNotificationRequest generatePushNotificationRequest(JSONObject jsonData, String actualRecord, JSONObject msgCntJson)
			throws JSONException, EmailSMSProcessorException {
		PushNotificationRequest pushRequest = null;
		if (null != actualRecord) {
			pushRequest = new PushNotificationRequest();
			// JSONObject jsonData = new JSONObject(payload.getPayload());
			JSONObject actualJSON = new JSONObject(actualRecord);
			
			pushRequest.setAlertTrackingId(isNullCheckMandatoryFields(actualJSON.getString(DLVRY_ID), DLVRY_ID));
			pushRequest.setAlertTypeCode(isNullCheckMandatoryFields(actualJSON.getString(ALRT_TYPE_CD), ALRT_TYPE_CD));
			pushRequest.setDeviceToken(
					isNullCheckMandatoryFields(actualJSON.getString(CNTCT_PNT_ADR_TXT), CNTCT_PNT_ADR_TXT));

			
			JSONObject substitutionContent = new JSONObject(msgCntJson.getString(SUBSTI_CONTENT).toString());
			String messageText = substitutionContent.get(MSG_TEXT).toString();
			
			pushRequest.setMessage(messageText);
			pushRequest.setMobileAppId(isNullCheckMandatoryFields(actualJSON.getString(MobileAPPId), MobileAPPId));
			
		}
		return pushRequest;
	}

	/**
	 * isNullCheckMandatory
	 * 
	 * @param field
	 * @param testData2
	 * @return
	 * @throws Exception
	 */
	private String isNullCheckMandatoryFields(String field, String fieldName) throws EmailSMSProcessorException {
		String value = null;
		if (field != null && !field.isEmpty()) {
			value = field;
		} else {
			throw new EmailSMSProcessorException(fieldName + IS_NULL);
		}
		return value;
	}

	/**
	 * 
	 * @param field
	 * @return
	 * @throws EmailSMSProcessorException
	 */
	private String isNullCheckForNonMandatoryFields(String fieldName) throws EmailSMSProcessorException {
		String result = null;
		if (fieldName != null && !fieldName.isEmpty()) {
			result = fieldName;
		} else {
			result = fieldName;
		}
		return result;
	}

	private boolean isNotNull(String field) throws EmailSMSProcessorException {
		if (field != null && !field.isEmpty()) {
			return true;
		} else {
			throw new EmailSMSProcessorException(field + IS_NULL);
		}
	}

}
