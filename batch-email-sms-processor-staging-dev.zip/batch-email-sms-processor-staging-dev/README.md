This is a custom module developed to create request payload for EmailDispatcher and SMSDispatcher. Based on the channelType, it constructs the request for either EmailDispatcher or SMSDispatcher. This will also process the response from Content Aseembly, in the request construction process, and writes all the Content Assembly error responses, and processing errors into error queue.

Below is the usage of this custom module:

batchemailsmsprocessor --environment=DEV

Options:

1. environment - The value of this can be DEV for Dev, ST for Staging, PROD for Production
