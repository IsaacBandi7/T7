DMSAWSS3Source with OutputChannel
======================================

This project provided implementation to read files from S3 bucket using following spring projects:

  * Spring Integration
  * Spring Integration Aws
  * Spring Cloud Aws

This project can be extended to behave as a S3 - Source Module in XD.

Please wait for Spring Integration Aws 1.0 version to release.

Exhibits how to use the outputChannel on S3 Inbound Adapter.