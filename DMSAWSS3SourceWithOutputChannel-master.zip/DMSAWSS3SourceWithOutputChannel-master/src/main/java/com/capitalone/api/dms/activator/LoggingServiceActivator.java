package com.capitalone.api.dms.activator;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

/**
 * @author asv132 - Karthik Palanivelu on 10/7/15.
 */
public class LoggingServiceActivator {

    public void transform(Message<?> message) {
        String text = (String) message.getPayload();
        System.out.println("Text Received @>>>>>" + text);
        MessageHeaders headers = message.getHeaders();
        System.out.println("Text displayed above from File Name >>>>>>>>>" + headers.get("file_name"));
    }

}
