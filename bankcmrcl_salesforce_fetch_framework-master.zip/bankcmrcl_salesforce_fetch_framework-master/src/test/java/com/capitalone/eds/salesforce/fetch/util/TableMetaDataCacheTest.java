package com.capitalone.eds.salesforce.fetch.util;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchException;
import com.capitalone.eds.salesforce.fetch.model.TableMetadata;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;

/**
 * Created by uah745 on 9/1/16.
 */
public class TableMetaDataCacheTest {

    @Test
    public void getTableMetaDataTest() {
        TableMetaDataCache testCache = createTableMetaDataCache();
        TableMetadata test1 = createTableMetaData();
        TableMetadata test2 = createTableMetaData();
        checkAssertEquals(testCache, test1);
        checkAssertEquals(testCache, test2);
    }

    @Test (expected = SalesforceFetchException.class)
    public void getNonExistentTableMetaDataTest() throws SalesforceFetchException {
        TableMetaDataCache testCache = createTableMetaDataCache();
        testCache.getTableMetaData("NONEXISTENT_DATA");
    }

    private void checkAssertEquals(TableMetaDataCache expected, TableMetadata result) {
        try {
            Assert.assertArrayEquals(expected.getTableMetaData("TEST 1").getColumns().toArray(), result.getColumns().toArray());
        } catch (SalesforceFetchException e) {
            e.printStackTrace();
        }
    }

    private TableMetadata createTableMetaData () {
        ArrayList<String> testColumns1 = new ArrayList<>();
        testColumns1.add("Id");
        testColumns1.add("Date");
        return new TableMetadata("TEST 1", testColumns1);
    }

    private TableMetaDataCache createTableMetaDataCache () {
        TableMetaDataCache testTableMetaDataCache = new TableMetaDataCache();

        TableMetadata testTableMetaData1 = createTableMetaData();

        ArrayList<String> testColumns2 = new ArrayList<>();
        testColumns2.add("TEST COLUMN");
        testColumns2.add("TEST COLUMN 2");
        testColumns2.add("STRING COLUMN");
        TableMetadata testTableMetaData2 = new TableMetadata("TEST 2", testColumns2);

        testTableMetaDataCache.register(testTableMetaData1);
        testTableMetaDataCache.register(testTableMetaData2);

        return testTableMetaDataCache;
    }
}
