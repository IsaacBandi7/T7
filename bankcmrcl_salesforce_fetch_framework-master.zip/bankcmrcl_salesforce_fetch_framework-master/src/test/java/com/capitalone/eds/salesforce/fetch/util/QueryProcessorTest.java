package com.capitalone.eds.salesforce.fetch.util;


import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class QueryProcessorTest {

    @Test
    public void testTableName(){

        String query = getSimpleQuery();
        String tableName = QueryProcessor.getTableMetadataFromQuery(query).getTableName();
        Assert.assertEquals(tableName,"PERSON");
    }

    @Test
    public void testColNames(){

        String query = getSimpleQuery();
        List<String> columns = QueryProcessor.getTableMetadataFromQuery(query).getColumns();
        Assert.assertEquals("name",columns.get(0));
    }

    @Test
    public void testTableNameFromWhereClauseQuery(){

        String query = getQueryWithWhereClause();
        String tableName = QueryProcessor.getTableMetadataFromQuery(query).getTableName();
        Assert.assertEquals(tableName,"PERSON");
    }

    @Test
    public void testColNamesFromWhereClauseQuery(){

        String query = getQueryWithWhereClause();
        List<String> columns = QueryProcessor.getTableMetadataFromQuery(query).getColumns();
        Assert.assertEquals("name",columns.get(0));
    }

    @Test
    public void testTableNameFromEmptyQuery(){

        String query = "";
        String tableName = QueryProcessor.getTableMetadataFromQuery(query).getTableName();
        Assert.assertEquals(tableName,"");
    }

    @Test
    public void testColNamesFromEmptyQuery(){

        String query = "";
        List<String> columns = QueryProcessor.getTableMetadataFromQuery(query).getColumns();
        Assert.assertEquals(0,columns.size());
    }

    private String getSimpleQuery(){

        return "SELECT name,address,age FROM PERSON";
    }

    private String getQueryWithWhereClause(){

        return "SELECT name,address,age FROM PERSON where name == STAN";
    }
}
