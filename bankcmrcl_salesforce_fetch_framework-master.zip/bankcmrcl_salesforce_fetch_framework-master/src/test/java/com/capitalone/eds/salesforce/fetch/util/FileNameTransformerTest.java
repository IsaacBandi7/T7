package com.capitalone.eds.salesforce.fetch.util;

import com.capitalone.eds.salesforce.fetch.input.Arguments;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FileNameTransformerTest {

    @InjectMocks
    private FileNameTransformer fileNameTransformer;

    @Mock
    private Arguments arguments;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);

        when(arguments.getAppTrim()).thenReturn("__c");
        when(arguments.getAppPrefix()).thenReturn("20160909_");
        when(arguments.getAppSuffix()).thenReturn("_raw.txt");
    }

    @Test
    public void testGetName() {
        fileNameTransformer.setTableName("TE__cST__c");
        String filePath = fileNameTransformer.getName();
        Assert.assertEquals(filePath, "20160909_TEST_raw.txt");
    }

}
