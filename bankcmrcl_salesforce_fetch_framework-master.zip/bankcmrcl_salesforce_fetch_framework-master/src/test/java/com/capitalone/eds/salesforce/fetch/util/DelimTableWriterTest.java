package com.capitalone.eds.salesforce.fetch.util;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchException;
import com.capitalone.eds.salesforce.fetch.input.Arguments;
import com.capitalone.eds.salesforce.fetch.model.Table;
import com.capitalone.eds.salesforce.fetch.model.TableMetadata;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class DelimTableWriterTest {
    @InjectMocks
    private DelimTableWriter delimTableWriter;

    @Mock
    private TableMetaDataCache tableMetaDataCache;

    @Mock
    private Arguments arguments;

    private Table table;

    @Before
    public void initMocks() throws SalesforceFetchException {
        MockitoAnnotations.initMocks(this);

        getTable();

        when(arguments.getOutputDir()).thenReturn("/tmp");
        when(arguments.getDelim()).thenReturn("|");

        List<String> columnNames = new ArrayList<>();
        columnNames.add("Id");
        columnNames.add("test_field");

        TableMetadata tableMetadata = new TableMetadata("TEST", columnNames);

        when(tableMetaDataCache.getTableMetaData(table.getTableName()))
                .thenReturn(tableMetadata);
    }

    @Test
    public void testWrite() throws SalesforceFetchException, IOException {
        /*TableWriter writer = new DelimTableWriter();
        writer.write(table);
        byte[] testFile = getFile(table);
        byte[] expectedOutputFile = getFile("testExpectedOutput.txt");
        Assert.assertEquals(testFile,expectedOutputFile);*/
    }

    private void getTable () {
        table = new Table();
        table.setTableName("TEST");
        table.setNextURL("TEST_URL");
        ArrayList<Map<String,String>> testRecords = new ArrayList<>();
        Map<String,String> testRecord1 = new HashMap<>();
        testRecord1.put("Id", "TEST_1");
        testRecord1.put("test_field", "1");

        Map<String,String> testRecord2 = new HashMap<>();
        testRecord1.put("Id", "TEST_2");
        testRecord1.put("test_field", "2");
        testRecords.add(testRecord1);
        testRecords.add(testRecord2);

        table.setRecords(testRecords);
    }

    private byte[] getFile(Table table) throws IOException {
        String outDir = arguments.getOutputDir();
        String fileName = outDir + "/" + table.getTableName() + ".txt";
        return Files.readAllBytes(Paths.get(fileName));
    }

    private byte[] getFile(String fileName) throws IOException {
        URL url = this.getClass().getClassLoader().getResource(fileName);
        return Files.readAllBytes(Paths.get(url.getFile()));
    }
}
