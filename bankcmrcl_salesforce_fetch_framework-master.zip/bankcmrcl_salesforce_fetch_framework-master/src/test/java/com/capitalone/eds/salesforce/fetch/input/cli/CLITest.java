package com.capitalone.eds.salesforce.fetch.input.cli;

import com.capitalone.eds.salesforce.fetch.util.Configuration;
import org.junit.Assert;
import org.junit.Test;

public class CLITest {

    @Test
    public void testNumQueries(){

        CLI cli = getSimpleCLI();
        Configuration config = cli.getConfiguration();
        Assert.assertEquals(5,config.getQueries().size());
    }

    @Test
    public void testSoapEndPointUrl(){

        CLI cli = getSimpleCLI();
        Configuration config = cli.getConfiguration();
        Assert.assertEquals("https://test.salesforce.com/services/Soap/u/37.0",config.getProperty(ConfigKeys.SALESFORCE_SOAPENDPOINT_KEY.value()));
    }

    private CLI getSimpleCLI(){

        ClassLoader classLoader = CLITest.class.getClassLoader();
        String queryFile = classLoader.getResource("testQueries.yaml").getFile();
        String confFile = classLoader.getResource("testUserConfigs.yaml").getFile();
        String[] args = {"-query",queryFile,"-conf",confFile};
        return new CLI(args);
    }
}
