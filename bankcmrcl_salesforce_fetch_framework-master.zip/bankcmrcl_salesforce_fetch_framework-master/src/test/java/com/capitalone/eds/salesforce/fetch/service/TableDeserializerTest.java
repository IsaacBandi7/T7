package com.capitalone.eds.salesforce.fetch.service;


import com.capitalone.eds.salesforce.fetch.model.Table;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.*;

public class TableDeserializerTest {

    @Test
    public void testTableName() throws IOException {

        String result = getSimpleTableStr();
        Table table = new ObjectMapper().readValue(result,Table.class);
        Assert.assertEquals("TEST", table.getTableName());
    }

    @Test
    public void testTableNextURL() throws IOException {
        String result = getSimpleTableStr();
        Table table = new ObjectMapper().readValue(result, Table.class);
        Assert.assertEquals("/services/data/v20.0/sobjects/TEST/TEST/TEST", table.getNextURL());
    }

    @Test
    public void testTableRecords() throws IOException {
        String result = getSimpleTableStr();
        Table table = new ObjectMapper().readValue(result, Table.class);
        Assert.assertEquals(getTestRecords(), table.getRecords());
    }

    private String getSimpleTableStr(){

        return "{" +
                "\"done\": true," +
                "\"records\": [" +
                "{" +
                "\"Id\": \"0015000000VALDtAAP\"," +
                "\"attributes\": {" +
                "\"type\": \"TEST\"," +
                "\"url\": \"/services/data/v20.0/sobjects/Account/0015000000VALDtAAP\"" +
                "}" +
                "}," +
                "{" +
                "\"Id\": \"0015000000VALDuAAP\"," +
                "\"attributes\": {" +
                "\"type\": \"TEST\"," +
                "\"url\": \"/services/data/v20.0/sobjects/Account/0015000000VALDuAAP\"" +
                "}" +
                "}]," +
                "\"nextRecordsUrl\": \"/services/data/v20.0/sobjects/TEST/TEST/TEST\"" +
                "}";
    }

    private List<Map<String,String>> getTestRecords () {
        List<Map<String,String>> testRecords = new ArrayList<Map<String, String>>();
        HashMap<String,String> firstRecord = new HashMap<>();
        firstRecord.put("Id", "0015000000VALDtAAP");
        HashMap<String,String> secondRecord = new HashMap<>();
        secondRecord.put("Id", "0015000000VALDuAAP");
        testRecords.add(firstRecord);
        testRecords.add(secondRecord);
        return testRecords;
    }
}
