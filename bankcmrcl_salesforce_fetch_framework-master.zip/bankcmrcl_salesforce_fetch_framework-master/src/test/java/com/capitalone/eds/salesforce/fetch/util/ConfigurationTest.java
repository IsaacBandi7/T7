package com.capitalone.eds.salesforce.fetch.util;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchRuntimeException;
import com.sun.org.apache.bcel.internal.util.ClassLoader;
import org.junit.Assert;
import org.junit.Test;

import java.net.URL;

public class ConfigurationTest {

    @Test
    public void testDefaultConfigsGetProperty() {
        Configuration configuration = getConfiguration();
        String userName = configuration.getProperty("salesforce.username");
        //Assert.assertEquals(userName, "hadoop@capitalone.com.full");
    }

    @Test
    public void testGetQueries() {
        Configuration configuration = getConfiguration();
        Object[] queries = configuration.getQueries().toArray();
        Assert.assertArrayEquals(queries, getExpectedQueries());
    }

    @Test
    public void testUserConfigsGetProperty() {
        Configuration configuration = getConfiguration("testQueries.yaml", "testUserConfigs.yaml");
        String userName = configuration.getProperty("salesforce.username");
        Assert.assertEquals(userName, "hadoop@capitalone.com.full");
    }

/*    @Test(expected = SalesforceFetchRuntimeException.class)
    public void testIncorrectlyFormattedQueriesYamlFile () {
        getConfiguration("testBadlyFormattedQueries.yaml", "testUserConfigs.yaml");
    }*/


    @Test(expected = SalesforceFetchRuntimeException.class)
    public void testNonExistentQueryFile () {
        getConfigurationUsingBadQueryFileName("nonExistentQueryFile.yaml");
    }

    private Object[] getExpectedQueries() {
        return new Object[]{
            "select Id,OwnerId,IsDeleted,Name,CreatedDate,CreatedById,LastModifiedDate,LastModifiedById,SystemModstamp,LastViewedDate,LastReferencedDate,CBSA_Code__c,CBSA_Type__c FROM CBSA__c",
                "select Id,IsDeleted,Name,CreatedDate,CreatedById,LastModifiedDate,LastModifiedById,SystemModstamp,ContactId__c,LoanId__c,Contact_Name__c,Guarantor__c,Role__c FROM Loan_Contact__c",
                "select Id,OwnerId,IsDeleted,Name,CreatedDate,CreatedById,LastModifiedDate,LastModifiedById,SystemModstamp,LastViewedDate,LastReferencedDate FROM Portfolio__c",
                "select Id,IsDeleted,Name,CreatedDate,CreatedById,LastModifiedDate,LastModifiedById,SystemModstamp,PropertyId__c,ContactId__c,Contact_Name__c FROM Property_Contact__c",
                "select Id,IsDeleted,Name,CreatedDate,CreatedById,LastModifiedDate,LastModifiedById,SystemModstamp,Account__c,Contact__c,Role__c,Contact_Name__c FROM Relationship__c"};
    }

    private Configuration getConfigurationUsingBadQueryFileName(String queryFileName) {
        return new Configuration(queryFileName);
    }

    private Configuration getConfiguration(String queryFileName, String configFileName) {
        URL queryURL = ClassLoader.getSystemResource(queryFileName);
        URL configURL = ClassLoader.getSystemResource(configFileName);
        return new Configuration(queryURL.getFile(), configURL.getFile());
    }

    private Configuration getConfiguration() {
        URL queryURL = ClassLoader.getSystemResource("testQueries.yaml");
        return new Configuration(queryURL.getFile());
    }
}
