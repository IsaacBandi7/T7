package com.capitalone.eds.salesforce.fetch.input;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchException;
import com.capitalone.eds.salesforce.fetch.input.cli.CLI;
import com.capitalone.eds.salesforce.fetch.model.Query;
import com.capitalone.eds.salesforce.fetch.model.TableMetadata;
import com.capitalone.eds.salesforce.fetch.util.TableMetaDataCache;
import com.capitalone.eds.salesforce.fetch.util.Configuration;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;


import java.util.List;

public class ArgumentTest {


    @Test
    public void testQueries(){

        Arguments arguments = getArguments();
        List<Query> queries  = arguments.getQueries();
        Assert.assertEquals("CBSA__c", queries.get(0).getTableName());
    }

    @Test
    public void testTableMetaDataCacheEntry() throws SalesforceFetchException {

        Arguments arguments = getArguments();
        TableMetaDataCache tableMetaDataCache  = arguments.getTableMetaDataCache();
        TableMetadata tableMetadata = tableMetaDataCache.getTableMetaData("CBSA__c");
        Assert.assertEquals(13, tableMetadata.getColumns().size());
    }

    private Arguments getArguments(){

        CLI cli = getSimpleCLI();
        TableMetaDataCache tableMetaDataCache = new TableMetaDataCache();
        return new Arguments(cli,tableMetaDataCache);
    }

    private CLI getSimpleCLI(){

        ClassLoader classLoader = ArgumentTest.class.getClassLoader();
        String queryFile = classLoader.getResource("testQueries.yaml").getFile();
        String confFile = classLoader.getResource("testUserConfigs.yaml").getFile();
        String[] args = {"-query",queryFile,"-conf",confFile};
        return new CLI(args);
    }


}
