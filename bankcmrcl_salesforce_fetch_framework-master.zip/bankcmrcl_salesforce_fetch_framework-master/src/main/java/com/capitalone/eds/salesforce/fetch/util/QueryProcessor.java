package com.capitalone.eds.salesforce.fetch.util;


import com.capitalone.eds.salesforce.fetch.model.TableMetadata;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QueryProcessor {

    private static final String SQL_SELECT_QUERY_PATTERN = "(select|SELECT)(.*)(FROM|from)(\\s+)(\\w+)(.*)";;
    private static final Pattern selectQueryPattern = Pattern.compile(SQL_SELECT_QUERY_PATTERN);
    private static final int COLUMNS_GROUP_NUM_IN_SELECT_QUERY = 2;
    private static final int TABLENAME_GROUP_NUM_IN_SELECT_QUERY = 5;


    public static TableMetadata getTableMetadataFromQuery(String query) {

        String tableName = getTableName(query);
        List<String> colNames = getColNames(query);
        return new TableMetadata(tableName,colNames);
    }

    private static String getTableName(String query) {

        String tableName = "";
        if(validateQuery(query)){
            Matcher matcher = selectQueryPattern.matcher(query);
            while (matcher.find()) {
                tableName = matcher.group(TABLENAME_GROUP_NUM_IN_SELECT_QUERY);
            }
        }
        return tableName.trim();
    }

    private static List<String> getColNames(String query) {

        List<String> colNames= new ArrayList<>();
        if(validateQuery(query)){
            Matcher matcher = selectQueryPattern.matcher(query);
            while (matcher.find()) {
                String columnsLine = matcher.group(COLUMNS_GROUP_NUM_IN_SELECT_QUERY);
                String[] colNamesArray = columnsLine.trim().split(",");
                colNames = Arrays.asList(colNamesArray);
            }
        }
        return colNames;
    }

    private static boolean validateQuery(String query){

        return (query != null && !query.isEmpty()) ;
    }
}
