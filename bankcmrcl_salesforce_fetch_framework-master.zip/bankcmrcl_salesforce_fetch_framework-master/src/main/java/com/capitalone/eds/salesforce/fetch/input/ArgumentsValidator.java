package com.capitalone.eds.salesforce.fetch.input;


import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchRuntimeException;
import com.capitalone.eds.salesforce.fetch.model.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.List;

public class ArgumentsValidator {

    private final static Logger LOGGER = LoggerFactory.getLogger(ArgumentsValidator.class);


    public static void validate(Arguments arguments){

        LOGGER.info("Validating config values");
        checkFilesExist(arguments);
        checkOutputDirectoryExists(arguments);
        checkEmptyQueries(arguments);
    }

    private static void checkFilesExist(Arguments arguments) {

        String siebelCertFileLocation = arguments.getSiebelCert();
        String trustStoreLocation = arguments.getTrustStoreLocation();
        LOGGER.debug("Checking siebel Cert File");
        checkFileExists(siebelCertFileLocation);
        LOGGER.debug("Checking trust store File");
        checkFileExists(trustStoreLocation);
    }

    private static void checkFileExists(String fileLocation) {

        File confFile =  new File(fileLocation);
        if(!confFile.exists() || confFile.isDirectory()) {
            throw new SalesforceFetchRuntimeException("File does not exist: " + fileLocation);
        }
    }

    private static void checkOutputDirectoryExists(Arguments arguments) {

        LOGGER.debug("Checking User provided output directory");
        File outputDir =  new File(arguments.getOutputDir());
        if(!outputDir.exists() || !outputDir.isDirectory()) {
            throw new SalesforceFetchRuntimeException("Output directory does not exist: " + outputDir);
        }
    }

    private static void checkEmptyQueries(Arguments arguments) {

        LOGGER.debug("Checking for empty queries");
        List<Query> queries = arguments.getQueries();
        if(queries.isEmpty()){
            throw new SalesforceFetchRuntimeException("No query provided. Please provide queries via a valid file location/library");
        }
    }

}
