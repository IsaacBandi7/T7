package com.capitalone.eds.salesforce.fetch.model;

import java.util.List;

public class TableMetadata {

    private final String tableName;
    private final List<String> colNames;
    private String parentDir;

    public TableMetadata(String tableName,List<String> colNames){

        this.tableName = tableName;
        this.colNames = colNames;
    }


    public String getTableName() {
        return tableName;
    }


    public List<String> getColumns(){

        return colNames;
    }

    public void setParentDir(String parentDir){

        this.parentDir = parentDir;
    }

    public String getPath(){

        return parentDir + "/" + tableName + ".txt";
    }
}
