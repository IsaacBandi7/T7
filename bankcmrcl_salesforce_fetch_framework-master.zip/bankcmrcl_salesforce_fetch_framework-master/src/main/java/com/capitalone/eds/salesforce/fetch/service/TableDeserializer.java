package com.capitalone.eds.salesforce.fetch.service;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchRuntimeException;
import com.capitalone.eds.salesforce.fetch.model.Table;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.type.CollectionType;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;


public class TableDeserializer extends StdDeserializer<Table> {

    public TableDeserializer() {
        this(null);
    }

    public TableDeserializer(Class<?> vc) {
        super(vc);
    }

    public Table deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
            throws IOException {

        Table table = new Table();
        //getTableName(jsonParser)
        //removeAttr()
        //getRecords()
        //getNextURl()

        JsonNode node = jsonParser.getCodec().readTree(jsonParser);
        JsonNode records = node.get("records");
        if(records.get(0) != null) {

            String tableName = records.get(0).get("attributes").get("type").toString();
            tableName = tableName.replaceAll("^\"|\"$", "");
            table.setTableName(tableName);

            if (records.isArray()) {
                for (JsonNode record : records) {
                    if (record != null && record.has("attributes")) {
                        ((ObjectNode) record).remove("attributes");
                    }
                }
            } else {
                throw new SalesforceFetchRuntimeException("Something is up with the JSON \"records\" field.");
            }
        }

        ObjectMapper objectMapper = new ObjectMapper();
        CollectionType mapCollectionType = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, Map.class);
        ArrayList<Map<String,String>> recordsList = objectMapper.convertValue(records, mapCollectionType);

        table.setRecords(recordsList);
        if (node.has("nextRecordsUrl")) {
            table.setNextURL(node.get("nextRecordsUrl").asText());
        }

        return table;
    }
}
