package com.capitalone.eds.salesforce.fetch.input.cli;


import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

class OptionProvider {


    static Options prepareOptions(){

        Option help = getHelpOption();
        Option queryFile = getQueryFileOption();
        Option confFile = getConfFileOption();
        Option[] options = {help,queryFile,confFile};
        return getCliOptions(options);
    }

    private static Option getHelpOption() {

        return new Option(CLIArgs.HELP.value(), "print this message" );
    }

    private static  Option getQueryFileOption() {

        return Option.builder(CLIArgs.QUERY_FILE.value())
                .argName( "file" )
                .hasArg()
                .desc(  "Query File Location" )
                .build();
    }

    private static  Option getConfFileOption() {

        return Option.builder(CLIArgs.CONF_FILE.value())
                .argName( "file" )
                .hasArg()
                .desc(  "Config file location" )
                .build();
    }

    private static  Options getCliOptions(Option[] prepOptions) {

        Options options = new Options();
        for(Option option : prepOptions){
            options.addOption(option);
        }
        return options;
    }





}
