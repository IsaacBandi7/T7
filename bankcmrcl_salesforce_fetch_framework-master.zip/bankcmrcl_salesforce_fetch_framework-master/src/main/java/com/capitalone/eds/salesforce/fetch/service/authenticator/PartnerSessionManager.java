package com.capitalone.eds.salesforce.fetch.service.authenticator;


import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchRuntimeException;
import com.capitalone.eds.salesforce.fetch.input.Arguments;
import com.capitalone.eds.salesforce.fetch.service.SalesforceClient;
import com.sforce.soap.partner.PartnerConnection;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PartnerSessionManager implements SessionManager{

    private final Arguments arguments;
    private SforceAuthResult sforceAuthResult;
    private PartnerConnection connection;
    private final Logger LOGGER= LoggerFactory.getLogger(SessionManager.class);

    public PartnerSessionManager(Arguments arguments){

        this.arguments = arguments;
    }

    @Override
    public SforceAuthResult getSforceAuthResult(SalesforceClient sforceClient) {

        if (sforceAuthResult == null) {
            return getAuthResultFromSforce(sforceClient);
        } else {
            return sforceAuthResult;
        }
    }

    private SforceAuthResult getAuthResultFromSforce(SalesforceClient sforceClient) {

        LOGGER.info("Preparing config and system values for Salesforce Authentication object");
        setSystemProps();
        ConnectorConfig partnerConfig = getPartnerConfig();
        tryLoginSforce(partnerConfig,sforceClient);
        sforceAuthResult = getAuthResultFromConfig();
        return sforceAuthResult;
    }

    private void setSystemProps() {

        System.setProperty("javax.net.ssl.keyStore", arguments.getSiebelCert());
        System.setProperty("javax.net.ssl.keyStorePassword", arguments.getSiebelCertPswd());
        System.setProperty("javax.net.ssl.trustStore", arguments.getTrustStoreLocation());
        System.setProperty("javax.net.ssl.trustStorePassword", arguments.getTrustStorePswd());
    }

    private ConnectorConfig getPartnerConfig() {

        ConnectorConfig partnerConfig = new ConnectorConfig();
        partnerConfig.setUsername(arguments.getUserName());
        partnerConfig.setPassword(arguments.getUserPswd());
        partnerConfig.setAuthEndpoint(arguments.getAuthEndPointURL());
        partnerConfig.setRequestHeader("EndPointURL",arguments.getSoapEndPointURL());
        return partnerConfig;
    }

    private void tryLoginSforce(ConnectorConfig partnerConfig,SalesforceClient sforceClient) {

        try {
            LOGGER.info("Login to salesforce.....");
            connection = sforceClient.connect(partnerConfig);
        } catch (ConnectionException e) {
            throw new SalesforceFetchRuntimeException("Could not login to Salesforce "  + e.getMessage());
        }
    }


    private SforceAuthResult getAuthResultFromConfig() {

        LOGGER.info("Creating authentication object.");
        String sessionID = getSessionID();
        String restUrl= getRestUrl();
        return new SforceAuthResult(sessionID,restUrl);
    }

    private String getSessionID(){

        String sessionID = connection.getSessionHeader().getSessionId();
        LOGGER.info("Session ID details: " + sessionID);
        return sessionID;
    }

    private String getRestUrl(){

        String soapUrl=connection.getConfig().getServiceEndpoint();
        String baseRestUrl=soapUrl.substring(0,soapUrl.indexOf("/services"));
        LOGGER.info("Rest url details: " + baseRestUrl);
        return baseRestUrl;
    }
}
