package com.capitalone.eds.salesforce.fetch.util;


import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchException;
import com.capitalone.eds.salesforce.fetch.model.Query;
import com.capitalone.eds.salesforce.fetch.model.Table;

public interface TableWriter{

    void write(Table table) throws SalesforceFetchException;
    void deleteFile(Query query) throws SalesforceFetchException;
}
