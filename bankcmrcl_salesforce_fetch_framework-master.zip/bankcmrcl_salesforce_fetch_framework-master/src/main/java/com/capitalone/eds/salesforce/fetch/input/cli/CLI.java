package com.capitalone.eds.salesforce.fetch.input.cli;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchRuntimeException;
import com.capitalone.eds.salesforce.fetch.util.Configuration;
import org.apache.commons.cli.*;


public class CLI {

    private final String HELP_INFO ="Argument template : \n" + "-query {query_file_location} -conf {conf_file_location}";
    private CommandLine cli;

    public CLI(String[] args){

        Options options = getOptions();
        cli = tryGetCommonsCLI(options,args);
        if(isHelpOptionProvided(cli)){
            printUsageAndExit();
        }
    }

    private Options getOptions() {

        return OptionProvider.prepareOptions();
    }

    private CommandLine tryGetCommonsCLI(Options options,String[] args) {

        CommandLineParser cliParser = new DefaultParser();
        try {
            CommandLine commandLine = cliParser.parse(options,args);
            return commandLine;
        } catch (ParseException e) {
            throw new SalesforceFetchRuntimeException(e.getMessage());
        }
    }


    private  boolean isHelpOptionProvided(CommandLine cli) {

        return cli.hasOption(CLIArgs.HELP.value());
    }


    private void printUsageAndExit() {

        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp(HELP_INFO,getOptions());
        System.exit(0);
    }


    public Configuration getConfiguration() {

        String queryFile = cli.getOptionValue(CLIArgs.QUERY_FILE.value());
        String confFile = cli.getOptionValue(CLIArgs.CONF_FILE.value());
        return new Configuration(queryFile,confFile);
    }

}
