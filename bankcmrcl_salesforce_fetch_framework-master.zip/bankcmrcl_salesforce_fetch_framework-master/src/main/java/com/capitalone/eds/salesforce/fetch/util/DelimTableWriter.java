package com.capitalone.eds.salesforce.fetch.util;


import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchException;
import com.capitalone.eds.salesforce.fetch.input.Arguments;
import com.capitalone.eds.salesforce.fetch.model.Query;
import com.capitalone.eds.salesforce.fetch.model.Table;
import com.capitalone.eds.salesforce.fetch.model.TableMetadata;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Map;

public class DelimTableWriter implements  TableWriter {

    @Autowired
    private TableMetaDataCache tableMetaDataCache;

    @Autowired
    private Arguments arguments;

    @Autowired
    private FileNameTransformer fileNameTrans;

    @Override
    public void write(Table table) throws SalesforceFetchException {

        String fileName = getFilePath(table.getTableName());
        String contents = getFileContents(table);
        writeContentsToFile(fileName,contents);
    }

    private String getFilePath(String tableName) {

        String outDir = arguments.getOutputDir();
        fileNameTrans.setTableName(tableName);
        String fileName = fileNameTrans.getName();
        return outDir + "/" + fileName;
    }

    private String getFileContents(Table table) throws SalesforceFetchException {

        List<Map<String,String>> records = table.getRecords();
        String tableName = getTableName(table);
        TableMetadata tableMetadata = tableMetaDataCache.getTableMetaData(tableName);
        List<String> columns = tableMetadata.getColumns();
        StringBuilder sb = new StringBuilder();
        if(records.size() > 0){
            for(Map<String,String> record : records){
                String lineContent = getLineContent(columns,record);
                sb.append(lineContent);
                sb.append(System.lineSeparator());
            }
        }
        return sb.toString();
    }

    private String getLineContent(List<String> colNames, Map<String, String> record) {

        String delim = arguments.getDelim();

        StringBuilder sb = new StringBuilder();
        for(String colName : colNames){
            if (record.containsKey(colName)) {
                Object colValue = record.get(colName);
                sb.append(colValue)
                        .append(delim);
            }
        }
        sb.deleteCharAt(sb.lastIndexOf(delim));
        return sb.toString();
    }


    private void writeContentsToFile(String fileName, String contents) throws SalesforceFetchException {
        try {
            Files.write(Paths.get(fileName), contents.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND, StandardOpenOption.WRITE);
        } catch (IOException e) {
            throw new SalesforceFetchException("Error: Failed to Write");
        }
    }

    public void deleteFile(Query query) throws SalesforceFetchException{
        String filePath = arguments.getOutputDir() + "/" + getFilePath(query.getTableName());
        try {
            Files.deleteIfExists(Paths.get(filePath));
        } catch (IOException e) {
            throw new SalesforceFetchException("Error: Failed to delete");
        }
    }

    public String getTableName(Table table) {

        return table.getTableName();
    }
}
