package com.capitalone.eds.salesforce.fetch.model;

import com.capitalone.eds.salesforce.fetch.service.TableDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@JsonDeserialize (using = TableDeserializer.class)
public class Table {

    private String tableName;
    private List<Map<String,String>> records;
    private String nextURL;

    public Table(){
        this.records = new ArrayList<Map<String,String>>();
    }

    public void setTableName (String tableName) {
        this.tableName = tableName;
    }

    public void setRecords (ArrayList<Map<String,String>> records) {
        this.records = records;
    }

    public String getTableName () {
        return this.tableName;
    }

    public List<Map<String,String>> getRecords () {
        return this.records;
    }

    public String getNextURL () {
        return this.nextURL;
    }

    public void setNextURL (String nextURL) {
        this.nextURL = nextURL;
    }

    public boolean hasNextUrl(){

        return (nextURL != null) && (!nextURL.isEmpty());
    }

}
