package com.capitalone.eds.salesforce.fetch.main;

import com.capitalone.eds.salesforce.fetch.input.Arguments;
import com.capitalone.eds.salesforce.fetch.input.ArgumentsValidator;
import com.capitalone.eds.salesforce.fetch.service.SalesforceClient;
import com.capitalone.eds.salesforce.fetch.service.query.QueryHandler;
import com.capitalone.eds.salesforce.fetch.service.authenticator.SessionManager;
import com.capitalone.eds.salesforce.fetch.service.authenticator.SforceAuthResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class SalesforceFetch {

    @Autowired
    private SessionManager sessionManager;

    @Autowired
    private Arguments arguments;

    @Autowired
    private QueryHandler queryHandler;

    @Autowired
    private SalesforceClient sforceClient;

    private final Logger LOGGER= LoggerFactory.getLogger(SalesforceFetch.class);


    public void execute() {

        LOGGER.info("Starting execution of program");
        ArgumentsValidator.validate(arguments);
        SforceAuthResult sforceAuthResult = getSForceAuthResult();
        queryHandler.setAuthResult(sforceAuthResult);
        queryHandler.runSfQueries();
    }

    private SforceAuthResult getSForceAuthResult() {

        SforceAuthResult SForceAuthResult = sessionManager.getSforceAuthResult(sforceClient);
        return SForceAuthResult;
    }

}
