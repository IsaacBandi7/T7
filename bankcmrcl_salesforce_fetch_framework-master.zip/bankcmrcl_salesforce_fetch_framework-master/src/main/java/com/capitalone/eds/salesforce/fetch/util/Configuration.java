package com.capitalone.eds.salesforce.fetch.util;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchRuntimeException;
import org.yaml.snakeyaml.Yaml;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;


public class Configuration {

    private final Logger logger = Logger.getLogger(Configuration.class);
    private Map<String, String> propertiesMap;
    private List<String> queryList;

    public Configuration(String queryFilePath) {
        //loadDefaultConfigs();
        propertiesMap = new HashMap<>();
        extractDataFromQueryFile(queryFilePath);
    }

    public Configuration(String queryFileName, String configsFileName) {
        //loadDefaultConfigs();
        propertiesMap = new HashMap<>();
        if(configsFileName != null && !configsFileName.isEmpty()){
            loadDataFromConfigFile(configsFileName);
        }
        extractDataFromQueryFile(queryFileName);
    }

    private void loadDefaultConfigs() {
        InputStream stream = Thread.currentThread().getContextClassLoader().getSystemResourceAsStream("defaultConfigs.yaml");
        try {
            propertiesMap = loadDataFromYamlFile(stream);
            stream.close();
        } catch (IOException e) {
            logger.error(e);
        }
    }

    private void loadDataFromConfigFile(String configsFilePath) {

        try {
            InputStream stream = new FileInputStream(configsFilePath);
            Map<String,String> data = loadDataFromYamlFile(stream);
            propertiesMap.putAll(data);
            stream.close();
        } catch (IOException e) {
            logger.error(e);
        }
    }

    private void extractDataFromQueryFile (String queryFileName) {

        try {
            if(!queryFileName.isEmpty()){
                InputStream stream = new FileInputStream(queryFileName);
                queryList = (List<String>) loadDataFromYamlFile(stream).get("Queries");
                stream.close();
            }
        } catch (IOException e) {
            logger.error(e);
            throw new SalesforceFetchRuntimeException("Error loading query file: " + queryFileName);
        }
    }

    private Map loadDataFromYamlFile (InputStream fileStream) throws FileNotFoundException{

        Map<String, String> data;
        Yaml yaml = new Yaml();
        data = (Map<String,String>)yaml.load(fileStream);
        return data;
    }

    public String getProperty (String key) {

        return String.valueOf(propertiesMap.get(key));
    }

    public List<String> getQueries () {
        return this.queryList;
    }
}
