package com.capitalone.eds.salesforce.fetch.service;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchRuntimeException;
import com.capitalone.eds.salesforce.fetch.input.Arguments;
import com.capitalone.eds.salesforce.fetch.model.Table;
import com.capitalone.eds.salesforce.fetch.service.authenticator.SforceAuthResult;

import javax.net.ssl.*;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import com.sforce.soap.partner.Connector;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;
import com.sforce.soap.partner.PartnerConnection;
import org.glassfish.jersey.apache.connector.ApacheConnectorProvider;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.springframework.beans.factory.annotation.Autowired;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;


public class SalesforceClient {

    @Autowired
    private Arguments arguments;

    public PartnerConnection connect(ConnectorConfig partnerConfig) throws ConnectionException {

        return Connector.newConnection(partnerConfig);
    }

    public Table execRestQuery(String query,SforceAuthResult sforceAuthResult) {

        Client httpClient = getJerseyClient();
        return runQuery(httpClient,query,sforceAuthResult);
    }

    private Client getJerseyClient() {
        SSLContext sslContext = getSSLContext();
        ClientConfig config = new ClientConfig();
        config.connectorProvider(new ApacheConnectorProvider())
            .property(ClientProperties.PROXY_URI, arguments.getProxyUrl())
            .property(ClientProperties.PROXY_USERNAME, arguments.getProxyUser())
            .property(ClientProperties.PROXY_PASSWORD, arguments.getProxyPswd())
            .register(JacksonFeature.class);

       return ClientBuilder.newBuilder().sslContext(sslContext).withConfig(config).register(JacksonFeature.class).build();
    }

    private SSLContext getSSLContext () {

        try {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }

            }}, new SecureRandom());
            return sslContext;
        } catch (Exception e) {
            throw new SalesforceFetchRuntimeException("Could not setup ssl context" + e.getMessage());
        }
    }

    private Table runQuery(Client client, String query,SforceAuthResult sforceAuthResult) {

        WebTarget webTarget = client.target(sforceAuthResult.getBaseRestUrl())
                               .path(sforceAuthResult.getRestUrlPath());

        if(sforceAuthResult.hasQueryParam()){
            webTarget = webTarget.queryParam(sforceAuthResult.getQueryKey(),query);
        }

        return webTarget.request(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + sforceAuthResult.getSessionID())
                .get(Table.class);

    }

}
