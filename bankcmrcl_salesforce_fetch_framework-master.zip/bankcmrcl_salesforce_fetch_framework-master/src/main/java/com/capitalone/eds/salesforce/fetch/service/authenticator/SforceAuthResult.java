package com.capitalone.eds.salesforce.fetch.service.authenticator;


public class SforceAuthResult {

    private final String sessionID;
    private final String baseRestUrl;
    private String restUrlPath;
    private String queryKey;

    public SforceAuthResult(String sessionID, String baseUrl){

        this.sessionID = sessionID;
        this.baseRestUrl = baseUrl;
        this.restUrlPath = "/services/data/v37.0/query/";
        this.queryKey = "q";
    }

    public String getSessionID() {
        return sessionID;
    }

    public String getBaseRestUrl() {
        return baseRestUrl;
    }

    public String getRestUrlPath() {
        return restUrlPath;
    }

    public void setRestUrlPath(String restUrlPath) {
        this.restUrlPath = restUrlPath;
    }

    public void removeQueryKey(){

        this.queryKey = "";
    }

    public boolean hasQueryParam(){

        return !queryKey.isEmpty();
    }

    public String getQueryKey() {
        return queryKey;
    }

    public void reset(){

        this.restUrlPath = "/services/data/v37.0/query/";
        this.queryKey = "q";
    }
}
