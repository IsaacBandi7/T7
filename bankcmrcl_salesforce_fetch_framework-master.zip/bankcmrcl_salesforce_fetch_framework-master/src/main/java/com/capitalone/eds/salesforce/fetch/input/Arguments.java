package com.capitalone.eds.salesforce.fetch.input;


import com.capitalone.eds.salesforce.fetch.input.cli.CLI;
import com.capitalone.eds.salesforce.fetch.input.cli.ConfigKeys;
import com.capitalone.eds.salesforce.fetch.model.Query;
import com.capitalone.eds.salesforce.fetch.util.TableMetaDataCache;
import com.capitalone.eds.salesforce.fetch.util.Configuration;
import com.capitalone.eds.salesforce.fetch.model.TableMetadata;
import com.capitalone.eds.salesforce.fetch.util.QueryProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class Arguments {


        private TableMetaDataCache tableMetaDataCache;

        private final Logger LOGGER= LoggerFactory.getLogger(ArgumentsValidator.class);

        private String authEndPointURL;
        private String userName;
        private String userPswd;
        private String soapEndPointURL;
        private String siebelCert;
        private String siebelCertPswd;
        private String trustStoreLocation;
        private String trustStrorePswd;
        private List<Query> queries;
        private String outputDirectory;
        private String delim;
        private Configuration configuration;

        public Arguments(CLI cli,TableMetaDataCache tableMetaDataCache){

            this.queries = new ArrayList<>();
            this.configuration = cli.getConfiguration();
            this.tableMetaDataCache = tableMetaDataCache;
            populateArgumentsFromConfig();
        }

        private void populateArgumentsFromConfig() {

            LOGGER.info("Populating config values into arguments object");
            setAuthEndPointURL(configuration.getProperty(ConfigKeys.SALESFORCE_AUTHENDPOINT_KEY.value()));
            setUserName(configuration.getProperty(ConfigKeys.SALESFORCE_USERNAME_KEY.value()));
            setUserPswd(configuration.getProperty(ConfigKeys.SALESFORCE_PASSWORD_KEY.value()));
            setSoapEndPointURL(configuration.getProperty(ConfigKeys.SALESFORCE_SOAPENDPOINT_KEY.value()));
            setSiebelCert(configuration.getProperty(ConfigKeys.SALESFORCE_SIEBELCERT_KEY.value()));
            setSiebelCertPswd(configuration.getProperty(ConfigKeys.SALESFORCE_SIEBELCERTPWD_KEY.value()));
            setTrustStoreLocation(configuration.getProperty(ConfigKeys.SALESFORCE_TRUSTSTORE_KEY.value()));
            setTrustStorePswd(configuration.getProperty(ConfigKeys.SALESFORCE_TRUSTSTOREPWD_KEY.value()));
            setOutputDir(configuration.getProperty(ConfigKeys.SALESFORCE_OUTPUTDIR_KEY.value()));
            setDelim(configuration.getProperty(ConfigKeys.DELIMITER.value()));
            setQueries(configuration.getQueries());
        }

        public String getProxyUrl(){

            return configuration.getProperty(ConfigKeys.PROXY_URL.value());
        }

        public String getProxyUser(){

            return configuration.getProperty(ConfigKeys.PROXY_USER.value());
        }

        public String getProxyPswd(){

            return configuration.getProperty(ConfigKeys.PROXY_PSWD.value());
        }

        public String getAppTrim() {
            return configuration.getProperty(ConfigKeys.APP_TRIM.value());
        }

        public String getAppPrefix() {
            return configuration.getProperty(ConfigKeys.APP_PREFIX.value());
        }

        public String getAppSuffix() {
            return configuration.getProperty(ConfigKeys.APP_SUFFIX.value());
        }

        public String getAuthEndPointURL() {
            return authEndPointURL;
        }

        private void setAuthEndPointURL(String authEndPointURL) {
            this.authEndPointURL = authEndPointURL;
        }

        public String getUserName() {
            return userName;
        }

        private void setUserName(String userName) {
            this.userName = userName;
        }

        public String getUserPswd() {
            return userPswd;
        }

        private void setUserPswd(String pswd) {
            this.userPswd = pswd;
        }

        public String getSoapEndPointURL() {
            return soapEndPointURL;
        }

        private void setSoapEndPointURL(String soapEndPointURL) {
            this.soapEndPointURL = soapEndPointURL;
        }

        public String getSiebelCert() {
            return siebelCert;
        }

        private void setSiebelCert(String siebelCert) {
            this.siebelCert = siebelCert;
        }

        public String getSiebelCertPswd() {
            return siebelCertPswd;
        }

        private void setSiebelCertPswd(String siebelCertPswd) {
            this.siebelCertPswd = siebelCertPswd;
        }

        public String getTrustStoreLocation() {
            return trustStoreLocation;
        }

        private void setTrustStoreLocation(String trustStoreLocation) {
            this.trustStoreLocation = trustStoreLocation;
        }

        public String getTrustStorePswd() {
            return trustStrorePswd;
        }

        private void setTrustStorePswd(String trustStrorePswd) {
            this.trustStrorePswd = trustStrorePswd;
        }

        public void setQueries(List<String> queries) {

            createAndRegisterTableMetadata(queries);
        }

        public List<Query> getQueries(){
            return queries;
        }

        public String getOutputDir() {
            return outputDirectory;
        }

        private void setOutputDir(String outputDirectory) {
            this.outputDirectory = outputDirectory;
        }

        public String getDelim() {
            return delim;
        }

        private void setDelim(String delimitter) {
            this.delim = delimitter;
        }


        private void createAndRegisterTableMetadata(List<String> queries) {

            LOGGER.info("Extracting metadata info for queries");
            if (queries != null){
                for(String query: queries){
                    LOGGER.debug("Extracting metadata info for query:" + query);
                    TableMetadata tableMetadata = QueryProcessor.getTableMetadataFromQuery(query);
                    tableMetadata.setParentDir(getOutputDir());
                    tableMetaDataCache.register(tableMetadata);
                    this.queries.add(new Query(tableMetadata.getTableName(),query));
                }
            }
        }

    public TableMetaDataCache getTableMetaDataCache(){

        return tableMetaDataCache;
    }
}
