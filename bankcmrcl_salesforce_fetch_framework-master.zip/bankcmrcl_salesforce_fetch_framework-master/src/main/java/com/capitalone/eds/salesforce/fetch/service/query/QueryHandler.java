package com.capitalone.eds.salesforce.fetch.service.query;

import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchException;
import com.capitalone.eds.salesforce.fetch.model.Query;
import com.capitalone.eds.salesforce.fetch.model.Table;
import com.capitalone.eds.salesforce.fetch.service.SalesforceClient;
import com.capitalone.eds.salesforce.fetch.service.authenticator.SforceAuthResult;
import com.capitalone.eds.salesforce.fetch.util.TableWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.BadRequestException;
import java.util.List;

public class QueryHandler {

    @Autowired
    private TableWriter tableWriter;

    @Autowired
    private SalesforceClient sforceClient;

    private SforceAuthResult sforceAuthResult;
    private  List<Query> queries;
    private final Logger LOGGER= LoggerFactory.getLogger(QueryHandler.class);

    public void setQueries(List<Query> queries){

        this.queries = queries;
    }

    public void setAuthResult(SforceAuthResult sforceAuthResult){

        this.sforceAuthResult =sforceAuthResult;
    }

    public void runSfQueries() {

        for(Query query : queries){
            LOGGER.info("Running query: " + query.getQuery());
            tryRunSfQuery(query);
        }
    }

    private void tryRunSfQuery(Query query)  {

        try {
            runSfQuery(query);
        } catch (Exception e) {
            deleteIncompleteFile(query);
            LOGGER.error("Error while executing query pipeline : " + e.getMessage());
        }
    }

    private void deleteIncompleteFile(Query query) {
        try {
            tableWriter.deleteFile(query);
        } catch (SalesforceFetchException e) {
            LOGGER.error("Could not clean up file for query: " + query.getQuery());
        }
    }

    private void runSfQuery(Query query) throws SalesforceFetchException {

        String baseQueryStr = query.getQuery();

        LOGGER.info("Launching restful salesforce client ");
        Table table = sforceClient.execRestQuery(baseQueryStr,sforceAuthResult);
        LOGGER.info("Table retrieved has " + table.getRecords().size() + " records");
        table.setTableName(query.getTableName());
        sforceAuthResult.removeQueryKey();
        tableWriter.deleteFile(query);
        while(table.hasNextUrl()){
            table = writeAndGetNextTable(table,baseQueryStr);
        }
        sforceAuthResult.reset();

        LOGGER.info("Writing table to file");
        tableWriter.write(table);
    }

    private Table writeAndGetNextTable(Table table,String baseQueryStr) throws SalesforceFetchException{

        String restUrl = table.getNextURL();

        LOGGER.info("Writing table to file");
        tableWriter.write(table);
        sforceAuthResult.setRestUrlPath(restUrl);

        LOGGER.info("Next restful URL call  for: " + table.getTableName());
        table = sforceClient.execRestQuery(baseQueryStr,sforceAuthResult);
        LOGGER.info("Table retrieved has " + table.getRecords().size() + " records");

        return table;
    }

}
