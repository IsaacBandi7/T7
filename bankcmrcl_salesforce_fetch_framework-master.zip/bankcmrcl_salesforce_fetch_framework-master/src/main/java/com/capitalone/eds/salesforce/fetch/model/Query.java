package com.capitalone.eds.salesforce.fetch.model;

public class Query {

    private final String tableName;
    private final String query;

    public Query(String tableName, String query){

        this.tableName = tableName;
        this.query = query;
    }

    public String getQuery() {
        return query;
    }


    public String getTableName() {
        return tableName;
    }

}
