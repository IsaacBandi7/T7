package com.capitalone.eds.salesforce.fetch.main;

import com.capitalone.eds.salesforce.fetch.input.Arguments;
import com.capitalone.eds.salesforce.fetch.input.cli.CLI;
import com.capitalone.eds.salesforce.fetch.service.query.QueryHandler;
import com.capitalone.eds.salesforce.fetch.util.FileNameTransformer;
import com.capitalone.eds.salesforce.fetch.util.TableMetaDataCache;
import com.capitalone.eds.salesforce.fetch.service.SalesforceClient;
import com.capitalone.eds.salesforce.fetch.service.authenticator.PartnerSessionManager;
import com.capitalone.eds.salesforce.fetch.service.authenticator.SessionManager;
import com.capitalone.eds.salesforce.fetch.util.DelimTableWriter;
import com.capitalone.eds.salesforce.fetch.util.TableWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;


@SpringBootApplication
@org.springframework.context.annotation.Configuration
public class SalesforceInjectionApp {

    @Autowired
    private Environment env;


    public static void main(String args[]) {

        SpringApplication.run(SalesforceInjectionApp.class, args);
    }

    @Bean
    @Scope("singleton")
    public TableMetaDataCache getTableMetaDataCache () {

        return new TableMetaDataCache();
    }

    @Bean
    @Scope("singleton")
    public SessionManager getSessionManger (Arguments arguments) {

        return new PartnerSessionManager(arguments);
    }

    @Bean
    @Scope("singleton")
    public SalesforceFetch getSalesforceFetch() {

        return new SalesforceFetch();
    }

    @Bean
    @Scope("singleton")
    public Arguments getArguments (CLI cli, TableMetaDataCache tableMetaDataCache) {

        return new Arguments(cli,tableMetaDataCache);
    }

    @Bean
    @Scope("singleton")
    public CLI getCLI () {

        String[] progArgs = env.getProperty("nonOptionArgs").split(",");
        return new CLI(progArgs);
    }

    @Bean
    @Scope("prototype")
    public SalesforceClient getSalesforceClient () {

        return new SalesforceClient();
    }

    @Bean
    @Scope("prototype")
    public TableWriter getTableWriter () {

        return new DelimTableWriter();
    }

    @Bean
    @Scope("prototype")
    public QueryHandler getQueryHandler (Arguments arguments) {

        QueryHandler handler = new QueryHandler();
        handler.setQueries(arguments.getQueries());
        return handler;
    }

    @Bean
    @Scope("prototype")
    public FileNameTransformer getFileNameTransformer () {

        return new FileNameTransformer();
    }

}
