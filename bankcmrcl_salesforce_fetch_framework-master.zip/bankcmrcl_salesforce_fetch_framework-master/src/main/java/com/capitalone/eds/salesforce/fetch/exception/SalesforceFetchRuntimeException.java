package com.capitalone.eds.salesforce.fetch.exception;


public class SalesforceFetchRuntimeException extends RuntimeException {

    public SalesforceFetchRuntimeException(String messagse){
        super(messagse);
    }
}
