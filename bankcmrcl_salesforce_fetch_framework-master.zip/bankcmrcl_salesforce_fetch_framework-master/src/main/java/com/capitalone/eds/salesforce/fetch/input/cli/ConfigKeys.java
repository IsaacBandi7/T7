package com.capitalone.eds.salesforce.fetch.input.cli;


public enum ConfigKeys {

    SALESFORCE_AUTHENDPOINT_KEY ("salesforce.authendpoint"), SALESFORCE_USERNAME_KEY("salesforce.username"),SALESFORCE_PASSWORD_KEY("salesforce.password"), SALESFORCE_SOAPENDPOINT_KEY ("salesforce.soapendpoint"),
    SALESFORCE_SIEBELCERT_KEY("salesforce.siebelcert"), SALESFORCE_SIEBELCERTPWD_KEY("salesforce.siebelcertpwd"),SALESFORCE_TRUSTSTORE_KEY("salesforce.truststore"), SALESFORCE_TRUSTSTOREPWD_KEY("salesforce.truststorepwd"),
    SALESFORCE_OUTPUTDIR_KEY("salesforce.outputdir"),DELIMITER("app.delim"),PROXY_URL("proxy.url"),PROXY_USER("proxy.user"),PROXY_PSWD("proxy.pswd"),APP_TRIM("app.trim"),APP_PREFIX("app.prefix"),APP_SUFFIX("app.suffix");



    private String description;

    ConfigKeys(String description){

        this.description = description;
    }

    public String value(){

        return description;
    }


}
