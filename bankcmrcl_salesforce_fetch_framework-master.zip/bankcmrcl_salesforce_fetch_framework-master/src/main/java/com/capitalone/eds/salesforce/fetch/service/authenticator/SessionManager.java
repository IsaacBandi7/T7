package com.capitalone.eds.salesforce.fetch.service.authenticator;


import com.capitalone.eds.salesforce.fetch.service.SalesforceClient;

public interface SessionManager {

    SforceAuthResult getSforceAuthResult(SalesforceClient sforceClient);
}
