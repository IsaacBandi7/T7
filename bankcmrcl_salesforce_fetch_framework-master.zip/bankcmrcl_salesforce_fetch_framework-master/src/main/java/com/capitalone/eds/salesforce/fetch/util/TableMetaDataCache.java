package com.capitalone.eds.salesforce.fetch.util;


import com.capitalone.eds.salesforce.fetch.exception.SalesforceFetchException;
import com.capitalone.eds.salesforce.fetch.model.TableMetadata;

import java.util.HashMap;
import java.util.Map;

public class TableMetaDataCache {

    private  Map<String,TableMetadata> tableMetadataMap;

    public TableMetaDataCache(){

        this.tableMetadataMap = new HashMap<>();
    }


    public  void register(TableMetadata tableMetadata) {

        String tableName = tableMetadata.getTableName();
        tableMetadataMap.put(tableName,tableMetadata);
    }

    public  TableMetadata getTableMetaData(String tableName) throws SalesforceFetchException {

        if(tableMetadataMap.containsKey(tableName)){
            return tableMetadataMap.get(tableName);
        }else{
            throw new SalesforceFetchException("Could not fetch table info for: " + tableName);
        }
    }
}
