package com.capitalone.eds.salesforce.fetch.input.cli;


public enum CLIArgs {

    QUERY_FILE("query"), CONF_FILE("conf"),HELP("help");

    private String description;

    CLIArgs(String description){

        this.description = description;
    }

    public String value(){

        return description;
    }
}
