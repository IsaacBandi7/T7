package com.capitalone.eds.salesforce.fetch.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;



@Component
public class SalesforceInjectionRunner implements CommandLineRunner {

    private final Logger LOGGER= LoggerFactory.getLogger(SalesforceInjectionRunner.class);

    @Autowired
    private SalesforceFetch salesforceFetch;

    @Override
    public void run(String[] strings) throws Exception {

        LOGGER.info("Running application...");
        salesforceFetch.execute();
    }

}
