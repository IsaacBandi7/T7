package com.capitalone.eds.salesforce.fetch.exception;


public class SalesforceFetchException extends Exception{

    public SalesforceFetchException(String message){
        super(message);
    }
}
