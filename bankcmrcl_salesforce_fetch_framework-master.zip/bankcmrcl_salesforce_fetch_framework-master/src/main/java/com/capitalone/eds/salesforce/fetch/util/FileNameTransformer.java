package com.capitalone.eds.salesforce.fetch.util;


import com.capitalone.eds.salesforce.fetch.input.Arguments;
import org.springframework.beans.factory.annotation.Autowired;

public class FileNameTransformer {

    @Autowired
    private Arguments arguments;
    
    private String tableName;

    public void setTableName(String tableName){

        this.tableName = tableName;
    }

    public String getName() {

        if(tableName != null && !tableName.equals("")){
            tableName = trim(tableName);
            tableName = prependPrefix(this.tableName);
            tableName = appendSuffix(this.tableName);
        }
        return tableName;
    }

    private String trim(String tableName) {

        String trimValue = arguments.getAppTrim();
        String newTableName = tableName;
        if(trimValue != null && !trimValue.equals("") && !trimValue.equals("null")){
            newTableName = tableName.replaceAll(trimValue, "");
        }
        return newTableName;
    }

    private String prependPrefix(String tableName) {

        String prefix = arguments.getAppPrefix();
        if (prefix == null || prefix.equals("null")) {
            return tableName;
        } else {
            return prefix + tableName;
        }
    }

    private String appendSuffix(String tableName) {

        String suffix = arguments.getAppSuffix();
        if (suffix == null || suffix.equals("null")) {
            return tableName;
        } else {
            return tableName + suffix;
        }
    }
}
