EDS System Team Example Repository
==================================

This is an example repository for a Java application.

