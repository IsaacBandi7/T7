package com.capitalone.api.dms.main;


import com.amazonaws.util.BinaryUtils;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;	
import org.springframework.beans.factory.InitializingBean;
import org.springframework.integration.aws.core.AWSCommonUtils;
import org.springframework.integration.aws.core.AWSCredentials;
import org.springframework.integration.aws.s3.core.AmazonS3Object;
import org.springframework.integration.aws.s3.core.AmazonS3ObjectACL;
import org.springframework.integration.aws.s3.core.AmazonS3OperationException;
import org.springframework.integration.aws.s3.core.AmazonS3Operations;
import org.springframework.integration.aws.s3.core.PaginatedObjectsView;
import org.springframework.integration.aws.s3.core.S3ObjectSummary;
import org.springframework.util.Assert;

public abstract class AbstractAmazonS3Operations implements AmazonS3Operations, InitializingBean {
public  Logger logger = LoggerFactory.getLogger(this.getClass());
 private volatile long multipartUploadThreshold;
 private volatile File temporaryDirectory = new File(System.getProperty("java.io.tmpdir"));
 private volatile String temporaryFileSuffix = ".writing";
 public final String PATH_SEPARATOR = "/";
 private String awsEndpoint;

 protected AbstractAmazonS3Operations() {
     
 }

 public long getMultipartUploadThreshold() {
     return this.multipartUploadThreshold;
 }

 public void setMultipartUploadThreshold(long multipartUploadThreshold) {
     Assert.isTrue(multipartUploadThreshold >= 5120L, "Minimum threshold for multipart upload is 5120 bytes");
     this.multipartUploadThreshold = multipartUploadThreshold;
 }

 public File getTemporaryDirectory() {
     return this.temporaryDirectory;
 }

 public void setTemporaryDirectory(File temporaryDirectory) {
     Assert.notNull(temporaryDirectory, "Provided temporaryDirectory is null");
     Assert.isTrue(temporaryDirectory.exists(), "The given temporary directory does not exist");
     Assert.isTrue(temporaryDirectory.isDirectory(), "The given temporary directory path has to be a directory");
     this.temporaryDirectory = temporaryDirectory;
 }

 public void setTemporaryDirectory(String temporaryDirectory) {
     Assert.hasText(temporaryDirectory, "Provided temporary directory string is null or empty string");
     this.setTemporaryDirectory(new File(temporaryDirectory));
 }

 public String getTemporaryFileSuffix() {
     return this.temporaryFileSuffix;
 }

 public void setTemporaryFileSuffix(String temporaryFileSuffix) {
     Assert.hasText(temporaryFileSuffix, "The temporary file suffix must not be null or empty");
     if(!temporaryFileSuffix.startsWith(".")) {
         temporaryFileSuffix = "." + temporaryFileSuffix;
     }

     this.temporaryFileSuffix = temporaryFileSuffix;
 }

 public String getAwsEndpoint() {
     return this.awsEndpoint;
 }

 public void setAwsEndpoint(String awsEndpoint) {
     Assert.hasText(awsEndpoint, "Given AWS Endpoint has to be non null and non empty string");
     this.awsEndpoint = awsEndpoint;
 }

 public final void afterPropertiesSet() throws Exception {
     this.init();
 }

 protected void init() {
 }

 private File getTempFile(InputStream in, String bucketName, String objectName) {
     Object inStream;
     if(!(in instanceof BufferedInputStream) && !(in instanceof ByteArrayInputStream)) {
         inStream = new BufferedInputStream(in);
     } else {
         inStream = in;
     }

     String fileName;
     if(objectName.contains("/")) {
         String[] temporaryDirectory = objectName.split("/");
         fileName = temporaryDirectory[temporaryDirectory.length - 1];
     } else {
         fileName = objectName;
     }

     File temporaryDirectory1 = this.getTemporaryDirectory();
     String temporaryFileSuffix = this.getTemporaryFileSuffix();
     String filePath = temporaryDirectory1.getAbsoluteFile() + File.separator + fileName + temporaryFileSuffix;
     if(this.logger.isDebugEnabled()) {
         this.logger.debug("Temporary file path is " + filePath);
     }

     File tempFile = new File(filePath);
     FileOutputStream fos = null;

     try {
         fos = new FileOutputStream(tempFile);
         byte[] ioe = new byte[1024];
         boolean read = false;

         while(true) {
             int read1 = ((InputStream)inStream).read(ioe);
             if(read1 == -1) {
                 return tempFile;
             }

             fos.write(ioe, 0, read1);
         }
     } catch (FileNotFoundException var24) {
         throw new AmazonS3OperationException("accessKey", bucketName, objectName, "Exception caught while writing the temporary file from input stream", var24);
     } catch (IOException var25) {
         throw new AmazonS3OperationException("accessKey", bucketName, objectName, "Exception caught while reading from the provided input stream", var25);
     } finally {
         if(fos != null) {
             try {
                 fos.flush();
                 fos.close();
             } catch (IOException var23) {
                 this.logger.error("Unable to close the stream to the temp file being created", var23);
             }

             try {
                 in.close();
             } catch (IOException var22) {
                 this.logger.error("Unable to close the input stream source", var22);
             }
         }

     }
 }

 public final void putObject(String bucketName, String folder, String objectName, AmazonS3Object s3Object) {
     Assert.hasText(bucketName, "null or empty bucketName provided");
     Assert.hasText(objectName, "null or empty object name provided");
     Assert.notNull(s3Object, "null s3 object provided for upload");
     File file = s3Object.getFileSource();
     InputStream in = s3Object.getInputStream();
     Assert.isTrue(file != null ^ in != null, "Exactly one of file or inpuut stream needed in the provided s3 object");
     boolean isTempFile = false;
     if(in != null) {
         file = this.getTempFile(in, bucketName, objectName);
         isTempFile = true;
     }

     String key = this.getKeyFromFolder(folder, objectName);
     String stringContentMD5 = BinaryUtils.toBase64(AWSCommonUtils.getContentsMD5AsBytes(file));

     try {
         this.doPut(bucketName, key, file, s3Object.getObjectACL(), s3Object.getUserMetaData(), stringContentMD5);
     } catch (Exception var11) {
         throw new AmazonS3OperationException("accessKey", bucketName, key, "Encountered exception while putting an object, see root cause for more details", var11);
     }

     if(isTempFile) {
         if(this.logger.isDebugEnabled()) {
             this.logger.debug("Deleting temp file: " + file.getName());
         }

         boolean deleteSuccessful = file.delete();
         if(!deleteSuccessful) {
             this.logger.warn("Unable to delete file \'" + file.getName() + "\'");
         }
     }

 }

 protected String getKeyFromFolder(String folder, String objectName) {
     if(objectName.startsWith("/")) {
         objectName = objectName.substring(1);
     }

     String key;
     if(folder != null) {
         key = folder.endsWith("/")?folder + objectName:folder + "/" + objectName;
     } else {
         key = objectName;
     }

     if(key.startsWith("/")) {
         key = key.substring(1);
     }

     return key;
 }

 public boolean copyObject(String sourceBucketName, String sourceKey, String destinationBucketName, String destinationFolder) {
     return true;
 }

 public boolean removeObject(String bucketName, String folder, String objectName) {
     throw new UnsupportedOperationException("Operation not et supported");
 }

 public final PaginatedObjectsView listObjects(String bucketName, String folder, String nextMarker, int pageSize) {
     Assert.hasText(bucketName, "Bucket name should be non null and non empty");
     Assert.isTrue(pageSize >= 0, "Page size should be a non negative number");
     if(this.logger.isDebugEnabled()) {
         this.logger.debug("Listing objects from bucket " + bucketName + " and folder " + folder);
         this.logger.debug("Next marker is " + nextMarker + " and pageSize is " + pageSize);
     }

     String prefix = null;
     if(folder != null && !"/".equals(folder)) {
         prefix = folder;
     }

     if(prefix != null && prefix.startsWith("/")) {
         prefix = prefix.substring(1);
     }

     return this.doListObjects(bucketName, nextMarker, pageSize, prefix);
 }

 public final AmazonS3Object getObject(String bucketName, String folder, String objectName) {
     Assert.hasText(bucketName, "Bucket name should be non null and non empty");
     if(this.logger.isDebugEnabled()) {
         this.logger.debug("Getting from bucket " + bucketName + ", from folder " + folder + " the  object name " + objectName);
     }

     String key = this.getKeyFromFolder(folder, objectName);

     try {
         return this.doGetObject(bucketName, key);
     } catch (Exception var6) {
         throw new AmazonS3OperationException("accessKey", bucketName, key, "Encountered exception while putting an object, see root cause for more details", var6);
     }
 }

 protected abstract AmazonS3Object doGetObject(String var1, String var2);

 protected abstract PaginatedObjectsView doListObjects(String var1, String var2, int var3, String var4);

 protected abstract void doPut(String var1, String var2, File var3, AmazonS3ObjectACL var4, Map<String, String> var5, String var6);

 static class PagninatedObjectsViewImpl implements PaginatedObjectsView {
     private final List<S3ObjectSummary> objectSummary;
     private final String nextMarker;

     public PagninatedObjectsViewImpl(List<S3ObjectSummary> objectSummary, String nextMarker) {
         this.objectSummary = objectSummary;
         this.nextMarker = nextMarker;
     }

     public List<S3ObjectSummary> getObjectSummary() {
         return (List)(this.objectSummary != null?this.objectSummary:new ArrayList());
     }

     public boolean hasMoreResults() {
         return this.nextMarker != null;
     }

     public String getNextMarker() {
         return this.nextMarker;
     }
 }
}
