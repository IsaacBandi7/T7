package com.capitalone.api.dms.main;


import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;

public class CustomClientCredentialsResourceDetails extends ClientCredentialsResourceDetails {

		public void setClientId(String clientId) {
			super.setClientId(clientId);
		}

		public void setAccessTokenUri(String accessTokenUri) {
			super.setAccessTokenUri(accessTokenUri);
		}

		public void setClientSecret(String clientSecret) {
			super.setClientSecret(clientSecret);
		}

	}
