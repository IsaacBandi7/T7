package com.capitalone.api.dms.main;




import com.amazonaws.ClientConfiguration;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.AccessControlList;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.CanonicalGrantee;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.EmailAddressGrantee;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.GroupGrantee;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.Permission;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.SSEAwsKeyManagementParams;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerConfiguration;
import com.amazonaws.services.s3.transfer.Upload;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;
import org.springframework.integration.aws.core.AbstractAWSClientFactory;
import com.capitalone.api.dms.main.AbstractAmazonS3Operations;
import org.springframework.integration.aws.s3.core.AmazonS3Object;
import org.springframework.integration.aws.s3.core.AmazonS3ObjectACL;
import org.springframework.integration.aws.s3.core.AmazonS3OperationException;
import org.springframework.integration.aws.s3.core.Grantee;
import org.springframework.integration.aws.s3.core.GranteeType;
import org.springframework.integration.aws.s3.core.ObjectGrant;
import org.springframework.integration.aws.s3.core.ObjectPermissions;
import org.springframework.integration.aws.s3.core.PaginatedObjectsView;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

public class CustomC1AmazonS3Operations extends AbstractAmazonS3Operations {
 private AmazonS3Client client;
 private volatile TransferManager transferManager;
 private volatile ThreadPoolExecutor threadPoolExecutor;
 private volatile AbstractAWSClientFactory<AmazonS3Client> s3Factory;
 private volatile String awsSecurityKey;
 private volatile SSEAwsKeyManagementParams sseAwsKeyManagementParams;

 public CustomC1AmazonS3Operations( final ClientConfiguration clientConfiguration) {
    
     this.s3Factory = new AbstractAWSClientFactory() {
         protected AmazonS3Client getClientImplementation() {
            
             return new AmazonS3Client();
         }
     };
 }

 protected void init() {
     this.client = (AmazonS3Client)this.s3Factory.getClient(this.getAwsEndpoint());
     if(this.threadPoolExecutor == null) {
         this.transferManager = new TransferManager(this.client);
     } else {
         this.transferManager = new TransferManager(this.client, this.threadPoolExecutor);
     }

     long multipartUploadThreshold = this.getMultipartUploadThreshold();
     if(multipartUploadThreshold > 0L) {
         TransferManagerConfiguration config = new TransferManagerConfiguration();
         if(multipartUploadThreshold > 2147483647L) {
             config.setMultipartUploadThreshold(2147483647L);
         } else {
             config.setMultipartUploadThreshold((long)((int)multipartUploadThreshold));
         }

         this.transferManager.setConfiguration(config);
     }

 }

 protected PaginatedObjectsView doListObjects(String bucketName, String nextMarker, int pageSize, String prefix) {
     ListObjectsRequest listObjectsRequest = (new ListObjectsRequest()).withBucketName(bucketName).withPrefix(prefix).withMarker(nextMarker);
     if(pageSize > 0) {
         listObjectsRequest.withMaxKeys(Integer.valueOf(pageSize));
     }

     ObjectListing listing = this.client.listObjects(listObjectsRequest);
     PagninatedObjectsViewImpl view = null;
     List summaries = listing.getObjectSummaries();
     if(summaries != null && !summaries.isEmpty()) {
         ArrayList objectSummaries = new ArrayList();
         Iterator i$ = summaries.iterator();

         while(i$.hasNext()) {
             final S3ObjectSummary summary = (S3ObjectSummary)i$.next();
             org.springframework.integration.aws.s3.core.S3ObjectSummary summ = new org.springframework.integration.aws.s3.core.S3ObjectSummary() {
                 public long getSize() {
                     return summary.getSize();
                 }

                 public Date getLastModified() {
                     return summary.getLastModified();
                 }

                 public String getKey() {
                     return summary.getKey();
                 }

                 public String getETag() {
                     return summary.getETag();
                 }

                 public String getBucketName() {
                     return summary.getBucketName();
                 }
             };
             objectSummaries.add(summ);
         }

         view = new PagninatedObjectsViewImpl(objectSummaries, listing.getNextMarker());
     }

     return view;
 }

 protected AmazonS3Object doGetObject(String bucketName, String key) {
     GetObjectRequest request = new GetObjectRequest(bucketName, key);

     S3Object s3Object;
     try {
         s3Object = this.client.getObject(request);
     } catch (AmazonS3Exception var6) {
         if("NoSuchKey".equals(var6.getErrorCode())) {
             return null;
         }

         throw var6;
     }

     return new AmazonS3Object(s3Object.getObjectMetadata().getUserMetadata(), s3Object.getObjectMetadata().getRawMetadata(), s3Object.getObjectContent(), (File)null);
 }

 public boolean copyObject(String sourceBucketName, String sourceKey, String destinationBucketName, String destinationFolder) {
     CopyObjectRequest copyObjectRequest = new CopyObjectRequest(sourceBucketName, this.getKeyFromFolder("/", sourceKey), destinationBucketName, this.getKeyFromFolder(destinationFolder, sourceKey));
     if(StringUtils.hasText(this.awsSecurityKey)) {
         copyObjectRequest.withSSEAwsKeyManagementParams(this.getSSseAwsKeyManagementParams());
     }

     this.client.copyObject(copyObjectRequest);
     return true;
 }

 public boolean removeObject(String bucketName, String folder, String objectName) {
     DeleteObjectRequest deleteObjectRequest = new DeleteObjectRequest(bucketName, this.getKeyFromFolder(folder, objectName));
     this.client.deleteObject(deleteObjectRequest);
     return true;
 }

 public void doPut(String bucketName, String key, File file, AmazonS3ObjectACL objectACL, Map<String, String> userMetadata, String stringContentMD5) {
     ObjectMetadata metadata = new ObjectMetadata();
     PutObjectRequest request = new PutObjectRequest(bucketName, key, file);
     if(StringUtils.hasText(this.awsSecurityKey)) {
         request.withSSEAwsKeyManagementParams(this.getSSseAwsKeyManagementParams());
     }

     request.withMetadata(metadata);
     if(stringContentMD5 != null) {
         metadata.setContentMD5(stringContentMD5);
     }

     if(userMetadata != null) {
         metadata.setUserMetadata(userMetadata);
     }

     Upload upload;
     try {
         upload = this.transferManager.upload(request);
     } catch (Exception var12) {
         var12.printStackTrace();
         throw new AmazonS3OperationException("access key", bucketName, key, "Encountered Exception while invoking upload on multipart/single thread file, see nested exceptions for more details", var12);
     }

     try {
         if(this.logger.isInfoEnabled()) {
             this.logger.info("Waiting for Upload to complete");
         }

         upload.waitForCompletion();
         if(this.logger.isInfoEnabled()) {
             this.logger.info("Upload completed");
         }
     } catch (Exception var13) {
         var13.printStackTrace();
         throw new AmazonS3OperationException("access key", bucketName, key, "Encountered Exception while uploading the multipart/single thread file, see nested exceptions for more details", var13);
     }

     if(objectACL != null) {
         if(this.logger.isInfoEnabled()) {
             this.logger.info("Setting Access control list for key " + key);
         }

         try {
             this.client.setObjectAcl(bucketName, key, this.getAccessControlList(bucketName, key, objectACL));
         } catch (Exception var11) {
             var11.printStackTrace();
             throw new AmazonS3OperationException("access key", bucketName, key, "Encountered Exception while setting the Object ACL for key , " + key + "see nested exceptions for more details", var11);
         }

         if(this.logger.isDebugEnabled()) {
             this.logger.debug("Successfully set the object ACL");
         }
     }

 }

 private AccessControlList getAccessControlList(String bucketName, String key, AmazonS3ObjectACL acl) {
     AccessControlList accessControlList = null;
     if(acl != null && !acl.getGrants().isEmpty()) {
         accessControlList = this.client.getObjectAcl(bucketName, key);
         Iterator i$ = acl.getGrants().iterator();

         while(true) {
             while(i$.hasNext()) {
                 ObjectGrant objGrant = (ObjectGrant)i$.next();
                 Grantee grantee = objGrant.getGrantee();
                 Object awsGrantee;
                 if(grantee.getGranteeType() == GranteeType.CANONICAL_GRANTEE_TYPE) {
                     awsGrantee = new CanonicalGrantee(grantee.getIdentifier());
                 } else if(grantee.getGranteeType() == GranteeType.EMAIL_GRANTEE_TYPE) {
                     awsGrantee = new EmailAddressGrantee(grantee.getIdentifier());
                 } else {
                     awsGrantee = GroupGrantee.parseGroupGrantee(grantee.getIdentifier());
                     if(awsGrantee == null) {
                         this.logger.warn("Group grantee with identifier: \"" + grantee.getIdentifier() + "\" not found. skipping this grant");
                         continue;
                     }
                 }

                 ObjectPermissions perm = objGrant.getPermission();
                 Permission permission;
                 if(perm == ObjectPermissions.READ) {
                     permission = Permission.Read;
                 } else if(perm == ObjectPermissions.READ_ACP) {
                     permission = Permission.ReadAcp;
                 } else {
                     permission = Permission.WriteAcp;
                 }

                 accessControlList.grantPermission((com.amazonaws.services.s3.model.Grantee)awsGrantee, permission);
             }

             return accessControlList;
         }
     } else {
         return accessControlList;
     }
 }

 public ThreadPoolExecutor getThreadPoolExecutor() {
     return this.threadPoolExecutor;
 }

 public void setThreadPoolExecutor(ThreadPoolExecutor threadPoolExecutor) {
     Assert.notNull(threadPoolExecutor, "\'threadPoolExecutor\' is null");
     this.threadPoolExecutor = threadPoolExecutor;
 }

 private SSEAwsKeyManagementParams getSSseAwsKeyManagementParams() {
     if(this.sseAwsKeyManagementParams == null) {
         this.sseAwsKeyManagementParams = new SSEAwsKeyManagementParams(this.getAwsSecurityKey());
     }

     return this.sseAwsKeyManagementParams;
 }

 public String getAwsSecurityKey() {
     return this.awsSecurityKey;
 }

 public void setAwsSecurityKey(String awsSecurityKey) {
     this.awsSecurityKey = awsSecurityKey;
 }
}
