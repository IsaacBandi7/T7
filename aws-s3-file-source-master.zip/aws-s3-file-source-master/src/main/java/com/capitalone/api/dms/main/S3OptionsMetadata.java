package com.capitalone.api.dms.main;


import org.springframework.xd.module.options.spi.ModuleOption;

public class S3OptionsMetadata {

	private String accessKey="AKIAJBYWWNFRIDES7DOA";
	private String secretKey="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";
	private String bucket="dms-batch-st";
	private String awsSecurityKey="arn:aws:kms:us-east-1:625275122486:key/3fb86a24-bc28-4469-810c-7657deedbc64";
	private String localDirectory="/tmp/MM";
	private String temporaryDirectory="/tmp/MM/output";
	private String fileNameWildcard="*.*";
	private String region="DEV";
	private String	archiveDirectory="/archive";
	private String	proxyHost="proxy.kdc.capitalone.com";
	private String	proxyPort="8099";
	private String	fixedDelay="5000";
    private String	prefix="/input";
	private String  archiveBucket="dms-batch-st";
	private String  url="";
	private String  doHealthCheck="false";
	private String  maxMessageRate="1";
	private String  smsUrl="";
	private String  healthHeader="";
	
   

	private String clientId="";
    
    private String clientSecret="";
    
    private String accessTokenUri="";
    

    public String getClientId() {
		return clientId;
	}

    
    @ModuleOption("OAuth token client Id")

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

    
    
	public String getClientSecret() {
		return clientSecret;
	}

	
	 public String getHealthHeader() {
			return healthHeader;
		}

	   @ModuleOption("Health check value for sms URL")
	   public void setHealthHeader(String healthHeader) {
			this.healthHeader = healthHeader;
		}
	
	 @ModuleOption("OAuth token client secret") 
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	 
	public String getAccessTokenUri() {
		return accessTokenUri;
	}

	
	 @ModuleOption("OAuth token token generator URI") 

	public void setAccessTokenUri(String accessTokenUri) {
		this.accessTokenUri = accessTokenUri;
	}

	
	public String getSmsUrl() {
		return smsUrl;
	}

	@ModuleOption(" sms Url Seperated by , to perform healthcheck")

	public void setSmsUrl(String smsUrl) {
		this.smsUrl = smsUrl;
	}


	public String getRegion() {
		return region;
	}

	
	@ModuleOption("Region ST,IT,DEV,PROD")
	public void setRegion(String region) {
		this.region = region;
	}

	public String getUrl() {
		return url;
	}

	@ModuleOption("Url Seperated by , to perform healthcheck")
    public void setUrl(String url) {
		this.url = url;
	}

	public String getDoHealthCheck() {
		return doHealthCheck;
	}
  
	@ModuleOption("boolean flag to enable or disable healthcheck")

	public void setDoHealthCheck(String doHealthCheck) {
		this.doHealthCheck = doHealthCheck;
	}

	
	public String getArchiveBucket() {
		return archiveBucket;
	}

	@ModuleOption("The bucket name in S3 where files should be archived")
    public void setArchiveBucket(String archiveBucket) {
		this.archiveBucket = archiveBucket;
	}

	public String getArchiveDirectory() {
		return archiveDirectory;
	}

	@ModuleOption("Archive directory in S3 where files should be archived")
    public void setArchiveDirectory(String archiveDirectory) {
		this.archiveDirectory = archiveDirectory;
	}

	public String getProxyHost() {
		return proxyHost;
	}

	@ModuleOption("Proxy host for local setup")
    public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	public String getProxyPort() {
		return proxyPort;
	}

	@ModuleOption("Proxy Port for local setup")
    public void setProxyPort(String proxyPort) {
		this.proxyPort = proxyPort;
	}

	public String getFixedDelay() {
		return fixedDelay;
	}

	@ModuleOption("delay  in ms for file polling")
        public void setFixedDelay(String fixedDelay) {
		this.fixedDelay = fixedDelay;
	}

	public String getPrefix() {
		return prefix;
	}

	@ModuleOption("Name of Folder inside bucket")
    public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	
	public String getAccessKey() {
		return accessKey;
	}
	
	@ModuleOption("AWS S3 Acess key token")
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	
	public String getSecretKey() {
		return secretKey;
	}
	
	@ModuleOption("AWS S3 secret key token")
	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	
	public String getBucket() {
		return bucket;
	}
	
	@ModuleOption("AWS S3 Bucket Name")
	public void setBucket(String bucket) {
		this.bucket = bucket;
	}
	
	public String getAwsSecurityKey() {
		return awsSecurityKey;
	}
	
	@ModuleOption("AWS S3 KMS Security Key")
	public void setAwsSecurityKey(String awsSecurityKey) {
		this.awsSecurityKey = awsSecurityKey;
	}
	
	public String getLocalDirectory() {
		return localDirectory;
	}
	
	@ModuleOption("Location where s3 files should be stored in local directory")
	public void setLocalDirectory(String localDirectory) {
		this.localDirectory = localDirectory;
	}
	
	public String getTemporaryDirectory() {
		return temporaryDirectory;
	}
	
	@ModuleOption("Temprorary file directory where files will be stored after processing.")
	public void setTemporaryDirectory(String temporaryDirectory) {
		this.temporaryDirectory = temporaryDirectory;
	}
	
	
	public String getFileNameWildcard() {
		return fileNameWildcard;
	}
	
	@ModuleOption("File name patterns which need to be picked from S3.")
	public void setFileNameWildcard(String fileNameWildcard) {
		this.fileNameWildcard = fileNameWildcard;
	}
	
	public String getMaxMessageRate() {
		return maxMessageRate;
	}

	@ModuleOption("Max Message Per Poll from S3.")
	public void setMaxMessageRate(String maxMessageRate) {
		this.maxMessageRate = maxMessageRate;
	}
	
}
