package com.capitalone.api.dms.main;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.scheduling.PollSkipStrategy;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.web.client.RestTemplate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@ManagedResource
public class ServiceHealthCheckPollSkipStrategy  implements PollSkipStrategy  {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceHealthCheckPollSkipStrategy.class);
	private volatile boolean skip=false;
	private String url;
	private String smsUrl;

	
	private static String doHealthCheck;
	private RestTemplate restTemplate;
	private OAuth2RestTemplate oauthRestTemplate;



	private String healthHeader;
	private  BatchClientHttpRequestFactory requestFactory;

	
	public BatchClientHttpRequestFactory getRequestFactory() {
		return requestFactory;
	}

	public void setRequestFactory(BatchClientHttpRequestFactory requestFactory) {
		this.requestFactory = requestFactory;
	}



	
	public String getSmsUrl() {
		return smsUrl;
	}

	public void setSmsUrl(String smsUrl) {
		this.smsUrl = smsUrl;
	}


	
	public String getHealthHeader() {
		return healthHeader;
	}

	public void setHealthHeader(String healthHeader) {
		this.healthHeader = healthHeader;
	}


	public OAuth2RestTemplate getOauthRestTemplate() {
		return oauthRestTemplate;
	}

	public void setOauthRestTemplate(OAuth2RestTemplate oauthRestTemplate) {
		this.oauthRestTemplate = oauthRestTemplate;
	}

	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDoHealthCheck() {
		return doHealthCheck;
	}

	public void setDoHealthCheck(String doHealthCheck) {
		ServiceHealthCheckPollSkipStrategy.doHealthCheck= doHealthCheck;
	}

	@Override
	public boolean skipPoll() {
	 
		 
			if(doHealthCheck.equals("false")){
		    LOGGER.info("skipping healthcheck since flag is  false  " );

			return this.skip;
		}
		else if(doHealthCheck.equals("true")){
	      LOGGER.info("performing healthcheck since flag is  true  " );
		List<String> smsurlList =getUrlfromEncodedString(smsUrl);

		List<String> urlList =getUrlfromEncodedString(url);
		for (String url : urlList) {
			boolean status =performHealthCheck(url);
			if(status==false){
			return this.skip = true;	
			}
		}
           for (String smsUrl : smsurlList) {
				boolean smsStatus =performSMSHealthCheck(smsUrl);
				if(smsStatus==false){
				return this.skip = true;	
			}
           	
		}
		
		return this.skip;
		}
		else {
			throw  new IllegalArgumentException("do health check can be either true or false");
		}
		
	}

	/**
	 * Skip future polls.
	 */
	@ManagedOperation
	public void skipPolls() {
		this.skip = true;
	}


	/**
	 * Resume polling at the next {@code Trigger} event.
	 */
	@ManagedOperation
	public void reset() {
		this.skip = false;
	}
	
	
	private List<String>  getUrlfromEncodedString(String urls) throws IllegalArgumentException
	{
		if(urls==null){
			throw new IllegalArgumentException("urls passed is null");
		}
		List<String> urlList = Arrays.asList(urls.split("\\s*,\\s*"));		
		return urlList;
	}
	
	
	private boolean performHealthCheck(String url){
		if(url==null){
			LOGGER.error("url is null !");
			throw new IllegalArgumentException("url passed is null");
		}
		
		LOGGER.info("doing health check for URL "+ url );
	    HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set("API-Key", "RTM");

	    HttpEntity<String> request = new HttpEntity<String>(headers);

		ResponseEntity<String> response = restTemplate.
				  exchange(url, HttpMethod.GET, request, String.class);
		
		 if (response.getStatusCode().toString().equals("204")){
				LOGGER.info("healthcheck passed for url "+ url );

			 return  true;
		   }
		
		 LOGGER.error("healthcheck failed for url "+ url );
		return false;
	}
	
	
	private boolean performSMSHealthCheck(String smsUrl){
		if(smsUrl==null){
			LOGGER.error("sms url is null !");
			throw new IllegalArgumentException("sms url passed is null");
		}
		String data ="{}";

	    LOGGER.info("doing health check for URL "+ smsUrl );
	    HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set("Api-Key", "RTM");
	    headers.set("x-RS-Proxy-id","health");
	    headers.set("x-RS-Proxy-value",healthHeader);
            oauthRestTemplate.setRequestFactory(requestFactory);
            HttpEntity<String> request = new HttpEntity<String>(data,headers);
            ResponseEntity<String> response  = oauthRestTemplate.
				  exchange(smsUrl, HttpMethod.POST, request, String.class);
       
	
		 if (response.getStatusCode().toString().equals("204")){
				LOGGER.info("healthcheck passed for url "+ smsUrl );

			 return  true;
	}
		
		 LOGGER.error("healthcheck failed for url "+ smsUrl );
		return false;
	}
}

