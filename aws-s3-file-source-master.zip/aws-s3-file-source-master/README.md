aws-s3-file-source
==================

This repository will be used as a source for spring xd  to pull s3 files from aws and split  the record line by line

Usage:
* Clone this  repository and run mvn clean install
* Start the xd container and in xd shell 
* ```xd-shell> module upload --file $your_project/target/dms-aws-s3-source-1.0-SNAPSHOT.jar   --name aws-s3-source --type source ```
* ```xd-shell>stream create --name streamTest --definition "aws-s3-source --url=http://localhost:8080/RESTfulExample/rest/ca/mock/post --doHealthCheck=false --temporaryDirectory=/tmp/MM/output --bucket=dms-batch-trans-test2 --fileNameWildcard=*.*  --localDirectory=/tmp/MM/  | log" --deploy```
* Upload a file  in dms-gumbo bucket and batch-alert/input folder. Check your log files for the s3 records split line  by line .
* Check dms-aws-s3-nonprod.properties for more information
